import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { TrendingUp, TrendingDown, Award, Target, Calendar, BookOpen } from 'lucide-react';

export function Analytics() {
  const gpaData = [
    { semester: 'Fall 2023', gpa: 3.4 },
    { semester: 'Spring 2024', gpa: 3.6 },
    { semester: 'Fall 2024', gpa: 3.7 },
    { semester: 'Spring 2025', gpa: 3.8 },
    { semester: 'Fall 2025', gpa: 3.75 },
  ];

  const coursePerformance = [
    { course: 'CS 301', grade: 88, credits: 3 },
    { course: 'CS 305', grade: 92, credits: 4 },
    { course: 'CS 320', grade: 98, credits: 3 },
    { course: 'CS 340', grade: 85, credits: 3 },
    { course: 'CS 350', grade: 92, credits: 4 },
  ];

  const gradeDistribution = [
    { grade: 'A/A+', count: 12, percentage: 48 },
    { grade: 'A-', count: 5, percentage: 20 },
    { grade: 'B+', count: 4, percentage: 16 },
    { grade: 'B', count: 3, percentage: 12 },
    { grade: 'B-', count: 1, percentage: 4 },
  ];

  const studyHours = [
    { week: 'Week 1', hours: 15 },
    { week: 'Week 2', hours: 18 },
    { week: 'Week 3', hours: 22 },
    { week: 'Week 4', hours: 20 },
    { week: 'Week 5', hours: 25 },
    { week: 'Week 6', hours: 23 },
  ];

  const categoryPerformance = [
    { category: 'Core CS', value: 92 },
    { category: 'Mathematics', value: 88 },
    { category: 'Gen Ed', value: 90 },
    { category: 'Electives', value: 95 },
  ];

  const COLORS = ['#3b82f6', '#8b5cf6', '#10b981', '#f59e0b', '#ef4444'];

  const currentGPA = 3.75;
  const previousGPA = 3.8;
  const gpaChange = currentGPA - previousGPA;
  const targetGPA = 3.8;

  return (
    <div className="space-y-6">
      {/* Summary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Current GPA</p>
              <p className="text-3xl font-semibold text-gray-900 mt-1">{currentGPA}</p>
              <div className="flex items-center gap-1 mt-2">
                {gpaChange >= 0 ? (
                  <TrendingUp className="size-4 text-green-500" />
                ) : (
                  <TrendingDown className="size-4 text-red-500" />
                )}
                <span className={`text-sm ${gpaChange >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                  {Math.abs(gpaChange).toFixed(2)}
                </span>
              </div>
            </div>
            <Award className="size-10 text-blue-600" />
          </div>
        </div>

        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Target GPA</p>
              <p className="text-3xl font-semibold text-gray-900 mt-1">{targetGPA}</p>
              <p className="text-sm text-gray-600 mt-2">
                {(targetGPA - currentGPA).toFixed(2)} to go
              </p>
            </div>
            <Target className="size-10 text-purple-600" />
          </div>
        </div>

        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Avg Study Hours/Week</p>
              <p className="text-3xl font-semibold text-gray-900 mt-1">20.5</p>
              <p className="text-sm text-green-600 mt-2">+2.5 from last month</p>
            </div>
            <Calendar className="size-10 text-green-600" />
          </div>
        </div>

        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Course Average</p>
              <p className="text-3xl font-semibold text-gray-900 mt-1">91%</p>
              <p className="text-sm text-green-600 mt-2">Excellent</p>
            </div>
            <BookOpen className="size-10 text-orange-600" />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* GPA Trend */}
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h3 className="font-semibold text-gray-900 mb-4">GPA Trend</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={gpaData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="semester" />
              <YAxis domain={[0, 4.0]} />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="gpa" stroke="#3b82f6" strokeWidth={2} name="GPA" />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Current Course Performance */}
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h3 className="font-semibold text-gray-900 mb-4">Current Course Performance</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={coursePerformance}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="course" />
              <YAxis domain={[0, 100]} />
              <Tooltip />
              <Legend />
              <Bar dataKey="grade" fill="#3b82f6" name="Grade %" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Grade Distribution */}
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h3 className="font-semibold text-gray-900 mb-4">Overall Grade Distribution</h3>
          <div className="flex items-center gap-8">
            <ResponsiveContainer width="50%" height={250}>
              <PieChart>
                <Pie
                  data={gradeDistribution}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ grade }) => grade}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="count"
                >
                  {gradeDistribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
            <div className="flex-1 space-y-2">
              {gradeDistribution.map((item, index) => (
                <div key={index} className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div
                      className="size-4 rounded"
                      style={{ backgroundColor: COLORS[index % COLORS.length] }}
                    />
                    <span className="text-sm text-gray-700">{item.grade}</span>
                  </div>
                  <span className="text-sm font-medium text-gray-900">
                    {item.count} ({item.percentage}%)
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Study Hours */}
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h3 className="font-semibold text-gray-900 mb-4">Weekly Study Hours</h3>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={studyHours}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="week" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="hours" fill="#10b981" name="Hours" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Category Performance */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h3 className="font-semibold text-gray-900 mb-4">Performance by Category</h3>
        <div className="space-y-4">
          {categoryPerformance.map((item, index) => (
            <div key={index}>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-gray-700">{item.category}</span>
                <span className="text-sm font-semibold text-gray-900">{item.value}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-3">
                <div
                  className="bg-blue-600 h-3 rounded-full transition-all"
                  style={{ width: `${item.value}%` }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Insights */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h3 className="font-semibold text-gray-900 mb-4">Performance Insights</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 bg-green-50 rounded-lg border border-green-200">
            <div className="flex items-start gap-3">
              <TrendingUp className="size-5 text-green-600 mt-0.5" />
              <div>
                <p className="font-medium text-green-900">Strong Performance</p>
                <p className="text-sm text-green-700 mt-1">
                  Your electives average is 95%, showing excellent engagement in specialized topics.
                </p>
              </div>
            </div>
          </div>

          <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
            <div className="flex items-start gap-3">
              <Award className="size-5 text-blue-600 mt-0.5" />
              <div>
                <p className="font-medium text-blue-900">Consistent Achiever</p>
                <p className="text-sm text-blue-700 mt-1">
                  You've maintained a GPA above 3.7 for the past 3 semesters.
                </p>
              </div>
            </div>
          </div>

          <div className="p-4 bg-orange-50 rounded-lg border border-orange-200">
            <div className="flex items-start gap-3">
              <Target className="size-5 text-orange-600 mt-0.5" />
              <div>
                <p className="font-medium text-orange-900">Goal Focus</p>
                <p className="text-sm text-orange-700 mt-1">
                  Increase study time by 3 hours/week to reach your target GPA of 3.8.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
