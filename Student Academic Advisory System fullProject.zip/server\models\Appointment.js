const mongoose = require('mongoose');

const AppointmentSchema = new mongoose.Schema({
    studentId: { type: mongoose.Schema.Types.ObjectId, ref: 'Student', required: true },
    advisorName: { type: String, required: true },
    date: { type: String, required: true }, // Keeping string for simplicity to match frontend 'YYYY-MM-DD' or ISO
    time: { type: String, required: true },
    topic: { type: String, required: true }, // Changed 'purpose' to 'topic' to match frontend store if needed, or map it.
    // Frontend uses: id, advisorName, date, time, topic, status, type
    type: { type: String, enum: ['in-person', 'virtual'], default: 'virtual' },
    status: { type: String, enum: ['pending', 'confirmed', 'cancelled', 'completed'], default: 'confirmed' }
});

module.exports = mongoose.model('Appointment', AppointmentSchema);
