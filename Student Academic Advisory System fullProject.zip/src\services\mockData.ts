import { Student, Course, EnrolledCourse, Notification, Appointment, TranscriptEntry, StudyGroup } from '../types';
import { addDays, format } from 'date-fns';

// --- Courses Data ---
export const MOCK_COURSES: Course[] = [
    {
        id: '1', code: 'CS 450', name: 'Machine Learning', credits: 3, instructor: 'Dr. Sarah Williams',
        schedule: 'Mon/Wed 2:00 PM - 3:30 PM', location: 'Building A, Room 301', capacity: 40, enrolled: 35,
        semester: 'Fall 2026', status: 'open', rating: 4.7, prerequisites: ['CS 340', 'STAT 301'],
        syllabus: 'https://example.com/syllabus/cs450.pdf'
    },
    {
        id: '2', code: 'CS 460', name: 'Computer Graphics', credits: 3, instructor: 'Prof. Michael Chen',
        schedule: 'Tue/Thu 10:00 AM - 11:30 AM', location: 'Building C, Room 205', capacity: 35, enrolled: 32,
        semester: 'Fall 2026', status: 'open', rating: 4.5, prerequisites: ['CS 301', 'MATH 201']
    },
    {
        id: '3', code: 'CS 470', name: 'Cloud Computing', credits: 3, instructor: 'Dr. Jennifer Lee',
        schedule: 'Mon/Wed 4:00 PM - 5:30 PM', location: 'Building B, Room 110', capacity: 30, enrolled: 30,
        semester: 'Fall 2026', status: 'waitlist', rating: 4.8, prerequisites: ['CS 350']
    },
    {
        id: '4', code: 'CS 480', name: 'Mobile App Development', credits: 3, instructor: 'Prof. David Kumar',
        schedule: 'Tue/Thu 1:00 PM - 2:30 PM', location: 'Building D, Room 150', capacity: 25, enrolled: 25,
        semester: 'Fall 2026', status: 'closed', rating: 4.9, prerequisites: ['CS 320']
    },
    {
        id: '5', code: 'CS 301', name: 'Data Structures', credits: 3, instructor: 'Dr. Emily Chen',
        schedule: 'Mon/Wed 10:00 AM - 11:30 AM', location: 'Building A, Room 201', capacity: 60, enrolled: 55,
        semester: 'Spring 2026', status: 'closed', rating: 4.6
    },
    {
        id: '6', code: 'CS 305', name: 'Database Systems', credits: 4, instructor: 'Prof. Michael Torres',
        schedule: 'Tue/Thu 2:00 PM - 3:45 PM', location: 'Building B, Room 105', capacity: 50, enrolled: 45,
        semester: 'Spring 2026', status: 'open', rating: 4.4
    },
    {
        id: '7', code: 'CS 320', name: 'Web Development', credits: 3, instructor: 'Dr. Sarah Martinez',
        schedule: 'Mon/Wed 1:00 PM - 2:30 PM', location: 'Building C, Room 310', capacity: 40, enrolled: 38,
        semester: 'Spring 2026', status: 'open', rating: 4.8
    },
    {
        id: '8', code: 'CS 340', name: 'Algorithms', credits: 3, instructor: 'Prof. David Kim',
        schedule: 'Tue/Thu 10:00 AM - 11:30 AM', location: 'Building A, Room 150', capacity: 50, enrolled: 48,
        semester: 'Spring 2026', status: 'open', rating: 4.5
    },
    {
        id: '9', code: 'CS 350', name: 'Operating Systems', credits: 4, instructor: 'Dr. Jennifer Lee',
        schedule: 'Mon/Wed/Fri 9:00 AM - 10:00 AM', location: 'Building D, Room 220', capacity: 40, enrolled: 35,
        semester: 'Spring 2026', status: 'open', rating: 4.6
    },
    {
        id: '10', code: 'MATH 201', name: 'Linear Algebra', credits: 3, instructor: 'Prof. Alan Turing',
        schedule: 'Tue/Thu 1:00 PM - 2:30 PM', location: 'Science Hall, Room 101', capacity: 50, enrolled: 12,
        semester: 'Fall 2026', status: 'open', rating: 4.2
    },
    {
        id: '11', code: 'PHYS 101', name: 'Physics I: Mechanics', credits: 4, instructor: 'Dr. Marie Curie',
        schedule: 'Mon/Wed 11:00 AM - 12:30 PM', location: 'Physics Lab, Room 2B', capacity: 30, enrolled: 5,
        semester: 'Fall 2026', status: 'open', rating: 4.9
    },
    {
        id: '12', code: 'ART 105', name: 'Digital Art Fundamentals', credits: 3, instructor: 'Prof. Bob Ross',
        schedule: 'Fri 2:00 PM - 5:00 PM', location: 'Arts Center, Studio 4', capacity: 20, enrolled: 18,
        semester: 'Fall 2026', status: 'open', rating: 5.0
    },
    {
        id: '13', code: 'HIST 220', name: 'Modern World History', credits: 3, instructor: 'Dr. Indiana Jones',
        schedule: 'Tue/Thu 4:00 PM - 5:30 PM', location: 'Humanities, Room 112', capacity: 60, enrolled: 45,
        semester: 'Fall 2026', status: 'open', rating: 4.7
    },
    {
        id: '14', code: 'BUS 301', name: 'Principles of Marketing', credits: 3, instructor: 'Prof. Don Draper',
        schedule: 'Mon/Wed 3:00 PM - 4:30 PM', location: 'Business School, Room 305', capacity: 45, enrolled: 20,
        semester: 'Fall 2026', status: 'open', rating: 4.4
    }
];

// --- Student Data ---
export const MOCK_STUDENT: Student = {
    id: 'u1',
    name: 'Sarah Johnson',
    email: 'sarah.j@university.edu',
    role: 'student',
    avatar: 'SJ',
    studentId: '2024-CS-1234',
    gpa: 3.75,
    major: 'Computer Science',
    creditsEarned: 87,
    totalCreditsRequired: 120,
    startYear: 2023,
    expectedGraduation: 'Spring 2027',
    advisor: 'Dr. Robert Anderson'
};

// --- Enrolled Courses (Spring 2026) ---
export const MOCK_ENROLLED_COURSES: EnrolledCourse[] = [
    { ...MOCK_COURSES[4], grade: 'A-', progress: 65, enrollmentDate: '2025-11-15', id: '5' }, // Data Structures
    { ...MOCK_COURSES[5], grade: 'A', progress: 58, enrollmentDate: '2025-11-15', id: '6' },   // Database Systems
    { ...MOCK_COURSES[6], grade: 'A+', progress: 72, enrollmentDate: '2025-11-16', id: '7' },  // Web Dev
    { ...MOCK_COURSES[7], grade: 'B+', progress: 60, enrollmentDate: '2025-11-16', id: '8' },  // Algorithms
    { ...MOCK_COURSES[8], grade: 'A', progress: 70, enrollmentDate: '2025-11-17', id: '9' },   // OS
];

// --- Transcript ---
export const MOCK_TRANSCRIPT: TranscriptEntry[] = [
    { courseId: '101', courseCode: 'CS 101', courseName: 'Intro to Programming', semester: 'Fall 2023', grade: 'A', credits: 4, qualityPoints: 16 },
    { courseId: '102', courseCode: 'MATH 101', courseName: 'Calculus I', semester: 'Fall 2023', grade: 'B+', credits: 4, qualityPoints: 13.2 },
    { courseId: '103', courseCode: 'ENG 101', courseName: 'Composition I', semester: 'Fall 2023', grade: 'A-', credits: 3, qualityPoints: 11.1 },
    // ... more history
];

// --- Notifications ---
export const MOCK_NOTIFICATIONS: Notification[] = [
    { id: '1', title: 'Registration Open', message: 'Fall 2026 registration is now open.', date: format(new Date(), 'yyyy-MM-dd'), read: false, type: 'info' },
    { id: '2', title: 'Grade Posted', message: 'Midterm grade posted for CS 350.', date: format(addDays(new Date(), -1), 'yyyy-MM-dd'), read: false, type: 'success' },
];

// --- Appointments ---
export const MOCK_APPOINTMENTS: Appointment[] = [
    {
        id: '1', advisorId: 'adv1', advisorName: 'Dr. Robert Anderson',
        date: format(addDays(new Date(), 2), 'yyyy-MM-dd'), time: '2:30 PM',
        purpose: 'Course Selection', status: 'confirmed', type: 'in-person'
    }
];

// --- Study Groups ---
export const MOCK_STUDY_GROUPS: StudyGroup[] = [
    {
        id: '1',
        name: 'Data Structures Mastery',
        course: 'CS 301',
        members: 5,
        maxMembers: 8,
        schedule: 'Tuesdays & Thursdays, 6:00 PM',
        location: 'Library, Room 203',
        nextMeeting: '2026-02-06',
        description: 'Focused on solving complex data structure problems and preparing for exams.',
        organizer: 'Alex Chen',
        isJoined: true
    },
    {
        id: '2',
        name: 'Web Dev Workshop',
        course: 'CS 320',
        members: 6,
        maxMembers: 10,
        schedule: 'Mondays, 5:00 PM',
        location: 'Student Center, Room 102',
        nextMeeting: '2026-02-10',
        description: 'Building real-world web applications together. Covering React, Node.js, and databases.',
        organizer: 'James Wilson',
        isJoined: false
    },
    {
        id: '3',
        name: 'Algorithm Study Circle',
        course: 'CS 340',
        members: 4,
        maxMembers: 6,
        schedule: 'Wednesdays, 7:00 PM',
        location: 'Online (Zoom)',
        nextMeeting: '2026-02-12',
        description: 'Weekly algorithm challenges and whiteboard practice for technical interviews.',
        organizer: 'Sarah Martinez',
        isJoined: true
    },
    {
        id: '4',
        name: 'Database Design & SQL',
        course: 'CS 305',
        members: 7,
        maxMembers: 8,
        schedule: 'Fridays, 4:00 PM',
        location: 'Computer Lab 2',
        nextMeeting: '2026-02-07',
        description: 'Hands-on practice with database design, normalization, and complex SQL queries.',
        organizer: 'Emily Zhang',
        isJoined: false
    },
];

// --- Deadlines ---
export const MOCK_DEADLINES: Deadline[] = [
    { id: '1', title: 'Machine Learning Project Proposal', courseCode: 'CS 450', dueDate: format(addDays(new Date(), 3), 'yyyy-MM-dd'), type: 'project' },
    { id: '2', title: 'Midterm Exam', courseCode: 'CS 460', dueDate: format(addDays(new Date(), 5), 'yyyy-MM-dd'), type: 'exam' },
    { id: '3', title: 'Weekly Quiz 4', courseCode: 'CS 470', dueDate: format(addDays(new Date(), 2), 'yyyy-MM-dd'), type: 'assignment' },
];
