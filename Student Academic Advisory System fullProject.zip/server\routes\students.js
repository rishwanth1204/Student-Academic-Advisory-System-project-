const express = require('express');
const router = express.Router();
const { getProfile, updateProfile, getTranscript } = require('../controllers/studentController');
const { protect } = require('../middleware/authMiddleware');

router.get('/profile', protect, getProfile);
router.put('/profile', protect, updateProfile);
router.get('/transcript', protect, getTranscript);

module.exports = router;
