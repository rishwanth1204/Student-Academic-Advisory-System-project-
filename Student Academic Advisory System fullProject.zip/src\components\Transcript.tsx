import { Download, Printer, Share2, Award, TrendingUp } from 'lucide-react';
import { useStudentStore } from '../store/useStudentStore';
import { useAuthStore } from '../store/useAuthStore';

// Helper to group flat transcript entries by semester
const groupTranscriptBySemester = (transcript: any[]) => {
  const grouped: Record<string, any> = {};

  transcript.forEach(entry => {
    if (!grouped[entry.semester]) {
      grouped[entry.semester] = {
        semester: entry.semester,
        courses: [],
        semesterPoints: 0,
        semesterCredits: 0
      };
    }
    grouped[entry.semester].courses.push(entry);
    grouped[entry.semester].semesterPoints += entry.qualityPoints;
    grouped[entry.semester].semesterCredits += entry.credits;
  });

  // Convert to array and calculate GPAs
  let runningPoints = 0;
  let runningCredits = 0;

  return Object.values(grouped).map((sem: any) => {
    runningPoints += sem.semesterPoints;
    runningCredits += sem.semesterCredits;
    return {
      ...sem,
      semesterGPA: sem.semesterCredits > 0 ? sem.semesterPoints / sem.semesterCredits : 0,
      cumulativeGPA: runningCredits > 0 ? runningPoints / runningCredits : 0
    };
  });
};

export function Transcript() {
  const { user } = useAuthStore();
  const { transcript, calculateGPA, getTotalCredits } = useStudentStore();
  const student = user && 'studentId' in user ? user : null;

  const groupedTranscript = groupTranscriptBySemester(transcript);
  const currentGPA = calculateGPA();
  const totalCredits = getTotalCredits();

  // Sort semesters (Mock logic - in real app sort by date)
  // For now we just trust the mock order or if needed reverse/sort

  const gradeScale = [
    { grade: 'A+', points: 4.0 }, { grade: 'A', points: 4.0 }, { grade: 'A-', points: 3.7 },
    { grade: 'B+', points: 3.3 }, { grade: 'B', points: 3.0 }, { grade: 'B-', points: 2.7 },
    { grade: 'C+', points: 2.3 }, { grade: 'C', points: 2.0 }, { grade: 'C-', points: 1.7 },
    { grade: 'D', points: 1.0 }, { grade: 'F', points: 0.0 }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-semibold text-gray-900">Official Transcript</h2>
            <p className="text-sm text-gray-500 mt-1">Academic Record Summary</p>
          </div>
          <div className="flex gap-2">
            <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium flex items-center gap-2">
              <Download className="size-4" />
              Download PDF
            </button>
            <button className="px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors text-sm font-medium">
              <Printer className="size-4" />
            </button>
            <button className="px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors text-sm font-medium">
              <Share2 className="size-4" />
            </button>
          </div>
        </div>

        {/* Student Info */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 p-4 bg-gray-50 rounded-lg">
          <div>
            <p className="text-xs text-gray-500">Student Name</p>
            <p className="font-medium text-gray-900">{student?.name || 'N/A'}</p>
          </div>
          <div>
            <p className="text-xs text-gray-500">Student ID</p>
            <p className="font-medium text-gray-900">{student?.studentId || 'N/A'}</p>
          </div>
          <div>
            <p className="text-xs text-gray-500">Major</p>
            <p className="font-medium text-gray-900">{student?.major || 'N/A'}</p>
          </div>
          <div>
            <p className="text-xs text-gray-500">Credits Earned</p>
            <p className="font-medium text-gray-900">{student?.creditsEarned || 0}</p>
          </div>
          <div>
            <p className="text-xs text-gray-500">Start Year</p>
            <p className="font-medium text-gray-900">{student?.startYear || 'N/A'}</p>
          </div>
          <div>
            <p className="text-xs text-gray-500">Expected Graduation</p>
            <p className="font-medium text-gray-900">{student?.expectedGraduation || 'N/A'}</p>
          </div>
        </div>
      </div>

      {/* GPA Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="flex items-center gap-3">
            <Award className="size-10 text-blue-600" />
            <div>
              <p className="text-3xl font-semibold text-gray-900">{currentGPA.toFixed(2)}</p>
              <p className="text-sm text-gray-500">Cumulative GPA</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="flex items-center gap-3">
            <TrendingUp className="size-10 text-green-600" />
            <div>
              <p className="text-3xl font-semibold text-gray-900">{totalCredits}</p>
              <p className="text-sm text-gray-500">Total Credits Earned</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="flex items-center gap-3">
            {/* Dynamic highest semester calculation */}
            <Award className="size-10 text-purple-600" />
            <div>
              <p className="text-3xl font-semibold text-gray-900">
                {Math.max(...groupedTranscript.map((t: any) => t.semesterGPA), 0).toFixed(2)}
              </p>
              <p className="text-sm text-gray-500">Highest Semester GPA</p>
            </div>
          </div>
        </div>
      </div>

      {/* Academic History */}
      <div className="space-y-6">
        {groupedTranscript.map((record: any, index: number) => (
          <div key={index} className="bg-white rounded-lg border border-gray-200 overflow-hidden">
            <div className="bg-gray-50 px-6 py-4 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold text-gray-900">{record.semester}</h3>
                <div className="flex items-center gap-6 text-sm">
                  <div>
                    <span className="text-gray-500">Semester GPA: </span>
                    <span className="font-semibold text-gray-900">{record.semesterGPA.toFixed(2)}</span>
                  </div>
                  <div>
                    <span className="text-gray-500">Cumulative GPA: </span>
                    <span className="font-semibold text-gray-900">{record.cumulativeGPA.toFixed(2)}</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-200 bg-gray-50 text-sm">
                    <th className="px-6 py-3 text-left font-medium text-gray-700">Course Code</th>
                    <th className="px-6 py-3 text-left font-medium text-gray-700">Course Name</th>
                    <th className="px-6 py-3 text-center font-medium text-gray-700">Credits</th>
                    <th className="px-6 py-3 text-center font-medium text-gray-700">Grade</th>
                    <th className="px-6 py-3 text-center font-medium text-gray-700">Grade Points</th>
                  </tr>
                </thead>
                <tbody>
                  {record.courses.map((course: any, courseIndex: number) => (
                    <tr key={courseIndex} className="border-b border-gray-100 hover:bg-gray-50">
                      <td className="px-6 py-4 text-sm font-medium text-gray-900">{course.courseCode}</td>
                      <td className="px-6 py-4 text-sm text-gray-700">{course.courseName}</td>
                      <td className="px-6 py-4 text-sm text-center text-gray-700">{course.credits}</td>
                      <td className="px-6 py-4 text-center">
                        <span className={`inline-block px-3 py-1 rounded-full text-sm font-medium ${course.qualityPoints / course.credits >= 3.0 ? 'bg-green-100 text-green-700' :
                            course.qualityPoints / course.credits >= 2.0 ? 'bg-yellow-100 text-yellow-700' :
                              'bg-orange-100 text-orange-700'
                          }`}>
                          {course.grade}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-sm text-center text-gray-700">{course.qualityPoints.toFixed(1)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        ))}
      </div>

      {/* Grade Scale */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h3 className="font-semibold text-gray-900 mb-4">Grading Scale</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
          {gradeScale.map((item, index) => (
            <div key={index} className="p-3 bg-gray-50 rounded-lg text-center">
              <p className="font-semibold text-gray-900">{item.grade}</p>
              <p className="text-sm text-gray-600">{item.points.toFixed(1)}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Footer Note */}
      <div className="bg-gray-50 rounded-lg p-4 border border-gray-200">
        <p className="text-xs text-gray-600 text-center">
          This is an unofficial transcript for student reference only. For official transcripts, please contact the Registrar's Office.
          Generated on {new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}.
        </p>
      </div>
    </div>
  );
}
