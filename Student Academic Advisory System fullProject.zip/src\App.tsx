import { useState, useEffect } from 'react';
import { Routes, Route, Navigate, NavLink, useLocation, useNavigate } from 'react-router-dom';
import { LayoutDashboard, BookOpen, User, Calendar as CalendarIcon, TrendingUp, Library, BarChart3, Users, Award, Briefcase, ClipboardList, Trophy, FileText, Bell, LogOut, Clock } from 'lucide-react';
import { useAuthStore } from './store/useAuthStore';
import { Dashboard } from './components/Dashboard';
import { Courses } from './components/Courses';
import { Advisor } from './components/Advisor';
import { Appointments } from './components/Appointments';
import { Progress } from './components/Progress';
import { Calendar } from './components/Calendar';
import { Resources } from './components/Resources';
import { Analytics } from './components/Analytics';
import { Tutoring } from './components/Tutoring';
import { Scholarships } from './components/Scholarships';
import { StudyGroups } from './components/StudyGroups';
import { Career } from './components/Career';
import { Registration } from './components/Registration';
import { Achievements } from './components/Achievements';
import { Transcript } from './components/Transcript';
import { Notifications } from './components/Notifications';
import { CourseDetails } from './components/CourseDetails';
import { Profile } from './components/Profile';
import { Login } from './pages/Login';
import { ProtectedRoute } from './components/ProtectedRoute';
import { ChatWidget } from './components/ChatWidget';
import { Toaster } from 'sonner';

export default function App() {
  const [notificationCount] = useState(5);
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const location = useLocation();
  const navigate = useNavigate(); // Add navigate hook
  const { user, logout } = useAuthStore();
  const student = user && 'studentId' in user ? user : null;

  const tabs = [
    { label: 'Dashboard', icon: LayoutDashboard, path: '/dashboard' },
    { label: 'Courses', icon: BookOpen, path: '/courses' },
    { label: 'Analytics', icon: BarChart3, path: '/analytics' },
    { label: 'Progress', icon: TrendingUp, path: '/progress' },
    { label: 'Calendar', icon: CalendarIcon, path: '/calendar' },
    { label: 'Registration', icon: ClipboardList, path: '/registration' },
    { label: 'Advisor', icon: User, path: '/advisor' },
    { label: 'Appointments', icon: CalendarIcon, path: '/appointments' },
    { label: 'Resources', icon: Library, path: '/resources' },
    { label: 'Tutoring', icon: Users, path: '/tutoring' },
    { label: 'Study Groups', icon: Users, path: '/study-groups' },
    { label: 'Career', icon: Briefcase, path: '/career' },
    { label: 'Scholarships', icon: Award, path: '/scholarships' },
    { label: 'Achievements', icon: Trophy, path: '/achievements' },
    { label: 'Transcript', icon: FileText, path: '/transcript' },
  ];

  // If on login page, render only that
  if (location.pathname === '/login') {
    return (
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="*" element={<Navigate to="/login" replace />} />
      </Routes>
    );
  }

  // Debugging: Log render
  console.log('App rendering, student:', student);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-md border-b border-gray-200 transition-all duration-300">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center cursor-pointer" onClick={() => navigate('/dashboard')}>
              <BookOpen className="size-8 text-blue-600" />
              <h1 className="ml-3 font-semibold text-gray-900">Academic Advisory System</h1>
            </div>

            {/* Live Clock in Header */}
            <div className="hidden md:flex items-center gap-2 px-4 py-1.5 bg-gray-50 rounded-full border border-gray-200 ml-6">
              <Clock className="size-4 text-blue-600" />
              <span className="text-sm font-medium text-gray-700 tabular-nums">
                {currentTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </span>
              <span className="text-xs text-gray-400">|</span>
              <span className="text-xs font-medium text-gray-500">
                {currentTime.toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}
              </span>
            </div>

            <div className="flex items-center gap-4">
              <button
                className="relative p-2 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-100"
              >
                <Bell className="size-6" />
                {notificationCount > 0 && (
                  <span className="absolute top-1 right-1 size-4 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
                    {notificationCount}
                  </span>
                )}
              </button>
              <div className="flex items-center gap-3 cursor-pointer hover:bg-gray-50 p-2 rounded-lg transition-colors" onClick={() => navigate('/profile')}>
                <div className="text-right">
                  <p className="text-sm font-medium text-gray-900">{student?.name || 'Student'}</p>
                  <p className="text-xs text-gray-500">Student ID: {student?.studentId || 'N/A'}</p>
                </div>
                <div className="size-10 rounded-full bg-blue-100 flex items-center justify-center">
                  <span className="text-blue-600 font-medium">{student?.avatar || 'ST'}</span>
                </div>
              </div>
              <button
                onClick={(e) => { e.stopPropagation(); logout(); }}
                className="p-2 text-gray-400 hover:text-red-600 rounded-lg hover:bg-red-50 ml-2"
                title="Sign Out"
              >
                <LogOut className="size-5" />
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation */}
      {/* Navigation */}
      <nav className="bg-white/90 backdrop-blur-sm border-b border-gray-200 overflow-x-auto shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex gap-6">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <NavLink
                  key={tab.path}
                  to={tab.path}
                  className={({ isActive }) => `flex items-center gap-2 px-1 py-4 border-b-2 transition-colors whitespace-nowrap ${isActive
                    ? 'border-blue-600 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                    }`}
                >
                  <Icon className="size-5" />
                  <span className="font-medium text-sm">{tab.label}</span>
                </NavLink>
              );
            })}
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Routes>
          <Route element={<ProtectedRoute />}>
            <Route path="/" element={<Navigate to="/dashboard" replace />} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/courses" element={<Courses />} />
            <Route path="/courses/:id" element={<CourseDetails />} />
            <Route path="/profile" element={<Profile />} />
            <Route path="/advisor" element={<Advisor />} />
            <Route path="/appointments" element={<Appointments />} />
            <Route path="/progress" element={<Progress />} />
            <Route path="/calendar" element={<Calendar />} />
            <Route path="/resources" element={<Resources />} />
            <Route path="/analytics" element={<Analytics />} />
            <Route path="/tutoring" element={<Tutoring />} />
            <Route path="/scholarships" element={<Scholarships />} />
            <Route path="/study-groups" element={<StudyGroups />} />
            <Route path="/career" element={<Career />} />
            <Route path="/registration" element={<Registration />} />
            <Route path="/achievements" element={<Achievements />} />
            <Route path="/transcript" element={<Transcript />} />
            <Route path="/notifications" element={<Notifications />} />
          </Route>
          <Route path="*" element={<Navigate to="/dashboard" replace />} />
        </Routes>
      </main>
      <ChatWidget /> {/* Add to layout */}
      <Toaster position="top-right" />
    </div>
  );
}