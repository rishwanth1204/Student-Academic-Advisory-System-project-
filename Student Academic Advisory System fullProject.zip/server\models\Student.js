const mongoose = require('mongoose');

const TranscriptEntrySchema = new mongoose.Schema({
    courseId: String,
    code: String,
    courseName: String,
    credits: Number,
    grade: String,
    qualityPoints: Number,
    semester: String
});

const EnrolledCourseSchema = new mongoose.Schema({
    courseId: { type: mongoose.Schema.Types.ObjectId, ref: 'Course' },
    code: String,
    name: String,
    credits: Number,
    progress: { type: Number, default: 0 },
    enrollmentDate: Date,
    semester: String,
    grade: String
});

const StudentSchema = new mongoose.Schema({
    studentId: { type: String, required: true, unique: true },
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    name: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    advisor: { type: String, default: 'Unassigned' },
    major: { type: String, default: 'Computer Science' },
    gpa: { type: Number, default: 0.0 },
    creditsEarned: { type: Number, default: 0 },
    totalCreditsRequired: { type: Number, default: 120 },
    expectedGraduation: String,
    transcript: [TranscriptEntrySchema],
    enrolledCourses: [EnrolledCourseSchema],
    notifications: [{
        title: String,
        message: String,
        date: { type: Date, default: Date.now },
        read: { type: Boolean, default: false },
        type: { type: String, enum: ['info', 'warning', 'success', 'alert'] }
    }]
}, { timestamps: true });

module.exports = mongoose.model('Student', StudentSchema);
