const User = require('../models/User');
const Student = require('../models/Student');
const jwt = require('jsonwebtoken');
const { users, students } = require('../data/mockData');

// Generate JWT Token
const generateToken = (id) => {
    return jwt.sign({ id }, process.env.JWT_SECRET, { expiresIn: '30d' });
};

// @desc    Register a new student
// @route   POST /api/auth/register
// @access  Public
exports.register = async (req, res, next) => {
    try {
        const { name, email, password } = req.body;

        // Check if user exists
        // const userExists = await User.findOne({ email });
        const userExists = users.find(u => u.email === email);
        if (userExists) {
            return res.status(400).json({ message: 'User already exists' });
        }

        // Create User
        // const user = await User.create({ ... });
        const user = {
            _id: Date.now().toString(),
            name,
            email,
            password, // In a real app, hash this!
            role: 'student',
            matchPassword: async function (enteredPassword) {
                return enteredPassword === this.password;
            }
        };
        users.push(user);


        // Create linked Student profile
        // const student = await Student.create({ ... });
        const student = {
            _id: Math.floor(100000 + Math.random() * 900000).toString(),
            studentId: Math.floor(100000 + Math.random() * 900000).toString(), // Generate random ID
            userId: user._id,
            name: user.name,
            email: user.email,
            major: 'Computer Science', // Default
            advisor: 'Unassigned',
            enrolledCourses: [],
            transcript: [],
            save: async function () { return this; } // Mock save function
        };
        students.push(student);

        res.status(201).json({
            token: generateToken(user._id),
            user: {
                id: user._id,
                name: user.name,
                email: user.email,
                role: user.role,
                studentId: student.studentId
            }
        });
    } catch (err) {
        next(err);
    }
};

// @desc    Login user
// @route   POST /api/auth/login
// @access  Public
exports.login = async (req, res, next) => {
    try {
        const { email, password } = req.body;

        // Check for user
        // const user = await User.findOne({ email });
        const user = users.find(u => u.email === email);

        if (!user) {
            return res.status(401).json({ message: 'Invalid credentials' });
        }

        // Check password
        // const isMatch = await user.matchPassword(password);
        const isMatch = password === user.password; // Simple comparison for mock

        if (!isMatch) {
            return res.status(401).json({ message: 'Invalid credentials' });
        }

        // Find associated Student profile
        // const student = await Student.findOne({ userId: user._id });
        const student = students.find(s => s.userId === user._id);

        res.json({
            token: generateToken(user._id),
            user: {
                id: user._id,
                name: user.name,
                email: user.email,
                role: user.role,
                studentId: student ? student.studentId : null
            }
        });
    } catch (err) {
        next(err);
    }
};
