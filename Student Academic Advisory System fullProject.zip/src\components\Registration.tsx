import { useState, useEffect } from 'react';
import { Search, Plus, Minus, Calendar, Users, Clock, AlertCircle, Loader2 } from 'lucide-react';
import { useStudentStore } from '../store/useStudentStore';
import { toast } from 'sonner';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '../components/ui/accordion';

export function Registration() {
  const [searchQuery, setSearchQuery] = useState('');
  const [cart, setCart] = useState<string[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const { availableCourses, enrolledCourses, registerCourse, fetchCourses } = useStudentStore();

  useEffect(() => {
    fetchCourses();
  }, [fetchCourses]);

  const filteredCourses = availableCourses.filter(course =>
    course.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
    course.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    course.instructor.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const cartCourses = availableCourses.filter(course => cart.includes(course.id));
  const totalCredits = cartCourses.reduce((sum, course) => sum + course.credits, 0);

  const toggleCourse = (courseId: string) => {
    if (enrolledCourses.some(c => c.id === courseId)) return;
    if (cart.includes(courseId)) {
      setCart(cart.filter(id => id !== courseId));
    } else {
      setCart([...cart, courseId]);
    }
  };

  const handleSubmit = async () => {
    setIsSubmitting(true);
    try {
      for (const courseId of cart) {
        await registerCourse(courseId);
      }
      setCart([]);
      toast.success('Successfully registered for courses!');
    } catch (error) {
      console.error('Registration failed', error);
      toast.error('Registration failed. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'open':
        return <span className="px-2 py-1 bg-green-100 text-green-700 rounded text-xs font-medium">Open</span>;
      case 'waitlist':
        return <span className="px-2 py-1 bg-yellow-100 text-yellow-700 rounded text-xs font-medium">Waitlist</span>;
      case 'closed':
        return <span className="px-2 py-1 bg-red-100 text-red-700 rounded text-xs font-medium">Closed</span>;
      default:
        return null;
    }
  };

  // Group courses by Subject Code (e.g. CS, MATH)
  const groupedCourses: Record<string, typeof availableCourses> = {};
  filteredCourses.forEach(course => {
    const subject = course.code.split(' ')[0];
    if (!groupedCourses[subject]) groupedCourses[subject] = [];
    groupedCourses[subject].push(course);
  });

  return (
    <div className="space-y-6">
      {/* Registration Period */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-semibold">Fall 2026 Registration</h2>
            <p className="text-blue-100 mt-2">Registration Period: February 15 - March 1, 2026</p>
          </div>
          <div className="text-right">
            <p className="text-sm text-blue-100">Your Registration Time</p>
            <p className="text-xl font-semibold mt-1">Feb 17, 9:00 AM</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Course Search */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white rounded-lg border border-gray-200 p-6">
            <h3 className="font-semibold text-gray-900 mb-4">Available Courses</h3>

            <div className="relative mb-4">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 size-5 text-gray-400" />
              <input
                type="text"
                placeholder="Search by code, name, or instructor..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <Accordion type="multiple" className="w-full space-y-4">
              {Object.keys(groupedCourses).map(subject => (
                <AccordionItem key={subject} value={subject} className="border rounded-lg px-4 border-gray-200">
                  <AccordionTrigger className="hover:no-underline">
                    <span className="font-semibold text-lg">{subject} Courses ({groupedCourses[subject].length})</span>
                  </AccordionTrigger>
                  <AccordionContent className="pt-2 pb-4 space-y-4">
                    {groupedCourses[subject].map(course => {
                      const isSelected = cart.includes(course.id);
                      const isEnrolled = enrolledCourses.some(c => c.id === course.id);
                      const isFull = (course.capacity - course.enrolled) <= 0;

                      return (
                        <div
                          key={course.id}
                          className={`p-4 border rounded-lg transition-all ${isSelected
                            ? 'border-blue-500 bg-blue-50'
                            : isEnrolled
                              ? 'border-green-200 bg-green-50 opacity-90'
                              : 'border-gray-200'
                            }`}
                        >
                          <div className="flex items-start justify-between mb-2">
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-1">
                                <h4 className="font-semibold text-gray-900">{course.code}</h4>
                                {getStatusBadge(course.status)}
                                {isEnrolled && <span className="px-2 py-0.5 bg-green-100 text-green-700 rounded text-xs font-medium">Enrolled</span>}
                                {isFull && !isEnrolled && <span className="px-2 py-0.5 bg-red-100 text-red-700 rounded text-xs font-medium">Full</span>}
                              </div>
                              <p className="text-gray-800 font-medium">{course.name}</p>
                              <p className="text-sm text-gray-600">{course.instructor}</p>
                            </div>
                            {!isEnrolled && (
                              <button
                                onClick={() => toggleCourse(course.id)}
                                disabled={course.status === 'closed' && !isSelected}
                                className={`p-1.5 rounded-lg transition-colors ${isSelected
                                  ? 'bg-red-100 text-red-600 hover:bg-red-200'
                                  : course.status === 'closed'
                                    ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                                    : 'bg-blue-100 text-blue-600 hover:bg-blue-200'
                                  }`}
                              >
                                {isSelected ? <Minus className="size-4" /> : <Plus className="size-4" />}
                              </button>
                            )}
                          </div>

                          <div className="flex flex-wrap gap-x-4 gap-y-2 text-xs text-gray-500 mt-2">
                            <div className="flex items-center gap-1">
                              <Clock className="size-3" /> {course.schedule}
                            </div>
                            <div className={`flex items-center gap-1 ${isFull ? 'text-red-600 font-medium' : ''}`}>
                              <Users className="size-3" /> {course.enrolled}/{course.capacity}
                            </div>
                            <div className="flex items-center gap-1">
                              <Calendar className="size-3" /> {course.location}
                            </div>
                            <div className="flex items-center gap-1 ml-auto font-medium text-gray-700">
                              {course.credits} Credits
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </AccordionContent>
                </AccordionItem>
              ))}
              {Object.keys(groupedCourses).length === 0 && (
                <div className="text-center py-8 text-gray-500">
                  No courses found matching your search.
                </div>
              )}
            </Accordion>
          </div>
        </div>

        {/* Shopping Cart (Compact) */}
        <div className="space-y-6">
          <div className="bg-white rounded-lg border border-gray-200 p-6 sticky top-32">
            <h3 className="font-semibold text-gray-900 mb-4">Cart ({cartCourses.length})</h3>

            {cartCourses.length === 0 ? (
              <div className="text-center py-8">
                <AlertCircle className="size-10 text-gray-300 mx-auto mb-2" />
                <p className="text-gray-500 text-xs">Empty</p>
              </div>
            ) : (
              <>
                <div className="space-y-2 mb-4 max-h-[300px] overflow-y-auto">
                  {cartCourses.map(course => (
                    <div key={course.id} className="p-2 bg-gray-50 rounded border border-gray-100 flex justify-between items-center group">
                      <div>
                        <p className="font-medium text-xs text-gray-900">{course.code}</p>
                        <p className="text-[10px] text-gray-500">{course.schedule.split(' ')[0]}</p>
                      </div>
                      <button onClick={() => toggleCourse(course.id)} className="text-gray-400 hover:text-red-600">
                        <Minus className="size-3" />
                      </button>
                    </div>
                  ))}
                </div>

                <div className="border-t border-gray-200 pt-3 mb-3">
                  <div className="flex justify-between text-sm font-medium">
                    <span>Total Credits</span>
                    <span>{totalCredits}</span>
                  </div>
                </div>

                <button
                  onClick={handleSubmit}
                  disabled={isSubmitting || totalCredits > 18 || cartCourses.length === 0}
                  className="w-full py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 text-sm font-medium flex justify-center items-center gap-2 disabled:bg-gray-300"
                >
                  {isSubmitting ? <Loader2 className="animate-spin size-4" /> : "Register"}
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
