// In-memory data store

const users = [];
const students = [];
const appointments = [];

// Seed some initial courses
const courses = [
    {
        _id: '101',
        code: 'CS101',
        name: 'Introduction to Computer Science',
        credits: 3,
        description: 'Fundamental concepts of programming and computer systems.',
        enrolled: 0
    },
    {
        _id: '102',
        code: 'CS102',
        name: 'Data Structures and Algorithms',
        credits: 4,
        description: 'Advanced programming with data structures.',
        enrolled: 0
    },
    {
        _id: '103',
        code: 'MATH201',
        name: 'Linear Algebra',
        credits: 3,
        description: 'Matrix theory and vector spaces.',
        enrolled: 0
    },
    {
        _id: '104',
        code: 'ENG101',
        name: 'Technical Writing',
        credits: 2,
        description: 'Skills for technical documentation.',
        enrolled: 0
    },
    {
        _id: '105',
        code: 'CS201',
        name: 'Database Systems',
        credits: 3,
        description: 'Relational database design and SQL.',
        enrolled: 0
    },
    {
        _id: '106',
        code: 'CS202',
        name: 'Operating Systems',
        credits: 4,
        description: 'Process management, memory management, and file systems.',
        enrolled: 0
    }
];

module.exports = {
    users,
    students,
    courses,
    appointments
};
