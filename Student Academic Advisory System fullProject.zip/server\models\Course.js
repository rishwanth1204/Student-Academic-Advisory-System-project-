const mongoose = require('mongoose');

const CourseSchema = new mongoose.Schema({
    code: { type: String, required: true, unique: true },
    name: { type: String, required: true },
    credits: { type: Number, required: true },
    description: String,
    instructor: String,
    schedule: String,
    location: String,
    prerequisites: [String],
    capacity: { type: Number, default: 30 },
    enrolled: { type: Number, default: 0 },
    semester: String,
    status: { type: String, enum: ['open', 'waitlist', 'closed'], default: 'open' }
});

module.exports = mongoose.model('Course', CourseSchema);
