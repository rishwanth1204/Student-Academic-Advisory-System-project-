// const Appointment = require('../models/Appointment');
// const Student = require('../models/Student');
const { appointments, students } = require('../data/mockData');

// @desc    Get all appointments for the student
// @route   GET /api/appointments
// @access  Private
exports.getAppointments = async (req, res, next) => {
    try {
        // const student = await Student.findOne({ userId: req.user._id });
        const student = students.find(s => s.userId === req.user._id);

        if (!student) {
            return res.status(404).json({ message: 'Student profile not found' });
        }

        // const appointments = await Appointment.find({ studentId: student._id });
        const studentAppointments = appointments.filter(a => a.studentId === student._id);

        res.json(studentAppointments);
    } catch (err) {
        next(err);
    }
};

// @desc    Book a new appointment
// @route   POST /api/appointments
// @access  Private
exports.bookAppointment = async (req, res, next) => {
    try {
        const { advisorName, date, time, topic, type } = req.body;

        // const student = await Student.findOne({ userId: req.user._id });
        const student = students.find(s => s.userId === req.user._id);

        if (!student) {
            return res.status(404).json({ message: 'Student profile not found' });
        }

        const appointment = {
            _id: Date.now().toString(), // Simple ID generation
            studentId: student._id,
            advisorName: advisorName || student.advisor,
            date,
            time,
            topic,
            type: type || 'virtual',
            status: 'confirmed',
            // save: async function() { return this; }
        };

        appointments.push(appointment);

        res.status(201).json(appointment);
    } catch (err) {
        next(err);
    }
};

// @desc    Cancel an appointment
// @route   PUT /api/appointments/:id/cancel
// @access  Private
exports.cancelAppointment = async (req, res, next) => {
    try {
        // const appointment = await Appointment.findById(req.params.id);
        const appointment = appointments.find(a => a._id === req.params.id);

        if (!appointment) {
            return res.status(404).json({ message: 'Appointment not found' });
        }

        // Verify ownership (indirectly via studentId)
        // In a real app we'd check if appointment.studentId matches current student's ID
        // const student = await Student.findOne({ userId: req.user._id });
        const student = students.find(s => s.userId === req.user._id);

        if (!student || appointment.studentId.toString() !== student._id.toString()) {
            return res.status(401).json({ message: 'Not authorized to cancel this appointment' });
        }

        appointment.status = 'cancelled';
        // await appointment.save();

        res.json(appointment);
    } catch (err) {
        next(err);
    }
};
