const express = require('express');
const router = express.Router();
const { getCourses, enrollCourse } = require('../controllers/courseController');
const { protect } = require('../middleware/authMiddleware');

router.get('/', getCourses);
router.post('/enroll', protect, enrollCourse);

module.exports = router;
