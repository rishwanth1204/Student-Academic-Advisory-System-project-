import { Mail, Phone, MapPin, Calendar, MessageSquare, Video, Clock, CheckCircle2, Star, FileText } from 'lucide-react';
import { useAuthStore } from '../store/useAuthStore';
import { toast } from 'sonner';

export function Advisor() {
  const { user } = useAuthStore();
  const advisorName = user && 'studentId' in user ? user.advisor : 'Dr. Robert Anderson';

  // Static advisor details with added premium metadata
  const advisor = {
    name: advisorName || 'Dr. Robert Anderson',
    title: 'Senior Academic Advisor',
    department: 'Department of Computer Science',
    email: 'r.anderson@university.edu',
    phone: '(555) 123-4567',
    office: 'Building E, Room 305',
    specialization: 'Software Engineering & AI',
    rating: 4.9,
    reviews: 124,
    nextAvailable: 'Today, 2:30 PM',
    responseTime: '< 2 hours'
  };

  const actions = [
    { label: 'Schedule Appointment', icon: Calendar, color: 'text-blue-600', bg: 'bg-blue-50', border: 'border-blue-100', hover: 'hover:bg-blue-100' },
    { label: 'Send Message', icon: MessageSquare, color: 'text-purple-600', bg: 'bg-purple-50', border: 'border-purple-100', hover: 'hover:bg-purple-100' },
    { label: 'Video Call', icon: Video, color: 'text-green-600', bg: 'bg-green-50', border: 'border-green-100', hover: 'hover:bg-green-100' },
    { label: 'Request Transcript', icon: FileText, color: 'text-orange-600', bg: 'bg-orange-50', border: 'border-orange-100', hover: 'hover:bg-orange-100' },
  ];

  return (
    <div className="space-y-8">
      {/* Advisor Profile Header */}
      <div className="relative bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
        {/* Banner */}
        <div className="h-48 bg-gradient-to-r from-blue-700 via-blue-600 to-indigo-700">
          <div className="absolute top-6 right-6 flex gap-3">
            <div className="px-4 py-1.5 bg-white/20 backdrop-blur-md rounded-full text-white text-sm font-medium border border-white/30 flex items-center gap-2">
              <div className="size-2 bg-green-400 rounded-full animate-pulse" />
              Online Now
            </div>
          </div>
        </div>

        <div className="px-8 pb-8">
          <div className="flex flex-col md:flex-row gap-6 items-end -mt-16">
            <div className="relative">
              <div className="p-1.5 bg-white rounded-2xl shadow-md">
                <img
                  src="https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&q=80&w=200&h=200"
                  alt="Advisor"
                  className="size-32 rounded-xl object-cover"
                />
              </div>
              <div className="absolute -bottom-2 -right-2 bg-blue-600 text-white p-2 rounded-full border-4 border-white shadow-sm" title="Verified Advisor">
                <CheckCircle2 className="size-5" />
              </div>
            </div>

            <div className="flex-1 mb-2">
              <h1 className="text-3xl font-bold text-gray-900">{advisor.name}</h1>
              <p className="text-blue-600 font-medium text-lg">{advisor.title}</p>
              <p className="text-gray-500">{advisor.department} • {advisor.specialization}</p>
            </div>

            <div className="flex gap-4 mb-2">
              <div className="text-center px-6 py-2 bg-gray-50 rounded-xl border border-gray-100">
                <p className="text-2xl font-bold text-gray-900">{advisor.rating}</p>
                <div className="flex items-center gap-1 text-xs text-gray-500 uppercase tracking-wide font-medium mt-0.5">
                  <Star className="size-3 text-yellow-500 fill-yellow-500" /> Rating
                </div>
              </div>
              <div className="text-center px-6 py-2 bg-gray-50 rounded-xl border border-gray-100">
                <p className="text-2xl font-bold text-gray-900">{advisor.reviews}</p>
                <p className="text-xs text-gray-500 uppercase tracking-wide font-medium mt-0.5">Reviews</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column: Actions & Contact */}
        <div className="lg:col-span-2 space-y-8">
          {/* Quick Actions */}
          <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
            <h3 className="font-semibold text-gray-900 mb-4">Quick Actions</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {actions.map((action) => {
                const Icon = action.icon;
                return (
                  <button
                    key={action.label}
                    onClick={() => toast.success(`${action.label} initiated`)}
                    className={`flex items-center gap-4 p-4 rounded-xl border transition-all duration-200 group ${action.bg} ${action.border} ${action.hover}`}
                  >
                    <div className={`p-3 bg-white rounded-lg shadow-sm group-hover:scale-110 transition-transform duration-200`}>
                      <Icon className={`size-5 ${action.color}`} />
                    </div>
                    <span className={`font-semibold ${action.color.replace('text-', 'text-gray-900 ')}`}>{action.label}</span>
                  </button>
                )
              })}
            </div>
          </div>

          {/* About & Expertise */}
          <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm space-y-4">
            <h3 className="font-semibold text-gray-900">About</h3>
            <p className="text-gray-600 leading-relaxed">
              Dr. Anderson has over 15 years of experience in academic advising and computer science education.
              He specializes in helping students navigate the complexities of software engineering tracks and
              finding internship opportunities. He is also the faculty sponsor for the ACM student chapter.
            </p>

            <h4 className="font-medium text-gray-900 pt-2">Areas of Expertise</h4>
            <div className="flex flex-wrap gap-2">
              {['Curriculum Planning', 'Career Guidance', 'Graduate School Applications', 'Internships', 'Mental Health Support'].map(tag => (
                <span key={tag} className="px-3 py-1 bg-gray-100 text-gray-600 rounded-full text-sm font-medium">
                  {tag}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Key Info & Office Hours */}
        <div className="space-y-8">
          {/* Office Hours */}
          <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
            <div className="flex items-center gap-3 mb-6">
              <div className="p-2 bg-blue-50 text-blue-600 rounded-lg">
                <Clock className="size-5" />
              </div>
              <h3 className="font-semibold text-gray-900">Office Hours</h3>
            </div>

            <div className="space-y-4">
              {[
                { day: 'Monday', time: '10:00 AM - 12:00 PM', status: 'Available' },
                { day: 'Wednesday', time: '10:00 AM - 12:00 PM', status: 'Available' },
                { day: 'Friday', time: '1:00 PM - 3:00 PM', status: 'Full' },
              ].map(slot => (
                <div key={slot.day} className="flex items-center justify-between p-3 rounded-xl bg-gray-50 border border-gray-100">
                  <div>
                    <p className="font-medium text-gray-900">{slot.day}</p>
                    <p className="text-xs text-gray-500">{slot.time}</p>
                  </div>
                  <span className={`px-2 py-1 rounded text-xs font-medium ${slot.status === 'Available' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                    {slot.status}
                  </span>
                </div>
              ))}
            </div>

            <div className="mt-6 pt-6 border-t border-gray-100">
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm text-gray-500">Next Available Slot</span>
                <span className="text-sm font-semibold text-gray-900">{advisor.nextAvailable}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-500">Avg. Response Time</span>
                <span className="text-sm font-semibold text-gray-900">{advisor.responseTime}</span>
              </div>
            </div>
          </div>

          {/* Contact Info */}
          <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
            <h3 className="font-semibold text-gray-900 mb-4">Contact Information</h3>
            <div className="space-y-4">
              <div className="flex items-start gap-4">
                <div className="p-2 bg-gray-50 rounded-lg text-gray-500">
                  <Mail className="size-5" />
                </div>
                <div>
                  <p className="text-sm text-gray-500 block mb-1">Email Address</p>
                  <a href={`mailto:${advisor.email}`} className="text-sm font-medium text-blue-600 hover:underline">{advisor.email}</a>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="p-2 bg-gray-50 rounded-lg text-gray-500">
                  <Phone className="size-5" />
                </div>
                <div>
                  <p className="text-sm text-gray-500 block mb-1">Phone Number</p>
                  <p className="text-sm font-medium text-gray-900">{advisor.phone}</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="p-2 bg-gray-50 rounded-lg text-gray-500">
                  <MapPin className="size-5" />
                </div>
                <div>
                  <p className="text-sm text-gray-500 block mb-1">Office Location</p>
                  <p className="text-sm font-medium text-gray-900">{advisor.office}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
