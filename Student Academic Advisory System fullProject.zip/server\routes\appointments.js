const express = require('express');
const router = express.Router();
const { getAppointments, bookAppointment, cancelAppointment } = require('../controllers/appointmentController');
const { protect } = require('../middleware/authMiddleware');

router.get('/', protect, getAppointments);
router.post('/', protect, bookAppointment);
router.put('/:id/cancel', protect, cancelAppointment);

module.exports = router;
