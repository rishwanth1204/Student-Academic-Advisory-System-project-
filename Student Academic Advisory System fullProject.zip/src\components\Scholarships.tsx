import { useState } from 'react';
import { toast } from 'sonner';
import { DollarSign, Calendar, Users, Award, Search, Filter, CheckCircle, Clock } from 'lucide-react';

interface Scholarship {
  id: string;
  name: string;
  amount: number;
  deadline: string;
  eligibility: string[];
  type: 'merit' | 'need' | 'department' | 'external';
  status: 'open' | 'upcoming' | 'closed';
  applicants: number;
  description: string;
}

export function Scholarships() {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState('all');

  const scholarships: Scholarship[] = [
    {
      id: '1',
      name: 'CS Department Excellence Scholarship',
      amount: 5000,
      deadline: '2026-03-15',
      eligibility: ['GPA ≥ 3.5', 'CS Major', 'Full-time student'],
      type: 'department',
      status: 'open',
      applicants: 45,
      description: 'Awarded to outstanding Computer Science students demonstrating academic excellence and leadership.'
    },
    {
      id: '2',
      name: 'Dean\'s Merit Scholarship',
      amount: 10000,
      deadline: '2026-02-28',
      eligibility: ['GPA ≥ 3.8', 'Any Major', 'Essay required'],
      type: 'merit',
      status: 'open',
      applicants: 123,
      description: 'Prestigious scholarship for top-performing students across all disciplines.'
    },
    {
      id: '3',
      name: 'Technology Innovation Grant',
      amount: 3000,
      deadline: '2026-04-01',
      eligibility: ['Tech project proposal', 'STEM Major'],
      type: 'external',
      status: 'upcoming',
      applicants: 0,
      description: 'Supports students working on innovative technology projects with potential social impact.'
    },
    {
      id: '4',
      name: 'Need-Based Student Aid',
      amount: 7500,
      deadline: '2026-03-01',
      eligibility: ['FAFSA required', 'Financial need', 'GPA ≥ 2.5'],
      type: 'need',
      status: 'open',
      applicants: 234,
      description: 'Provides financial assistance to students demonstrating significant financial need.'
    },
    {
      id: '5',
      name: 'Women in Technology Scholarship',
      amount: 4000,
      deadline: '2026-03-20',
      eligibility: ['Female students', 'CS/Engineering Major', 'GPA ≥ 3.0'],
      type: 'external',
      status: 'open',
      applicants: 67,
      description: 'Empowers women pursuing careers in technology and computer science.'
    },
    {
      id: '6',
      name: 'Research Assistant Fellowship',
      amount: 8000,
      deadline: '2026-02-15',
      eligibility: ['Graduate student', 'Research proposal', 'Faculty sponsor'],
      type: 'department',
      status: 'open',
      applicants: 28,
      description: 'Funds graduate students conducting research in computer science and related fields.'
    }
  ];

  const myApplications = [
    {
      id: '1',
      scholarship: 'CS Department Excellence Scholarship',
      amount: 5000,
      status: 'submitted',
      submittedDate: '2026-02-01',
      decision: 'Pending'
    },
    {
      id: '2',
      scholarship: 'Women in Technology Scholarship',
      amount: 4000,
      status: 'in-progress',
      submittedDate: null,
      decision: 'Draft'
    }
  ];

  const types = ['all', 'merit', 'need', 'department', 'external'];

  const filteredScholarships = scholarships.filter(scholarship => {
    const matchesSearch = scholarship.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      scholarship.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = filterType === 'all' || scholarship.type === filterType;
    return matchesSearch && matchesType;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'open':
        return 'bg-green-100 text-green-700';
      case 'upcoming':
        return 'bg-blue-100 text-blue-700';
      case 'closed':
        return 'bg-gray-100 text-gray-700';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'merit':
        return '🏆';
      case 'need':
        return '💰';
      case 'department':
        return '🎓';
      case 'external':
        return '🌟';
      default:
        return '📄';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h2 className="text-2xl font-semibold text-gray-900 mb-4">Scholarships & Financial Aid</h2>

        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 size-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search scholarships..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            {types.map(type => (
              <option key={type} value={type}>
                {type === 'all' ? 'All Types' : type.charAt(0).toUpperCase() + type.slice(1)}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="flex items-center gap-3">
            <DollarSign className="size-8 text-green-600" />
            <div>
              <p className="text-2xl font-semibold text-gray-900">$37K</p>
              <p className="text-sm text-gray-500">Total Available</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="flex items-center gap-3">
            <Award className="size-8 text-blue-600" />
            <div>
              <p className="text-2xl font-semibold text-gray-900">6</p>
              <p className="text-sm text-gray-500">Open Opportunities</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="flex items-center gap-3">
            <CheckCircle className="size-8 text-purple-600" />
            <div>
              <p className="text-2xl font-semibold text-gray-900">2</p>
              <p className="text-sm text-gray-500">My Applications</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="flex items-center gap-3">
            <Clock className="size-8 text-orange-600" />
            <div>
              <p className="text-2xl font-semibold text-gray-900">15</p>
              <p className="text-sm text-gray-500">Days to Deadline</p>
            </div>
          </div>
        </div>
      </div>

      {/* My Applications */}
      {myApplications.length > 0 && (
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h3 className="font-semibold text-gray-900 mb-4">My Applications</h3>
          <div className="space-y-3">
            {myApplications.map(app => (
              <div key={app.id} className="flex items-center justify-between p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <div>
                  <p className="font-medium text-gray-900">{app.scholarship}</p>
                  <div className="flex items-center gap-3 mt-1 text-sm text-gray-600">
                    <span className="flex items-center gap-1">
                      <DollarSign className="size-3" />
                      {app.amount.toLocaleString()}
                    </span>
                    {app.submittedDate && (
                      <>
                        <span>•</span>
                        <span>Submitted {new Date(app.submittedDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}</span>
                      </>
                    )}
                  </div>
                </div>
                <span className={`px-3 py-1 rounded-full text-xs font-medium ${app.status === 'submitted' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'
                  }`}>
                  {app.decision}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Scholarships List */}
      <div className="grid grid-cols-1 gap-6">
        {filteredScholarships.map(scholarship => (
          <div key={scholarship.id} className="bg-white rounded-lg border border-gray-200 p-6 hover:shadow-lg transition-shadow">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-start gap-4">
                <div className="text-4xl">{getTypeIcon(scholarship.type)}</div>
                <div className="flex-1">
                  <h3 className="font-semibold text-gray-900 text-lg">{scholarship.name}</h3>
                  <p className="text-sm text-gray-600 mt-1">{scholarship.description}</p>
                </div>
              </div>
              <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(scholarship.status)}`}>
                {scholarship.status}
              </span>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
              <div className="flex items-center gap-2 text-sm">
                <DollarSign className="size-4 text-gray-400" />
                <div>
                  <p className="text-xs text-gray-500">Award Amount</p>
                  <p className="font-semibold text-gray-900">${scholarship.amount.toLocaleString()}</p>
                </div>
              </div>

              <div className="flex items-center gap-2 text-sm">
                <Calendar className="size-4 text-gray-400" />
                <div>
                  <p className="text-xs text-gray-500">Deadline</p>
                  <p className="font-medium text-gray-900">
                    {new Date(scholarship.deadline).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 text-sm">
                <Users className="size-4 text-gray-400" />
                <div>
                  <p className="text-xs text-gray-500">Applicants</p>
                  <p className="font-medium text-gray-900">{scholarship.applicants}</p>
                </div>
              </div>

              <div className="flex items-center gap-2 text-sm">
                <Award className="size-4 text-gray-400" />
                <div>
                  <p className="text-xs text-gray-500">Type</p>
                  <p className="font-medium text-gray-900 capitalize">{scholarship.type}</p>
                </div>
              </div>
            </div>

            <div className="mb-4">
              <p className="text-sm font-medium text-gray-700 mb-2">Eligibility Requirements:</p>
              <div className="flex flex-wrap gap-2">
                {scholarship.eligibility.map((req, index) => (
                  <span key={index} className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-xs">
                    ✓ {req}
                  </span>
                ))}
              </div>
            </div>

            <div className="flex gap-3">
              {scholarship.status === 'open' && (
                <button
                  onClick={() => toast.success(`Application started for ${scholarship.name}`)}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium"
                >
                  Apply Now
                </button>
              )}
              <button
                onClick={() => toast.info(`Viewing details for ${scholarship.name}`)}
                className="px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors text-sm font-medium"
              >
                Learn More
              </button>
              <button
                onClick={() => toast.success('Scholarship saved to your list')}
                className="px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors text-sm font-medium"
              >
                Save for Later
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Tips */}
      <div className="bg-gradient-to-r from-purple-600 to-blue-600 rounded-lg p-6 text-white">
        <h3 className="text-xl font-semibold mb-3">💡 Scholarship Application Tips</h3>
        <ul className="space-y-2 text-blue-50">
          <li>• Start early - most scholarships have early deadlines</li>
          <li>• Tailor your application to each scholarship's specific requirements</li>
          <li>• Request recommendation letters at least 2 weeks in advance</li>
          <li>• Proofread your essays multiple times and have someone review them</li>
          <li>• Keep track of all deadlines and required documents</li>
        </ul>
      </div>
    </div>
  );
}
