import { Award, BookOpen, Calendar, TrendingUp, AlertCircle } from 'lucide-react';
import React from 'react';
import { useStudentStore } from '../store/useStudentStore';

export function Dashboard() {
  const { enrolledCourses, calculateGPA, getTotalCredits, appointments } = useStudentStore();
  const gpa = calculateGPA();
  const totalCredits = getTotalCredits();
  const enrolledCount = enrolledCourses.length;
  const upcomingAppointmentsCount = appointments.filter(a => a.status === 'confirmed').length;

  const stats = [
    { label: 'Current GPA', value: gpa.toFixed(2), icon: Award, color: 'bg-green-100 text-green-600' },
    { label: 'Enrolled Courses', value: enrolledCount.toString(), icon: BookOpen, color: 'bg-blue-100 text-blue-600' },
    { label: 'Upcoming Appointments', value: upcomingAppointmentsCount.toString(), icon: Calendar, color: 'bg-purple-100 text-purple-600' },
    { label: 'Credits Completed', value: `${totalCredits}/120`, icon: TrendingUp, color: 'bg-orange-100 text-orange-600' },
  ];

  return (
    <div className="space-y-6">
      {/* Live Time Header */}
      <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-8 rounded-2xl shadow-lg m-1 text-white">
        <div>
          <h1 className="text-3xl font-bold">Welcome back!</h1>
          <p className="text-blue-100 mt-2 text-lg">Here's an overview of your academic progress.</p>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <div key={stat.label} className="bg-white rounded-2xl border border-gray-100 p-6 shadow-sm hover:shadow-md transition-all duration-300 hover:-translate-y-1">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500">{stat.label}</p>
                  <p className="mt-2 text-3xl font-bold text-gray-900">{stat.value}</p>
                </div>
                <div className={`p-3 rounded-xl shadow-sm ${stat.color}`}>
                  <Icon className="size-6" />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Upcoming Deadlines Placeholder relying on static data for now as deadlines aren't in store yet */}
        <div className="bg-white rounded-2xl border border-gray-100 p-6 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold text-gray-900">Upcoming Deadlines</h2>
            <AlertCircle className="size-5 text-gray-400" />
          </div>
          <div className="space-y-4">
            {/* Fallback mock data since we haven't implemented deadlines in store yet */}
            <div className="text-sm text-gray-500 text-center py-8 bg-gray-50 rounded-xl border border-dashed border-gray-200">
              No deadlines upcoming
            </div>
          </div>
        </div>

        {/* Recent Grades from Enrolled Courses */}
        <div className="bg-white rounded-2xl border border-gray-100 p-6 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold text-gray-900">Recent Grades</h2>
            <Award className="size-5 text-gray-400" />
          </div>
          <div className="space-y-4">
            {enrolledCourses.filter(c => c.grade).slice(0, 3).map((course, index) => (
              <div key={index} className="flex items-center justify-between pb-4 border-b border-gray-100 last:border-0 last:pb-0">
                <div className="flex-1">
                  <p className="text-sm font-medium text-gray-900">{course.name}</p>
                  <p className="text-sm text-gray-500">{course.code}</p>
                </div>
                <div className="text-right">
                  <p className="text-lg font-semibold text-gray-900">{course.grade}</p>
                  <p className="text-xs text-gray-500">{course.progress}%</p>
                </div>
              </div>
            ))}
            {enrolledCourses.filter(c => c.grade).length === 0 && (
              <div className="text-sm text-gray-500 text-center py-4">No recent grades available</div>
            )}
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="bg-white rounded-2xl border border-gray-100 p-6 shadow-sm">
        <h2 className="font-semibold text-gray-900 mb-6">Quick Actions</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <button className="px-6 py-4 bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-xl hover:from-blue-700 hover:to-blue-800 transition-all shadow-md hover:shadow-lg hover:-translate-y-0.5 text-sm font-semibold">
            Schedule Appointment
          </button>
          <button className="px-6 py-4 bg-white border border-gray-200 text-gray-700 rounded-xl hover:bg-gray-50 hover:border-gray-300 transition-all shadow-sm hover:shadow-md text-sm font-semibold">
            View Transcript
          </button>
          <button className="px-6 py-4 bg-white border border-gray-200 text-gray-700 rounded-xl hover:bg-gray-50 hover:border-gray-300 transition-all shadow-sm hover:shadow-md text-sm font-semibold">
            Contact Advisor
          </button>
        </div>
      </div>
    </div>
  );
}
