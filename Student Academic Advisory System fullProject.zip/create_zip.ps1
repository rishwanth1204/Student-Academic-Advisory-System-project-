$source = "c:\Users\rishw\Downloads\Student Academic Advisory System project"
$zip = "c:\Users\rishw\Downloads\Student_Academic_Advisory_System_Project.zip"
$temp = "c:\Users\rishw\Downloads\Student_Project_Export_Temp"

Write-Host "Preparing to zip..."
if (Test-Path $temp) { Remove-Item $temp -Recurse -Force }
New-Item -Path $temp -ItemType Directory | Out-Null

# Copy everything except node_modules and build artifacts
# We filter the items at the root level. Sub-folder 'node_modules' (if any inside src/ etc which shouldn't exist) would still be copied, but usually it's only in root.
Get-ChildItem -Path $source | Where-Object { $_.Name -notin 'node_modules', 'build', 'dist', '.git', '.vscode', '.gemini', 'coverage' } | Copy-Item -Destination $temp -Recurse

Write-Host "Compressing to $zip..."
Compress-Archive -Path "$temp\*" -DestinationPath $zip -Force

Write-Host "Cleaning up temp files..."
Remove-Item $temp -Recurse -Force
Write-Host "Done."
