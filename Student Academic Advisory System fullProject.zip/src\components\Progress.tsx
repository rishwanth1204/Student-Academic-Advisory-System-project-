import { Award, BookOpen, CheckCircle, Circle, Target } from 'lucide-react';
import { useStudentStore } from '../store/useStudentStore';
import { TranscriptEntry } from '../types';

interface Requirement {
  category: string;
  required: number;
  completed: number;
  courses: { code: string; name: string; credits: number; grade?: string }[];
}

export function Progress() {
  const { transcript } = useStudentStore();

  // Helper to check if a course is in transcript
  const getCourseStatus = (code: string) => {
    return transcript.find(t => t.code === code);
  };

  // Helper to sum credits for a category
  // In a real app, courses would have a 'category' field. 
  // Here we will map specific codes to categories manually for the prototype logic.
  const getCategoryCredits = (codes: string[]) => {
    return transcript
      .filter(t => codes.includes(t.code))
      .reduce((sum, t) => sum + t.credits, 0);
  };

  // Define the curriculum structure
  // This is effectively the "Degree Rules" database
  const coreCodes = ['CS 101', 'CS 201', 'CS 202', 'CS 305', 'CS 310', 'CS 320', 'CS 330', 'CS 340', 'CS 350', 'CS 400', 'CS 450'];
  const mathCodes = ['MATH 101', 'MATH 102', 'MATH 201', 'MATH 210', 'STAT 301'];
  const genEdCodes = ['ENG 101', 'HIST 201', 'PSYC 101', 'ECON 101', 'PHYS 201', 'PHYS 202', 'ART 101', 'PHIL 201', 'SOC 101'];
  const electiveCodes = ['BUS 301', 'CS 420', 'CS 430', 'MKT 201', 'CS 460'];

  // Construct the Requirement objects dynamically based on Transcript
  const degreeRequirements: Requirement[] = [
    {
      category: 'Core Computer Science',
      required: 36,
      completed: getCategoryCredits(coreCodes),
      courses: coreCodes.map(code => {
        const taken = getCourseStatus(code);
        // We need names for these. Ideally from a Course Catalog. 
        // For this refactor, I'll map a few common ones or check if Transcript has names. 
        // TranscriptEntry has 'courseName' usually? Let's assume it does.
        // If not taken, we need a Fallback Name. 
        // I will use a simple map for names to keep it clean, or just use the code if name missing.
        const nameMap: Record<string, string> = {
          'CS 101': 'Intro to Programming',
          'CS 201': 'Data Structures',
          'CS 202': 'Algorithms',
          'CS 305': 'Database Systems',
          'CS 310': 'Operating Systems',
          'CS 320': 'Web Development',
          'CS 330': 'Software Engineering',
          'CS 340': 'Computer Networks',
          'CS 350': 'Computer Architecture',
          'CS 400': 'Theory of Computation',
          'CS 450': 'Machine Learning',
        };
        return {
          code,
          name: taken?.courseName || nameMap[code] || 'Course',
          credits: taken?.credits || (code.startsWith('CS 35') || code.startsWith('CS 305') || code.startsWith('CS 310') ? 4 : 3), // Rough heuristic
          grade: taken?.grade
        };
      }),
    },
    {
      category: 'Mathematics',
      required: 18,
      completed: getCategoryCredits(mathCodes),
      courses: mathCodes.map(code => {
        const taken = getCourseStatus(code);
        const nameMap: Record<string, string> = {
          'MATH 101': 'Calculus I',
          'MATH 102': 'Calculus II',
          'MATH 201': 'Linear Algebra',
          'MATH 210': 'Discrete Mathematics',
          'STAT 301': 'Probability & Statistics'
        };
        return {
          code,
          name: taken?.courseName || nameMap[code] || 'Math Course',
          credits: taken?.credits || (code.includes('101') || code.includes('102') || code.includes('210') ? 4 : 3),
          grade: taken?.grade
        }
      }),
    },
    {
      category: 'General Education',
      required: 30,
      completed: getCategoryCredits(genEdCodes),
      courses: genEdCodes.map(code => {
        const taken = getCourseStatus(code);
        const nameMap: Record<string, string> = {
          'ENG 101': 'English Composition',
          'HIST 201': 'World History',
          'PSYC 101': 'Intro to Psychology',
          'ECON 101': 'Microeconomics',
          'PHYS 201': 'Physics I',
          'PHYS 202': 'Physics II',
          'ART 101': 'Art History',
          'PHIL 201': 'Ethics',
          'SOC 101': 'Sociology'
        };
        return {
          code,
          name: taken?.courseName || nameMap[code] || 'Gen Ed Course',
          credits: taken?.credits || (code.includes('PHYS') ? 4 : 3),
          grade: taken?.grade
        }
      }),
    },
    {
      category: 'Electives',
      required: 15, // Adjusted to match likely transcript
      completed: getCategoryCredits(electiveCodes),
      courses: electiveCodes.map(code => {
        const taken = getCourseStatus(code);
        const nameMap: Record<string, string> = {
          'BUS 301': 'Business Communication',
          'CS 420': 'Mobile App Development',
          'CS 430': 'Cloud Computing',
          'MKT 201': 'Digital Marketing',
          'CS 460': 'Cybersecurity'
        };
        return {
          code,
          name: taken?.courseName || nameMap[code] || 'Elective',
          credits: 3,
          grade: taken?.grade
        }
      }),
    },
  ];

  const totalRequired = degreeRequirements.reduce((sum, req) => sum + req.required, 0);
  const totalCompleted = degreeRequirements.reduce((sum, req) => sum + req.completed, 0);
  const overallProgress = Math.min(100, Math.round((totalCompleted / totalRequired) * 100));
  const creditsRemaining = Math.max(0, totalRequired - totalCompleted);

  // Determine class standing dynamically
  const getStanding = (credits: number) => {
    if (credits < 30) return 'Freshman';
    if (credits < 60) return 'Sophomore';
    if (credits < 90) return 'Junior';
    return 'Senior';
  };

  const standing = getStanding(totalCompleted);

  const milestones = [
    { name: 'Freshman Year', status: totalCompleted >= 30 ? 'completed' : (standing === 'Freshman' ? 'in-progress' : 'upcoming'), semester: 'Fall 2023 - Spring 2024' },
    { name: 'Sophomore Year', status: totalCompleted >= 60 ? 'completed' : (standing === 'Sophomore' ? 'in-progress' : (totalCompleted < 30 ? 'upcoming' : 'upcoming')), semester: 'Fall 2024 - Spring 2025' },
    { name: 'Junior Year', status: totalCompleted >= 90 ? 'completed' : (standing === 'Junior' ? 'in-progress' : (totalCompleted < 60 ? 'upcoming' : 'upcoming')), semester: 'Fall 2025 - Spring 2026' },
    { name: 'Senior Year', status: totalCompleted >= 120 ? 'completed' : (standing === 'Senior' ? 'in-progress' : 'upcoming'), semester: 'Fall 2026 - Spring 2027' },
  ];

  return (
    <div className="space-y-6">
      {/* Overall Progress */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-semibold text-gray-900">Degree Progress</h2>
            <p className="text-sm text-gray-500 mt-1">Bachelor of Science in Computer Science</p>
          </div>
          <div className="text-right">
            <p className="text-4xl font-semibold text-blue-600">{overallProgress}%</p>
            <p className="text-sm text-gray-500 mt-1">Complete</p>
          </div>
        </div>

        <div className="w-full bg-gray-200 rounded-full h-4 mb-4">
          <div
            className="bg-blue-600 h-4 rounded-full transition-all"
            style={{ width: `${overallProgress}%` }}
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="text-center p-4 bg-green-50 rounded-lg">
            <p className="text-3xl font-semibold text-green-600">{totalCompleted}</p>
            <p className="text-sm text-gray-600 mt-1">Credits Completed</p>
          </div>
          <div className="text-center p-4 bg-orange-50 rounded-lg">
            <p className="text-3xl font-semibold text-orange-600">{creditsRemaining}</p>
            <p className="text-sm text-gray-600 mt-1">Credits Remaining</p>
          </div>
          <div className="text-center p-4 bg-blue-50 rounded-lg">
            <p className="text-3xl font-semibold text-blue-600">{totalRequired}</p>
            <p className="text-sm text-gray-600 mt-1">Total Required</p>
          </div>
        </div>
      </div>

      {/* Academic Milestones */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h3 className="font-semibold text-gray-900 mb-4">Academic Milestones</h3>
        <div className="space-y-4">
          {milestones.map((milestone, index) => (
            <div key={index} className="flex items-center gap-4">
              <div className="flex-shrink-0">
                {milestone.status === 'completed' ? (
                  <CheckCircle className="size-6 text-green-500" />
                ) : milestone.status === 'in-progress' ? (
                  <Target className="size-6 text-blue-500" />
                ) : (
                  <Circle className="size-6 text-gray-300" />
                )}
              </div>
              <div className="flex-1">
                <p className="font-medium text-gray-900">{milestone.name}</p>
                <p className="text-sm text-gray-500">{milestone.semester}</p>
              </div>
              <span
                className={`px-3 py-1 rounded-full text-xs font-medium ${milestone.status === 'completed'
                    ? 'bg-green-100 text-green-700'
                    : milestone.status === 'in-progress'
                      ? 'bg-blue-100 text-blue-700'
                      : 'bg-gray-100 text-gray-600'
                  }`}
              >
                {milestone.status === 'completed'
                  ? 'Completed'
                  : milestone.status === 'in-progress'
                    ? 'In Progress'
                    : 'Upcoming'}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Requirement Categories */}
      <div className="space-y-4">
        {degreeRequirements.map((requirement, index) => {
          const progress = requirement.required > 0 ? Math.round((requirement.completed / requirement.required) * 100) : 100;
          const isComplete = requirement.completed >= requirement.required;

          return (
            <div key={index} className="bg-white rounded-lg border border-gray-200 p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  {isComplete ? (
                    <Award className="size-6 text-green-500" />
                  ) : (
                    <BookOpen className="size-6 text-blue-500" />
                  )}
                  <div>
                    <h3 className="font-semibold text-gray-900">{requirement.category}</h3>
                    <p className="text-sm text-gray-500">
                      {requirement.completed} of {requirement.required} credits
                    </p>
                  </div>
                </div>
                <span
                  className={`text-2xl font-semibold ${isComplete ? 'text-green-600' : 'text-blue-600'
                    }`}
                >
                  {progress}%
                </span>
              </div>

              <div className="w-full bg-gray-200 rounded-full h-2 mb-4">
                <div
                  className={`h-2 rounded-full transition-all ${isComplete ? 'bg-green-500' : 'bg-blue-600'
                    }`}
                  style={{ width: `${Math.min(progress, 100)}%` }}
                />
              </div>

              <div className="space-y-2">
                {requirement.courses.map((course, courseIndex) => (
                  <div
                    key={courseIndex}
                    className="flex items-center justify-between py-2 px-3 bg-gray-50 rounded"
                  >
                    <div className="flex items-center gap-3">
                      {course.grade ? (
                        <CheckCircle className="size-4 text-green-500 flex-shrink-0" />
                      ) : (
                        <Circle className="size-4 text-gray-300 flex-shrink-0" />
                      )}
                      <div>
                        <span className="text-sm font-medium text-gray-900">
                          {course.code}
                        </span>
                        <span className="text-sm text-gray-600 ml-2">{course.name}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="text-sm text-gray-500">{course.credits} credits</span>
                      {course.grade && (
                        <span className="text-sm font-medium text-gray-900 min-w-[2rem] text-right">
                          {course.grade}
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>

      {/* Projected Graduation */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 rounded-lg p-6 text-white">
        <div className="flex items-center gap-4">
          <Award className="size-12" />
          <div>
            <h3 className="text-xl font-semibold">Projected Graduation</h3>
            <p className="text-blue-100 mt-1">Spring 2027</p>
            <p className="text-sm text-blue-100 mt-2">
              {totalCompleted > 90
                ? "You're in the home stretch! Keep up the great work."
                : "You're on track to graduate on time! Keep up the great work."}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
