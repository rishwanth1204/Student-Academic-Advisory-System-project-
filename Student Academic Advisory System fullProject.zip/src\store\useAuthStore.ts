import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { Student, User } from '../types';
import { MOCK_STUDENT } from '../services/mockData';
// import client from '../api/client'; // Disabled for demo mode

interface AuthState {
    user: User | Student | null;
    token: string | null;
    isAuthenticated: boolean;
    login: (email: string, password: string) => Promise<void>;
    register: (name: string, email: string, password: string) => Promise<void>;
    logout: () => void;
    updateProfile: (updates: Partial<User | Student>) => void;
}

export const useAuthStore = create<AuthState>()(
    persist(
        (set) => ({
            user: null,
            token: null,
            isAuthenticated: false,
            login: async (email, password) => {
                // Simulate API call
                await new Promise(resolve => setTimeout(resolve, 800));

                // For demo, accept any login
                set({
                    user: MOCK_STUDENT,
                    token: 'mock-jwt-token-123',
                    isAuthenticated: true
                });
            },
            register: async (name, email, password) => {
                // Simulate API call
                await new Promise(resolve => setTimeout(resolve, 800));

                set({
                    user: { ...MOCK_STUDENT, name, email },
                    token: 'mock-jwt-token-123',
                    isAuthenticated: true
                });
            },
            logout: () => set({ user: null, token: null, isAuthenticated: false }),
            updateProfile: (updates) =>
                set((state) => ({
                    user: state.user ? { ...state.user, ...updates } : null
                })),
        }),
        {
            name: 'auth-storage',
        }
    )
);
