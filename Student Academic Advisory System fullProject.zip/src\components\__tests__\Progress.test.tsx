import { render, screen } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { Progress } from '../Progress';
import { useStudentStore } from '../../store/useStudentStore';

// Mock the store
vi.mock('../../store/useStudentStore');

describe('Progress Component', () => {
    beforeEach(() => {
        vi.resetAllMocks();
    });

    it('calculates overall progress correctly based on transcript', () => {
        // Mock a transcript with some completed courses
        const mockTranscript = [
            { code: 'CS 101', credits: 3, grade: 'A', courseName: 'Intro', qualityPoints: 12, semester: 'Fall 2023', courseId: '1' },
            { code: 'MATH 101', credits: 4, grade: 'A', courseName: 'Calc I', qualityPoints: 16, semester: 'Fall 2023', courseId: '2' },
            // Add more to reach ~30% for example
        ];

        (useStudentStore as unknown as ReturnType<typeof vi.fn>).mockReturnValue({
            transcript: mockTranscript
        });

        render(<Progress />);

        // Check if progress text is present (exact value depends on logic, but we test if it renders)
        expect(screen.getByText(/Degree Progress/i)).toBeInTheDocument();
        expect(screen.getByText(/Credits Completed/i)).toBeInTheDocument();
        expect(screen.getByText('7')).toBeInTheDocument(); // 3 + 4 credits
    });

    it('displays Freshman standing correctly', () => {
        (useStudentStore as unknown as ReturnType<typeof vi.fn>).mockReturnValue({
            transcript: [] // 0 credits
        });

        render(<Progress />);
        // Freshman year status should be in-progress or active visually, but we can check the text
        const freshmanMilestone = screen.getByText('Freshman Year');
        expect(freshmanMilestone).toBeInTheDocument();
    });

    it('marks requirements as complete when credits are met', () => {
        // Mock a full Core CS category completion
        const coreCourses = [
            'CS 101', 'CS 201', 'CS 202', 'CS 305', 'CS 310', 'CS 320', 'CS 330', 'CS 340', 'CS 350', 'CS 400', 'CS 450'
        ].map(code => ({ code, credits: 3, grade: 'A', courseName: 'Test', qualityPoints: 12, semester: 'X', courseId: 'X' }));

        // Fix credits for some that are 4 in the component logic
        coreCourses.find(c => c.code === 'CS 305')!.credits = 4;
        coreCourses.find(c => c.code === 'CS 310')!.credits = 4;
        coreCourses.find(c => c.code === 'CS 350')!.credits = 4;

        (useStudentStore as unknown as ReturnType<typeof vi.fn>).mockReturnValue({
            transcript: coreCourses
        });

        render(<Progress />);

        // core req is 36. Sum of above is 3*8 + 4*3 = 24+12 = 36.
        // Progress text for that category should be 100% or similar green indicator
        // We can check for a specific text inside the Core category or just check that "36 of 36 credits" is visible
        expect(screen.getByText('36 of 36 credits')).toBeInTheDocument();
    });
});
