

import { useState } from 'react';
import { toast } from 'sonner';
import { Briefcase, Building, MapPin, DollarSign, Clock, ExternalLink, BookmarkPlus, Search, Filter } from 'lucide-react';

interface Job {
  id: string;
  title: string;
  company: string;
  location: string;
  type: 'internship' | 'full-time' | 'co-op' | 'part-time';
  salary: string;
  posted: string;
  deadline: string;
  description: string;
  requirements: string[];
  isSaved: boolean;
}

interface Event {
  id: string;
  name: string;
  type: string;
  date: string;
  time: string;
  location: string;
  companies: string[];
  registered: boolean;
}

export function Career() {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState('all');

  const jobs: Job[] = [
    {
      id: '1',
      title: 'Software Engineering Intern',
      company: 'Google',
      location: 'Mountain View, CA',
      type: 'internship',
      salary: '$8,000 - $10,000/month',
      posted: '2026-01-28',
      deadline: '2026-03-15',
      description: 'Join our team to work on cutting-edge technology projects. You\'ll collaborate with experienced engineers on real-world problems.',
      requirements: ['Currently pursuing CS degree', 'Strong programming skills in Java/Python', 'Data structures knowledge', 'GPA ≥ 3.0'],
      isSaved: true
    },
    {
      id: '2',
      title: 'Full Stack Developer',
      company: 'Microsoft',
      location: 'Seattle, WA',
      type: 'full-time',
      salary: '$120,000 - $150,000/year',
      posted: '2026-02-01',
      deadline: '2026-04-01',
      description: 'Build scalable web applications using modern technologies. Work on Azure cloud services and enterprise solutions.',
      requirements: ['BS in Computer Science', 'React and Node.js experience', '2+ years experience', 'Cloud platform knowledge'],
      isSaved: false
    },
    {
      id: '3',
      title: 'Data Science Co-op',
      company: 'Amazon',
      location: 'Austin, TX',
      type: 'co-op',
      salary: '$7,500/month',
      posted: '2026-01-25',
      deadline: '2026-03-01',
      description: 'Apply machine learning techniques to solve complex business problems. Work with large-scale data systems.',
      requirements: ['Python and SQL proficiency', 'Statistics coursework', 'Machine learning basics', 'Available for 6-month co-op'],
      isSaved: true
    },
    {
      id: '4',
      title: 'Frontend Developer Intern',
      company: 'Meta',
      location: 'Menlo Park, CA',
      type: 'internship',
      salary: '$9,000/month',
      posted: '2026-02-02',
      deadline: '2026-03-20',
      description: 'Create beautiful and responsive user interfaces. Work on products used by billions of people worldwide.',
      requirements: ['React experience', 'HTML/CSS/JavaScript mastery', 'Portfolio required', 'UI/UX interest'],
      isSaved: false
    },
    {
      id: '5',
      title: 'Backend Developer',
      company: 'Netflix',
      location: 'Los Gatos, CA',
      type: 'full-time',
      salary: '$130,000 - $160,000/year',
      posted: '2026-01-30',
      deadline: '2026-03-30',
      description: 'Build and scale microservices that power streaming for millions of users. Work with cutting-edge cloud technology.',
      requirements: ['Strong Java/Kotlin skills', 'Microservices architecture', 'AWS experience', '3+ years experience'],
      isSaved: false
    },
    {
      id: '6',
      title: 'Mobile App Developer',
      company: 'Apple',
      location: 'Cupertino, CA',
      type: 'internship',
      salary: '$8,500/month',
      posted: '2026-02-03',
      deadline: '2026-03-25',
      description: 'Develop innovative iOS applications. Learn from industry leaders and contribute to products used worldwide.',
      requirements: ['Swift programming', 'iOS development experience', 'Computer Science student', 'Portfolio of apps'],
      isSaved: true
    }
  ];

  const events: Event[] = [
    {
      id: '1',
      name: 'Spring Career Fair',
      type: 'Career Fair',
      date: '2026-02-18',
      time: '10:00 AM - 4:00 PM',
      location: 'Student Center Ballroom',
      companies: ['Google', 'Microsoft', 'Amazon', 'Apple', 'Meta'],
      registered: true
    },
    {
      id: '2',
      name: 'Tech Industry Networking Night',
      type: 'Networking',
      date: '2026-02-22',
      time: '6:00 PM - 8:00 PM',
      location: 'Engineering Building',
      companies: ['Various Tech Startups'],
      registered: false
    },
    {
      id: '3',
      name: 'Resume Review Workshop',
      type: 'Workshop',
      date: '2026-02-12',
      time: '3:00 PM - 5:00 PM',
      location: 'Career Center',
      companies: ['Career Services'],
      registered: true
    },
    {
      id: '4',
      name: 'Interview Skills Bootcamp',
      type: 'Workshop',
      date: '2026-02-20',
      time: '1:00 PM - 4:00 PM',
      location: 'Online',
      companies: ['Career Services'],
      registered: false
    }
  ];

  const types = ['all', 'internship', 'full-time', 'co-op', 'part-time'];

  const filteredJobs = jobs.filter(job => {
    const matchesSearch = job.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      job.company.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = filterType === 'all' || job.type === filterType;
    return matchesSearch && matchesType;
  });

  const savedJobs = jobs.filter(job => job.isSaved);

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'internship':
        return 'bg-blue-100 text-blue-700';
      case 'full-time':
        return 'bg-green-100 text-green-700';
      case 'co-op':
        return 'bg-purple-100 text-purple-700';
      case 'part-time':
        return 'bg-orange-100 text-orange-700';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h2 className="text-2xl font-semibold text-gray-900 mb-4">Career Center</h2>

        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 size-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search jobs or companies..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            {types.map(type => (
              <option key={type} value={type}>
                {type === 'all' ? 'All Types' : type.split('-').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ')}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <Briefcase className="size-8 text-blue-600 mb-2" />
          <p className="text-2xl font-semibold text-gray-900">{jobs.length}</p>
          <p className="text-sm text-gray-500">Open Positions</p>
        </div>

        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <BookmarkPlus className="size-8 text-green-600 mb-2" />
          <p className="text-2xl font-semibold text-gray-900">{savedJobs.length}</p>
          <p className="text-sm text-gray-500">Saved Jobs</p>
        </div>

        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <Building className="size-8 text-purple-600 mb-2" />
          <p className="text-2xl font-semibold text-gray-900">{events.length}</p>
          <p className="text-sm text-gray-500">Upcoming Events</p>
        </div>

        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <Clock className="size-8 text-orange-600 mb-2" />
          <p className="text-2xl font-semibold text-gray-900">2</p>
          <p className="text-sm text-gray-500">Applications Pending</p>
        </div>
      </div>

      {/* Upcoming Career Events */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h3 className="font-semibold text-gray-900 mb-4">Upcoming Career Events</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {events.map(event => (
            <div key={event.id} className="p-4 border border-gray-200 rounded-lg hover:shadow-md transition-shadow">
              <div className="flex items-start justify-between mb-2">
                <div>
                  <h4 className="font-medium text-gray-900">{event.name}</h4>
                  <span className="inline-block px-2 py-0.5 bg-blue-100 text-blue-700 rounded text-xs mt-1">
                    {event.type}
                  </span>
                </div>
                {event.registered && (
                  <span className="px-2 py-1 bg-green-100 text-green-700 rounded text-xs font-medium">
                    Registered
                  </span>
                )}
              </div>
              <div className="space-y-1 mt-3 text-sm text-gray-600">
                <div className="flex items-center gap-2">
                  <Clock className="size-4" />
                  <span>{new Date(event.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} at {event.time}</span>
                </div>
                <div className="flex items-center gap-2">
                  <MapPin className="size-4" />
                  <span>{event.location}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Building className="size-4" />
                  <span>{event.companies.join(', ')}</span>
                </div>
              </div>
              {!event.registered && (
                <button
                  onClick={() => toast.success(`Registered for ${event.name}`)}
                  className="px-4 py-1.5 bg-blue-50 text-blue-700 rounded-md hover:bg-blue-100 transition-colors text-sm font-medium"
                >
                  Register
                </button>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Job Listings */}
      <div>
        <h3 className="font-semibold text-gray-900 mb-4">Available Opportunities ({filteredJobs.length})</h3>
        <div className="space-y-4">
          {filteredJobs.map(job => (
            <div key={job.id} className="bg-white rounded-lg border border-gray-200 p-6 hover:shadow-lg transition-shadow">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <div className="flex items-start gap-3">
                    <div className="p-3 bg-gray-100 rounded-lg">
                      <Building className="size-6 text-gray-600" />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-semibold text-gray-900 text-lg">{job.title}</h4>
                      <p className="text-gray-700 mt-1">{job.company}</p>
                      <div className="flex flex-wrap items-center gap-3 mt-2 text-sm text-gray-600">
                        <div className="flex items-center gap-1">
                          <MapPin className="size-4" />
                          <span>{job.location}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <DollarSign className="size-4" />
                          <span>{job.salary}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Clock className="size-4" />
                          <span>Posted {new Date(job.posted).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="flex flex-col items-end gap-2">
                  <span className={`px-3 py-1 rounded-full text-xs font-medium ${getTypeColor(job.type)}`}>
                    {job.type.split('-').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ')}
                  </span>
                  {job.isSaved && (
                    <span className="text-yellow-500">
                      <BookmarkPlus className="size-5 fill-current" />
                    </span>
                  )}
                </div>
              </div>

              <p className="text-gray-600 text-sm mb-4">{job.description}</p>

              <div className="mb-4">
                <p className="text-sm font-medium text-gray-700 mb-2">Requirements:</p>
                <div className="flex flex-wrap gap-2">
                  {job.requirements.map((req, index) => (
                    <span key={index} className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-xs">
                      ✓ {req}
                    </span>
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-between pt-4 border-t border-gray-100">
                <p className="text-sm text-gray-600">
                  Deadline: <span className="font-medium text-gray-900">
                    {new Date(job.deadline).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                  </span>
                </p>
                <div className="flex gap-3">
                  <button
                    onClick={() => toast.success(`Application started for ${job.title} at ${job.company}`)}
                    className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium"
                  >
                    Apply Now
                  </button>
                  <button
                    onClick={() => toast.success('Job saved to your list')}
                    className="px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors text-sm font-medium"
                  >
                    Save
                  </button>
                </div>
              </div>
            </div>

          ))}
        </div>
      </div>

      {/* Career Resources */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg p-6 text-white">
        <h3 className="text-xl font-semibold mb-4">Career Resources</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white/10 rounded-lg p-4 backdrop-blur">
            <h4 className="font-medium mb-2">📝 Resume Builder</h4>
            <p className="text-sm text-blue-50 mb-3">Create a professional resume with our templates</p>
            <button className="text-sm underline">Get Started</button>
          </div>
          <div className="bg-white/10 rounded-lg p-4 backdrop-blur">
            <h4 className="font-medium mb-2">🎯 Interview Prep</h4>
            <p className="text-sm text-blue-50 mb-3">Practice common interview questions and techniques</p>
            <button className="text-sm underline">Start Practicing</button>
          </div>
          <div className="bg-white/10 rounded-lg p-4 backdrop-blur">
            <h4 className="font-medium mb-2">🤝 Mock Interviews</h4>
            <p className="text-sm text-blue-50 mb-3">Schedule mock interviews with career counselors</p>
            <button className="text-sm underline">Book Session</button>
          </div>
        </div>
      </div>
    </div >
  );
}
