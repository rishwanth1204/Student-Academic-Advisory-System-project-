import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { Course, EnrolledCourse, Appointment, Notification, TranscriptEntry, Message, StudyGroup, Deadline } from '../types';
import { MOCK_COURSES, MOCK_ENROLLED_COURSES, MOCK_APPOINTMENTS, MOCK_NOTIFICATIONS, MOCK_TRANSCRIPT, MOCK_STUDY_GROUPS, MOCK_DEADLINES } from '../services/mockData';
// import client from '../api/client';

interface StudentState {
    enrolledCourses: EnrolledCourse[];
    availableCourses: Course[];
    transcript: TranscriptEntry[];
    appointments: Appointment[];
    notifications: Notification[];
    messages: Message[];
    studyGroups: StudyGroup[];
    deadlines: Deadline[];

    // Actions
    fetchData: () => Promise<void>;
    fetchCourses: () => Promise<void>;
    registerCourse: (courseId: string) => Promise<void>;
    dropCourse: (courseId: string) => Promise<void>;
    scheduleAppointment: (appointment: Omit<Appointment, 'id' | 'status'>) => Promise<void>;
    cancelAppointment: (appointmentId: string) => Promise<void>;
    markNotificationRead: (id: string) => void;
    sendMessage: (text: string) => void;
    receiveMessage: (text: string) => void;
    joinStudyGroup: (groupId: string) => void;
    leaveStudyGroup: (groupId: string) => void;
    createStudyGroup: (group: StudyGroup) => void;
    calculateGPA: () => number;
    getTotalCredits: () => number;
}

export const useStudentStore = create<StudentState>()(
    persist(
        (set, get) => ({
            enrolledCourses: [],
            availableCourses: [],
            transcript: [],
            appointments: [],
            notifications: [],
            studyGroups: [],
            messages: [],
            deadlines: [],

            fetchData: async () => {
                // Simulate API call
                await new Promise(resolve => setTimeout(resolve, 800));
                set({
                    enrolledCourses: MOCK_ENROLLED_COURSES,
                    notifications: MOCK_NOTIFICATIONS,
                    transcript: MOCK_TRANSCRIPT,
                    appointments: MOCK_APPOINTMENTS,
                    studyGroups: MOCK_STUDY_GROUPS,
                    deadlines: MOCK_DEADLINES
                });
            },
            // ... rest of the file remains same ...
            fetchCourses: async () => {
                await new Promise(resolve => setTimeout(resolve, 500));
                set({ availableCourses: MOCK_COURSES });
            },

            registerCourse: async (courseId) => {
                await new Promise(resolve => setTimeout(resolve, 600));
                const course = get().availableCourses.find(c => c.id === courseId);
                if (course) {
                    const newEnrollment: EnrolledCourse = {
                        ...course,
                        grade: 'N/A',
                        progress: 0,
                        enrollmentDate: new Date().toISOString(),
                        id: course.id // Use same ID for simplicity in mock
                    };
                    set(state => ({
                        enrolledCourses: [...state.enrolledCourses, newEnrollment]
                    }));
                }
            },

            dropCourse: async (courseId) => {
                await new Promise(resolve => setTimeout(resolve, 600));
                set((state) => ({
                    enrolledCourses: state.enrolledCourses.filter(c => c.id !== courseId)
                }));
            },

            scheduleAppointment: async (appointmentData) => {
                await new Promise(resolve => setTimeout(resolve, 600));
                const newAppointment: Appointment = {
                    ...appointmentData,
                    id: Math.random().toString(36).substr(2, 9),
                    status: 'pending'
                };
                set(state => ({
                    appointments: [...state.appointments, newAppointment]
                }));
            },

            cancelAppointment: async (appointmentId) => {
                await new Promise(resolve => setTimeout(resolve, 600));
                set(state => ({
                    appointments: state.appointments.map(a =>
                        a.id === appointmentId ? { ...a, status: 'cancelled' } : a
                    )
                }));
            },

            joinStudyGroup: (groupId) => {
                set(state => ({
                    studyGroups: state.studyGroups.map(g =>
                        g.id === groupId ? { ...g, isJoined: true, members: g.members + 1 } : g
                    )
                }));
            },

            leaveStudyGroup: (groupId) => {
                set(state => ({
                    studyGroups: state.studyGroups.map(g =>
                        g.id === groupId ? { ...g, isJoined: false, members: g.members - 1 } : g
                    )
                }));
            },

            createStudyGroup: (group) => {
                set(state => ({
                    studyGroups: [...state.studyGroups, group]
                }));
            },

            markNotificationRead: (id) => {
                set(state => ({
                    notifications: state.notifications.map(n =>
                        n.id === id ? { ...n, read: true } : n
                    )
                }));
            },

            sendMessage: (text) => {
                const newMessage: Message = {
                    id: Math.random().toString(36).substr(2, 9),
                    sender: 'user',
                    text,
                    timestamp: new Date().toISOString(),
                    read: true
                };
                set(state => ({ messages: [...(state.messages || []), newMessage] }));
            },

            receiveMessage: (text) => {
                const newMessage: Message = {
                    id: Math.random().toString(36).substr(2, 9),
                    sender: 'advisor',
                    text,
                    timestamp: new Date().toISOString(),
                    read: false
                };
                set(state => ({ messages: [...(state.messages || []), newMessage] }));
            },

            calculateGPA: () => {
                const { transcript } = get();
                if (transcript.length === 0) return 0.00;
                const totalPoints = transcript.reduce((sum, entry) => sum + entry.qualityPoints, 0);
                const totalCredits = transcript.reduce((sum, entry) => sum + entry.credits, 0);
                return totalCredits > 0 ? Number((totalPoints / totalCredits).toFixed(2)) : 0.00;
            },

            getTotalCredits: () => {
                const { transcript, enrolledCourses } = get();
                const completed = transcript.reduce((sum, t) => sum + t.credits, 0);
                const current = enrolledCourses.reduce((sum, c) => sum + c.credits, 0);
                return completed + current;
            }
        }),
        {
            name: 'student-storage',
            partialize: (state) => ({
                // Could persist less now that fetching is reliable, but keeping some for offline feels okay
                enrolledCourses: state.enrolledCourses,
                appointments: state.appointments,
                notifications: state.notifications,
                transcript: state.transcript,
                studyGroups: state.studyGroups,
                deadlines: state.deadlines
            }),
        }
    )
);
