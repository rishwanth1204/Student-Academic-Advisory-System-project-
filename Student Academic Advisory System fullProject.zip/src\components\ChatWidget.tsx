import React, { useState, useEffect, useRef } from 'react';
import { useStudentStore } from '../store/useStudentStore';
import { socket } from '../api/socket';
import { MessageCircle, X, Send, User, CheckCheck } from 'lucide-react';
import { useAuthStore } from '../store/useAuthStore';

export function ChatWidget() {
    const [isOpen, setIsOpen] = useState(false);
    const [inputText, setInputText] = useState('');
    const [isTyping, setIsTyping] = useState(false);
    const messagesEndRef = useRef<HTMLDivElement>(null);

    const { messages, sendMessage, receiveMessage } = useStudentStore();
    const { user } = useAuthStore();

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    };

    useEffect(() => {
        scrollToBottom();
    }, [messages, isTyping]);

    // Socket.io Integration
    useEffect(() => {
        if (isOpen) {
            socket.connect();
            if (user) {
                socket.emit('join_chat', user.id);
            }
        }

        const onReceiveMessage = (data: any) => {
            console.log('Got message from socket:', data);
            receiveMessage(data.text);
            setIsTyping(false);
        };

        socket.on('receive_message', onReceiveMessage);

        return () => {
            socket.off('receive_message', onReceiveMessage);
            if (!isOpen) {
                // Optional: maintain connection if you want background notifications
                // socket.disconnect(); 
            }
        };
    }, [isOpen, user, receiveMessage]);

    const handleSend = async () => {
        if (!inputText.trim()) return;

        const text = inputText;
        setInputText('');
        sendMessage(text); // Optimistic UI update

        if (socket.connected && user) {
            socket.emit('send_message', {
                senderId: user.id,
                text: text,
                recipientId: 'advisor'
            });
            setIsTyping(true); // Assume waiting for reply
        } else {
            // Fallback for demo if socket fails or no user
            setTimeout(() => {
                receiveMessage("I'm looking into that for you. Can you provide more details?");
            }, 2000);
        }
    };

    const handleKeyPress = (e: React.KeyboardEvent) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            handleSend();
        }
    };

    return (
        <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end">
            {/* Chat Window */}
            {isOpen && (
                <div className="mb-4 w-[380px] h-[550px] bg-white rounded-2xl shadow-2xl border border-gray-100 flex flex-col overflow-hidden animate-in slide-in-from-bottom-10 fade-in duration-200">

                    {/* Header */}
                    <div className="bg-gradient-to-r from-blue-600 to-indigo-700 p-4 flex items-center justify-between shrink-0">
                        <div className="flex items-center space-x-3">
                            <div className="relative">
                                <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center text-white backdrop-blur-sm">
                                    <User size={20} />
                                </div>
                                <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-400 border-2 border-blue-600 rounded-full"></div>
                            </div>
                            <div className="text-white">
                                <h3 className="font-semibold text-sm">Academic Advisor</h3>
                                <p className="text-xs text-blue-100 opacity-90">Online now</p>
                            </div>
                        </div>
                        <button
                            onClick={() => setIsOpen(false)}
                            className="text-white/80 hover:text-white hover:bg-white/10 p-2 rounded-full transition-colors"
                        >
                            <X size={18} />
                        </button>
                    </div>

                    {/* Messages Area */}
                    <div className="flex-1 overflow-y-auto p-4 bg-gray-50 space-y-4">
                        {messages?.length === 0 && (
                            <div className="text-center text-gray-400 text-sm mt-8">
                                <p>Start a conversation with your advisor.</p>
                                <p className="text-xs mt-1">Typical reply time: few minutes</p>
                            </div>
                        )}

                        {messages?.map((msg) => (
                            <div
                                key={msg.id}
                                className={`flex w-full ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                            >
                                <div
                                    className={`max-w-[80%] rounded-2xl px-4 py-2.5 shadow-sm text-sm ${msg.sender === 'user'
                                        ? 'bg-blue-600 text-white rounded-br-none'
                                        : 'bg-white text-gray-800 border border-gray-100 rounded-bl-none'
                                        }`}
                                >
                                    <p>{msg.text}</p>
                                    <div className={`text-[10px] mt-1 flex items-center justify-end space-x-1 ${msg.sender === 'user' ? 'text-blue-100' : 'text-gray-400'}`}>
                                        <span>{new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                                        {msg.sender === 'user' && <CheckCheck size={12} />}
                                    </div>
                                </div>
                            </div>
                        ))}

                        {isTyping && (
                            <div className="flex justify-start w-full">
                                <div className="bg-white border border-gray-100 rounded-2xl rounded-bl-none px-4 py-3 shadow-sm flex space-x-1 items-center">
                                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
                                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce [animation-delay:-0.15s]"></div>
                                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                                </div>
                            </div>
                        )}
                        <div ref={messagesEndRef} />
                    </div>

                    {/* Input Area */}
                    <div className="p-4 bg-white border-t border-gray-100 shrink-0">
                        <div className="flex items-center space-x-2 bg-gray-50 rounded-full px-4 py-2 border border-gray-200 focus-within:border-blue-500 focus-within:ring-2 focus-within:ring-blue-100 transition-all">
                            <input
                                type="text"
                                value={inputText}
                                onChange={(e) => setInputText(e.target.value)}
                                onKeyDown={handleKeyPress}
                                placeholder="Type a message..."
                                className="flex-1 bg-transparent border-none outline-none text-sm text-gray-700 placeholder:text-gray-400"
                            />
                            <button
                                onClick={handleSend}
                                disabled={!inputText.trim()}
                                className="p-2 bg-blue-600 text-white rounded-full hover:bg-blue-700 disabled:opacity-50 disabled:hover:bg-blue-600 transition-colors shadow-sm"
                            >
                                <Send size={16} />
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* Launcher Button */}
            <button
                onClick={() => setIsOpen(!isOpen)}
                className={`${isOpen ? 'scale-0 opacity-0' : 'scale-100 opacity-100'
                    } transition-all duration-300 transform bg-blue-600 hover:bg-blue-700 text-white p-4 rounded-full shadow-lg hover:shadow-blue-500/30 flex items-center justify-center group`}
            >
                <span className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full border-2 border-white"></span>
                <MessageCircle size={28} className="group-hover:scale-110 transition-transform" />
            </button>
        </div>
    );
}
