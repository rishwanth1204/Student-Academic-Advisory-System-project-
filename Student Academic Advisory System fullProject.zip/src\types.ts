export interface User {
    id: string;
    name: string;
    email: string;
    role: 'student' | 'advisor' | 'admin';
    avatar?: string;
}

export interface Student extends User {
    studentId: string;
    gpa: number;
    major: string;
    creditsEarned: number;
    totalCreditsRequired: number;
    startYear: number;
    expectedGraduation: string;
    advisor?: string;
}

export interface Course {
    id: string;
    code: string;
    name: string;
    credits: number;
    instructor: string;
    schedule: string;
    location: string;
    description?: string;
    prerequisites?: string[];
    capacity: number;
    enrolled: number;
    semester: string;
    status: 'open' | 'waitlist' | 'closed';
    rating?: number;
    syllabus?: string; // URL to syllabus or content
}

export interface EnrolledCourse extends Course {
    grade?: string; // e.g., 'A', 'B+', or null if in progress
    progress: number; // 0-100
    enrollmentDate: string;
}

export interface TranscriptEntry {
    courseId: string;
    courseCode: string;
    courseName: string;
    semester: string;
    grade: string;
    credits: number;
    qualityPoints: number; // For GPA calculation
}

export interface Notification {
    id: string;
    title: string;
    message: string;
    date: string; // ISO string
    read: boolean;
    type: 'info' | 'warning' | 'success' | 'alert';
}

export interface Appointment {
    id: string;
    advisorId: string;
    advisorName: string;
    date: string;
    time: string;
    purpose: string;
    status: 'pending' | 'confirmed' | 'cancelled' | 'completed';
    type: 'in-person' | 'virtual';
    notes?: string;
    studentId?: string;
}

export interface StudyGroup {
    id: string;
    name: string;
    course: string;
    members: number;
    maxMembers: number;
    schedule: string;
    location: string;
    nextMeeting: string;
    description: string;
    organizer: string;
    isJoined: boolean;
}

export interface Message {
    id: string;
    sender: 'user' | 'advisor';
    text: string;
    timestamp: string;
    read: boolean;
}

export interface Deadline {
    id: string;
    title: string;
    courseCode: string;
    dueDate: string; // ISO string
    type: 'assignment' | 'exam' | 'project';
}
