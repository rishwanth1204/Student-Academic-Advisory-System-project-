# Student Advisory System Backend

## Setup
1. Install dependencies:
   ```bash
   npm install
   ```

2. Create a `.env` file in this directory:
   ```env
   PORT=5000
   MONGODB_URI=mongodb://localhost:27017/student_advisory
   JWT_SECRET=your_jwt_secret
   ```

3. Start the server:
   ```bash
   npm start
   # or for development
   npm run dev
   ```

## API Endpoints
- POST `/api/auth/login` - Login
- POST `/api/auth/register` - Register
- GET `/api/courses` - List courses
- GET `/api/students/:id/transcript` - Get transcript
- GET `/api/appointments/student/:studentId` - Get appointments

## Data Seeding
You may need to seed the database with initial Course data to make the frontend useful.
