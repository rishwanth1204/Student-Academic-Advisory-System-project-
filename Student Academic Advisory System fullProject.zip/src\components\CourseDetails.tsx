import { useParams, useNavigate } from 'react-router-dom';
import { useStudentStore } from '../store/useStudentStore';
import { ArrowLeft, Clock, MapPin, User, BookOpen, FileText } from 'lucide-react';
import { toast } from 'sonner';

export function CourseDetails() {
    const { id } = useParams();
    const navigate = useNavigate();
    const { enrolledCourses, dropCourse } = useStudentStore();

    const course = enrolledCourses.find(c => c.id === id);

    if (!course) {
        return (
            <div className="p-8 text-center">
                <h2 className="text-xl font-bold text-gray-900">Course not found</h2>
                <button
                    onClick={() => navigate('/courses')}
                    className="mt-4 text-blue-600 hover:underline"
                >
                    Back to Courses
                </button>
            </div>
        );
    }

    const handleDrop = async () => {
        if (window.confirm(`Are you sure you want to drop ${course.name}?`)) {
            await dropCourse(course.id);
            toast.success('Course dropped successfully');
            navigate('/courses');
        }
    };

    return (
        <div className="max-w-4xl mx-auto space-y-6">
            <button
                onClick={() => navigate('/courses')}
                className="flex items-center text-gray-600 hover:text-gray-900 transition-colors"
            >
                <ArrowLeft className="size-4 mr-2" />
                Back to Courses
            </button>

            <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
                <div className="h-32 bg-gradient-to-r from-blue-600 to-indigo-700 p-6 flex items-end">
                    <h1 className="text-3xl font-bold text-white">{course.name}</h1>
                </div>

                <div className="p-8 space-y-8">
                    <div className="flex justify-between items-start">
                        <div>
                            <h2 className="text-xl font-semibold text-gray-900 mb-2">{course.code}</h2>
                            <p className="text-gray-600 max-w-2xl">{course.description || "No description available for this course."}</p>
                        </div>
                        <div className="flex flex-col items-end gap-2">
                            <span className="px-4 py-1.5 bg-blue-100 text-blue-700 rounded-full font-medium">
                                {course.credits} Credits
                            </span>
                            <span className={`px-4 py-1.5 rounded-full font-medium ${course.status === 'open' ? 'bg-green-100 text-green-700' :
                                course.status === 'waitlist' ? 'bg-yellow-100 text-yellow-700' : 'bg-red-100 text-red-700'
                                }`}>
                                {course.status.toUpperCase()}
                            </span>
                        </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-4">
                            <h3 className="font-semibold text-gray-900 flex items-center gap-2">
                                <Clock className="size-5 text-gray-400" />
                                Schedule
                            </h3>
                            <div className="bg-gray-50 p-4 rounded-lg">
                                <p className="text-gray-700">{course.schedule}</p>
                                <p className="text-sm text-gray-500 mt-1">{course.semester}</p>
                            </div>
                        </div>

                        <div className="space-y-4">
                            <h3 className="font-semibold text-gray-900 flex items-center gap-2">
                                <MapPin className="size-5 text-gray-400" />
                                Location
                            </h3>
                            <div className="bg-gray-50 p-4 rounded-lg">
                                <p className="text-gray-700">{course.location}</p>
                                <p className="text-sm text-gray-500 mt-1">Campus Map Code: {course.location.split(' ')[0]}</p>
                            </div>
                        </div>

                        <div className="space-y-4">
                            <h3 className="font-semibold text-gray-900 flex items-center gap-2">
                                <User className="size-5 text-gray-400" />
                                Instructor
                            </h3>
                            <div className="bg-gray-50 p-4 rounded-lg">
                                <p className="text-gray-700 font-medium">{course.instructor}</p>
                                <p className="text-sm text-gray-500 mt-1">Office Hours: Mon/Wed 2-4 PM</p>
                            </div>
                        </div>

                        <div className="space-y-4">
                            <h3 className="font-semibold text-gray-900 flex items-center gap-2">
                                <BookOpen className="size-5 text-gray-400" />
                                Prerequisites
                            </h3>
                            <div className="bg-gray-50 p-4 rounded-lg">
                                {course.prerequisites && course.prerequisites.length > 0 ? (
                                    <div className="flex flex-wrap gap-2">
                                        {course.prerequisites.map(pre => (
                                            <span key={pre} className="px-2 py-1 bg-white border border-gray-200 rounded text-sm text-gray-600">
                                                {pre}
                                            </span>
                                        ))}
                                    </div>
                                ) : (
                                    <p className="text-gray-500">None</p>
                                )}
                            </div>
                        </div>
                    </div>

                    <div className="border-t border-gray-100 pt-8">
                        <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
                            <FileText className="size-5 text-blue-600" />
                            Course Syllabus
                        </h3>
                        <div className="bg-blue-50 border border-blue-100 p-6 rounded-xl flex items-center justify-between">
                            <div>
                                <h4 className="font-medium text-blue-900">Syllabus - {course.semester}</h4>
                                <p className="text-sm text-blue-700 mt-1">PDF Document • 2.4 MB</p>
                            </div>
                            <div className="flex gap-3">
                                <button
                                    onClick={() => window.open(course.syllabus || '#', '_blank')}
                                    className="px-4 py-2 bg-white text-blue-700 border border-blue-200 rounded-lg hover:bg-blue-50 transition-colors text-sm font-medium shadow-sm"
                                >
                                    View Online
                                </button>
                                <button
                                    onClick={() => toast.success('Syllabus downloaded!')}
                                    className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium shadow-sm"
                                >
                                    Download PDF
                                </button>
                            </div>
                        </div>
                    </div>

                    <div className="pt-4 flex justify-end">
                        <button
                            onClick={handleDrop}
                            className="px-6 py-2 border border-red-200 text-red-600 rounded-lg hover:bg-red-50 transition-colors font-medium"
                        >
                            Drop Course
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
}
