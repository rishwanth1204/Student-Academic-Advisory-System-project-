const http = require('http');

const post = (path, data) => {
    return new Promise((resolve, reject) => {
        const options = {
            hostname: 'localhost',
            port: 5000,
            path: path,
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Content-Length': data.length
            }
        };

        const req = http.request(options, (res) => {
            let body = '';
            res.on('data', (chunk) => body += chunk);
            res.on('end', () => resolve({ status: res.statusCode, body: JSON.parse(body) }));
        });

        req.on('error', (e) => reject(e));
        req.write(data);
        req.end();
    });
};

const get = (path, token) => {
    return new Promise((resolve, reject) => {
        const options = {
            hostname: 'localhost',
            port: 5000,
            path: path,
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        };

        const req = http.request(options, (res) => {
            let body = '';
            res.on('data', (chunk) => body += chunk);
            res.on('end', () => resolve({ status: res.statusCode, body: JSON.parse(body) }));
        });

        req.on('error', (e) => reject(e));
        req.end();
    });
};

async function testParams() {
    try {
        console.log('1. Registering new student...');
        const regData = JSON.stringify({
            name: "Test Student",
            email: "test" + Date.now() + "@example.com",
            password: "password123"
        });
        const regRes = await post('/api/auth/register', regData);
        console.log('Register Status:', regRes.status);
        if (regRes.status !== 201) throw new Error('Registration failed');
        const token = regRes.body.token;
        console.log('Token received');

        console.log('\n2. Getting Profile...');
        const profileRes = await get('/api/students/profile', token);
        console.log('Profile Status:', profileRes.status);
        console.log('Student Name:', profileRes.body.name);

        console.log('\n3. Getting Courses...');
        const coursesRes = await get('/api/courses', token);
        console.log('Courses Status:', coursesRes.status);
        console.log('Number of courses:', coursesRes.body.length);
        const courseId = coursesRes.body[0]._id;

        console.log('\n4. Enrolling in course ' + courseId + '...');
        const enrollData = JSON.stringify({ courseId: courseId });

        // Custom post for Enroll since it needs auth
        const enroll = () => {
            return new Promise((resolve, reject) => {
                const options = {
                    hostname: 'localhost',
                    port: 5000,
                    path: '/api/courses/enroll',
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Content-Length': enrollData.length,
                        'Authorization': `Bearer ${token}`
                    }
                };

                const req = http.request(options, (res) => {
                    let body = '';
                    res.on('data', (chunk) => body += chunk);
                    res.on('end', () => resolve({ status: res.statusCode, body: JSON.parse(body) }));
                });

                req.on('error', (e) => reject(e));
                req.write(enrollData);
                req.end();
            });
        }

        const enrollRes = await enroll();
        console.log('Enroll Status:', enrollRes.status);
        console.log('Enroll Message:', enrollRes.body.message);

        console.log('\nTest Completed Successfully!');
    } catch (err) {
        console.error('Test Failed:', err);
    }
}

testParams();
