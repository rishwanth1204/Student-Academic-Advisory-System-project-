// const Course = require('../models/Course');
// const Student = require('../models/Student');
const { courses, students } = require('../data/mockData');

// @desc    Get all courses (with optional filtering)
// @route   GET /api/courses
// @access  Public
exports.getCourses = async (req, res, next) => {
    try {
        const { search } = req.query;
        let results = courses;

        if (search) {
            const regex = new RegExp(search, 'i');
            results = courses.filter(course =>
                regex.test(course.name) || regex.test(course.code)
            );
        }

        res.json(results);
    } catch (err) {
        next(err);
    }
};

// @desc    Enroll in a course
// @route   POST /api/courses/enroll
// @access  Private
exports.enrollCourse = async (req, res, next) => {
    try {
        const { courseId } = req.body;

        // Find Student linked to User
        // const student = await Student.findOne({ userId: req.user._id });
        const student = students.find(s => s.userId === req.user._id);

        if (!student) {
            return res.status(404).json({ message: 'Student profile not found' });
        }

        // Find Course
        // const course = await Course.findById(courseId);
        const course = courses.find(c => c._id === courseId);

        if (!course) {
            return res.status(404).json({ message: 'Course not found' });
        }

        // Check if already enrolled
        // Note: checking by string comparison of IDs
        const isEnrolled = student.enrolledCourses.some(
            enrollment => enrollment.courseId && enrollment.courseId.toString() === courseId
        );

        if (isEnrolled) {
            return res.status(400).json({ message: 'Already enrolled in this course' });
        }

        // Add to Student's enrolled courses
        const newEnrollment = {
            courseId: course._id,
            code: course.code,
            name: course.name,
            credits: course.credits,
            progress: 0,
            enrollmentDate: new Date(),
            semester: 'Fall 2026', // Ideally dynamic or from current term
            grade: 'IP' // In Progress
        };

        student.enrolledCourses.push(newEnrollment);
        // await student.save();

        // Increment Course enrollment count
        course.enrolled = (course.enrolled || 0) + 1;
        // await course.save();

        res.json({ message: 'Enrolled successfully', enrolledCourses: student.enrolledCourses });
    } catch (err) {
        next(err);
    }
};
