import { useState } from 'react';
import { toast } from 'sonner';
import { Search, Star, Clock, DollarSign, Video, MapPin, Calendar, MessageSquare } from 'lucide-react';

interface Tutor {
  id: string;
  name: string;
  photo: string;
  subjects: string[];
  rating: number;
  reviews: number;
  hourlyRate: number;
  availability: string;
  type: 'peer' | 'professional';
  bio: string;
}

export function Tutoring() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSubject, setSelectedSubject] = useState('all');

  const tutors: Tutor[] = [
    {
      id: '1',
      name: 'Alex Chen',
      photo: 'AC',
      subjects: ['Data Structures', 'Algorithms'],
      rating: 4.9,
      reviews: 47,
      hourlyRate: 25,
      availability: 'Mon-Fri 4-8 PM',
      type: 'peer',
      bio: 'Senior CS student with 3.9 GPA. Specializes in algorithm optimization and data structure implementation.'
    },
    {
      id: '2',
      name: 'Dr. Maria Rodriguez',
      photo: 'MR',
      subjects: ['Database Systems', 'SQL'],
      rating: 5.0,
      reviews: 89,
      hourlyRate: 50,
      availability: 'Tue/Thu 6-9 PM',
      type: 'professional',
      bio: 'PhD in Computer Science with 10+ years of industry experience. Former senior database architect.'
    },
    {
      id: '3',
      name: 'James Wilson',
      photo: 'JW',
      subjects: ['Web Development', 'JavaScript', 'React'],
      rating: 4.8,
      reviews: 62,
      hourlyRate: 30,
      availability: 'Mon/Wed/Fri 5-9 PM',
      type: 'peer',
      bio: 'Full-stack developer and CS senior. Built 15+ web applications. Passionate about teaching modern web tech.'
    },
    {
      id: '4',
      name: 'Emily Zhang',
      photo: 'EZ',
      subjects: ['Operating Systems', 'Computer Architecture'],
      rating: 4.7,
      reviews: 34,
      hourlyRate: 25,
      availability: 'Weekends 10 AM-6 PM',
      type: 'peer',
      bio: 'Graduate student specializing in systems programming. TA for OS course for 2 years.'
    },
    {
      id: '5',
      name: 'Prof. David Kumar',
      photo: 'DK',
      subjects: ['Algorithms', 'Theory of Computation'],
      rating: 5.0,
      reviews: 123,
      hourlyRate: 60,
      availability: 'Sat/Sun 2-6 PM',
      type: 'professional',
      bio: 'Assistant Professor with research in algorithm design. Published 20+ papers in top conferences.'
    },
    {
      id: '6',
      name: 'Lisa Thompson',
      photo: 'LT',
      subjects: ['Python', 'Machine Learning'],
      rating: 4.9,
      reviews: 71,
      hourlyRate: 40,
      availability: 'Tue/Thu 7-10 PM',
      type: 'professional',
      bio: 'ML engineer at tech startup. Experienced in teaching Python and ML fundamentals.'
    }
  ];

  const subjects = ['all', 'Data Structures', 'Algorithms', 'Database Systems', 'Web Development', 'Operating Systems', 'Python', 'Machine Learning'];

  const filteredTutors = tutors.filter(tutor => {
    const matchesSearch = tutor.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tutor.subjects.some(s => s.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesSubject = selectedSubject === 'all' || tutor.subjects.includes(selectedSubject);
    return matchesSearch && matchesSubject;
  });

  const myBookings = [
    {
      id: '1',
      tutor: 'Alex Chen',
      subject: 'Data Structures',
      date: '2026-02-08',
      time: '5:00 PM - 6:00 PM',
      type: 'online',
      status: 'confirmed'
    },
    {
      id: '2',
      tutor: 'James Wilson',
      subject: 'React Fundamentals',
      date: '2026-02-11',
      time: '6:00 PM - 7:00 PM',
      type: 'in-person',
      status: 'pending'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h2 className="text-2xl font-semibold text-gray-900 mb-4">Peer Tutoring</h2>

        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 size-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search tutors or subjects..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <select
            value={selectedSubject}
            onChange={(e) => setSelectedSubject(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            {subjects.map(subject => (
              <option key={subject} value={subject}>
                {subject === 'all' ? 'All Subjects' : subject}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* My Bookings */}
      {myBookings.length > 0 && (
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h3 className="font-semibold text-gray-900 mb-4">My Upcoming Sessions</h3>
          <div className="space-y-3">
            {myBookings.map(booking => (
              <div key={booking.id} className="flex items-center justify-between p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <div className="flex items-center gap-4">
                  <Calendar className="size-5 text-blue-600" />
                  <div>
                    <p className="font-medium text-gray-900">{booking.subject} with {booking.tutor}</p>
                    <div className="flex items-center gap-3 mt-1 text-sm text-gray-600">
                      <span>{new Date(booking.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}</span>
                      <span>•</span>
                      <span>{booking.time}</span>
                      <span>•</span>
                      <span>{booking.type === 'online' ? '📹 Online' : '📍 In-Person'}</span>
                    </div>
                  </div>
                </div>
                <span className={`px-3 py-1 rounded-full text-xs font-medium ${booking.status === 'confirmed' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'
                  }`}>
                  {booking.status}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tutors Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filteredTutors.map(tutor => (
          <div key={tutor.id} className="bg-white rounded-lg border border-gray-200 p-6 hover:shadow-lg transition-shadow">
            <div className="flex items-start gap-4">
              <div className="size-16 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white text-xl font-semibold flex-shrink-0">
                {tutor.photo}
              </div>
              <div className="flex-1">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="font-semibold text-gray-900">{tutor.name}</h3>
                    <span className="inline-block px-2 py-0.5 bg-gray-100 text-gray-700 rounded text-xs font-medium mt-1">
                      {tutor.type === 'peer' ? '👥 Peer Tutor' : '🎓 Professional'}
                    </span>
                  </div>
                  <div className="text-right">
                    <div className="flex items-center gap-1 text-yellow-500">
                      <Star className="size-4 fill-current" />
                      <span className="text-sm font-semibold text-gray-900">{tutor.rating}</span>
                    </div>
                    <p className="text-xs text-gray-500 mt-0.5">({tutor.reviews} reviews)</p>
                  </div>
                </div>

                <p className="text-sm text-gray-600 mt-3">{tutor.bio}</p>

                <div className="flex flex-wrap gap-2 mt-3">
                  {tutor.subjects.map((subject, index) => (
                    <span key={index} className="px-2 py-1 bg-blue-100 text-blue-700 rounded text-xs">
                      {subject}
                    </span>
                  ))}
                </div>

                <div className="grid grid-cols-2 gap-4 mt-4 pt-4 border-t border-gray-100">
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <DollarSign className="size-4" />
                    <span>${tutor.hourlyRate}/hour</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <Clock className="size-4" />
                    <span>{tutor.availability}</span>
                  </div>
                </div>

                <div className="flex gap-2 mt-4">
                  <button
                    onClick={() => toast.success(`Booking session with ${tutor.name}...`)}
                    className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium"
                  >
                    Book Session
                  </button>
                  <button
                    onClick={() => toast.info(`Starting chat with ${tutor.name}...`)}
                    className="px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors text-sm font-medium"
                  >
                    <MessageSquare className="size-4" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Tutoring Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-blue-100 rounded-lg">
              <Clock className="size-6 text-blue-600" />
            </div>
            <div>
              <p className="text-2xl font-semibold text-gray-900">12</p>
              <p className="text-sm text-gray-500">Hours This Month</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-green-100 rounded-lg">
              <Star className="size-6 text-green-600" />
            </div>
            <div>
              <p className="text-2xl font-semibold text-gray-900">4.8</p>
              <p className="text-sm text-gray-500">Avg Tutor Rating</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-purple-100 rounded-lg">
              <Video className="size-6 text-purple-600" />
            </div>
            <div>
              <p className="text-2xl font-semibold text-gray-900">8</p>
              <p className="text-sm text-gray-500">Sessions Completed</p>
            </div>
          </div>
        </div>
      </div>

      {/* Become a Tutor */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-xl font-semibold">Become a Tutor</h3>
            <p className="text-blue-100 mt-2">
              Share your knowledge and earn money. Help fellow students succeed while building your resume.
            </p>
          </div>
          <button className="px-6 py-3 bg-white text-blue-600 rounded-lg hover:bg-blue-50 transition-colors font-medium whitespace-nowrap">
            Apply Now
          </button>
        </div>
      </div>
    </div>
  );
}
