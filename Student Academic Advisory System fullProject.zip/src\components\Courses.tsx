import { BookOpen, Clock, MapPin, User, Star, Plus } from 'lucide-react';
import { useStudentStore } from '../store/useStudentStore';
import { toast } from 'sonner';
import { useNavigate } from 'react-router-dom';

export function Courses() {
  const { enrolledCourses } = useStudentStore();
  const navigate = useNavigate(); // Hook

  const getStatusColor = (progress: number) => {
    if (progress >= 90) return 'text-green-600 bg-green-50';
    if (progress >= 70) return 'text-blue-600 bg-blue-50';
    if (progress >= 50) return 'text-yellow-600 bg-yellow-50';
    return 'text-gray-600 bg-gray-50';
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-900">My Courses</h2>
        <div className="flex gap-2">
          <button
            onClick={() => navigate('/registration')}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-full hover:bg-blue-700 transition-colors shadow-sm text-sm font-medium"
          >
            <Plus className="size-4" />
            Add Course
          </button>
          <span className="px-3 py-2 bg-blue-100 text-blue-700 rounded-full text-sm font-medium">
            Fall 2026
          </span>
          <span className="px-3 py-2 bg-green-100 text-green-700 rounded-full text-sm font-medium">
            {enrolledCourses.reduce((acc, curr) => acc + curr.credits, 0)} Credits
          </span>
        </div>
      </div>

      {enrolledCourses.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-lg border border-gray-200">
          <BookOpen className="size-12 text-gray-300 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900">No courses enrolled</h3>
          <p className="text-gray-500 mt-2 mb-6">Go to Registration to sign up for classes.</p>
          <button
            onClick={() => navigate('/registration')}
            className="inline-flex items-center gap-2 px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors shadow-sm font-medium"
          >
            Register for Classes
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {enrolledCourses.map((course) => (
            <div key={course.id} className="group bg-white rounded-2xl border border-gray-100 overflow-hidden hover:shadow-xl transition-all duration-300 hover:-translate-y-1 cursor-pointer" onClick={() => navigate(`/courses/${course.id}`)}>
              <div className="p-6 space-y-5">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="font-bold text-xl text-gray-900 line-clamp-1 group-hover:text-blue-600 transition-colors">{course.name}</h3>
                    <p className="text-gray-500 font-medium text-sm mt-1">{course.code}</p>
                  </div>
                  <div className={`px-3 py-1 rounded-full text-xs font-bold ${getStatusColor(course.progress)}`}>
                    {course.grade || `${course.progress}%`}
                  </div>
                </div>

                <div className="space-y-2 text-sm text-gray-600">
                  <div className="flex items-center gap-2">
                    <User className="size-4" />
                    <span className="line-clamp-1">{course.instructor}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="size-4" />
                    <span>{course.schedule}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <MapPin className="size-4" />
                    <span>{course.location}</span>
                  </div>
                </div>

                {/* Progress Bar */}
                <div className="space-y-1">
                  <div className="flex justify-between text-xs text-gray-500">
                    <span>Progress</span>
                    <span>{course.progress}%</span>
                  </div>
                  <div className="w-full bg-gray-100 rounded-full h-2.5 overflow-hidden">
                    <div
                      className="bg-blue-600 h-2.5 rounded-full transition-all duration-500 ease-out group-hover:bg-blue-500"
                      style={{ width: `${course.progress}%` }}
                    />
                  </div>
                </div>

                <div className="pt-4 border-t border-gray-100 flex justify-between items-center text-sm">
                  <span className="text-gray-500">{course.credits} Credits</span>
                  <button
                    onClick={(e) => { e.stopPropagation(); navigate(`/courses/${course.id}`); }}
                    className="text-blue-600 hover:text-blue-700 font-medium"
                  >
                    View Details
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
