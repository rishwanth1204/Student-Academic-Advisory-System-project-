// const Student = require('../models/Student');
const { students } = require('../data/mockData');

// @desc    Get current student profile
// @route   GET /api/students/profile
// @access  Private
exports.getProfile = async (req, res, next) => {
    try {
        // const student = await Student.findOne({ userId: req.user._id });
        const student = students.find(s => s.userId === req.user._id);

        if (!student) {
            return res.status(404).json({ message: 'Student profile not found' });
        }
        res.json(student);
    } catch (err) {
        next(err);
    }
};

// @desc    Update student profile
// @route   PUT /api/students/profile
// @access  Private
exports.updateProfile = async (req, res, next) => {
    try {
        // const student = await Student.findOne({ userId: req.user._id });
        const student = students.find(s => s.userId === req.user._id);

        if (!student) {
            return res.status(404).json({ message: 'Student profile not found' });
        }

        const { major, advisor, expectedGraduation } = req.body;

        student.major = major || student.major;
        student.advisor = advisor || student.advisor;
        student.expectedGraduation = expectedGraduation || student.expectedGraduation;

        // const updatedStudent = await student.save();
        // Since it's in-memory, modifying the object is enough. 
        // We'll return the object as if it was saved.

        res.json(student);
    } catch (err) {
        next(err);
    }
};

// @desc    Get student transcript
// @route   GET /api/students/transcript
// @access  Private
exports.getTranscript = async (req, res, next) => {
    try {
        // const student = await Student.findOne({ userId: req.user._id });
        const student = students.find(s => s.userId === req.user._id);

        if (!student) {
            return res.status(404).json({ message: 'Student profile not found' });
        }
        res.json(student.transcript);
    } catch (err) {
        next(err);
    }
};
