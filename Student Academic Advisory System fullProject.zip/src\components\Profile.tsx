import { useState } from 'react';
import { useAuthStore } from '../store/useAuthStore';
import { User, Mail, GraduationCap, Calendar, Book, Save, Pencil, X, Camera, Award, Clock, ChevronRight } from 'lucide-react';
import { toast } from 'sonner';

export function Profile() {
    const { user, updateProfile } = useAuthStore();
    const student = user && 'studentId' in user ? user : null;

    const [isEditing, setIsEditing] = useState(false);
    const [formData, setFormData] = useState({
        name: student?.name || '',
        email: student?.email || '',
        major: student?.major || '',
        expectedGraduation: student?.expectedGraduation || '',
        advisor: student?.advisor || ''
    });

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        try {
            await updateProfile(formData);
            toast.success('Profile updated successfully!');
            setIsEditing(false);
        } catch (error) {
            toast.error('Failed to update profile');
        }
    };

    const toggleEdit = () => {
        if (isEditing) {
            setFormData({
                name: student?.name || '',
                email: student?.email || '',
                major: student?.major || '',
                expectedGraduation: student?.expectedGraduation || '',
                advisor: student?.advisor || ''
            });
        }
        setIsEditing(!isEditing);
    };

    return (
        <div className="max-w-6xl mx-auto py-8 px-4 sm:px-6 space-y-8">
            {/* Header Section */}
            <div className="bg-white rounded-2xl shadow-xl border border-gray-200 overflow-hidden relative group">
                <div className="h-48 bg-gradient-to-r from-indigo-600 via-blue-600 to-blue-500 relative">
                    <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20"></div>
                    <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
                </div>

                <div className="px-8 pb-8">
                    <div className="relative flex flex-col md:flex-row items-end -mt-16 mb-6 gap-6">
                        <div className="relative group/avatar cursor-pointer">
                            <div className="w-32 h-32 bg-white rounded-full p-1.5 shadow-2xl ring-4 ring-white/50 relative z-10 transition-transform duration-300 group-hover/avatar:scale-105">
                                <div className="w-full h-full bg-gradient-to-br from-indigo-50 to-blue-50 rounded-full flex items-center justify-center text-4xl font-bold text-indigo-600 border border-indigo-100 overflow-hidden relative">
                                    {formData.name.charAt(0)}
                                    <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover/avatar:opacity-100 transition-opacity duration-200">
                                        <Camera className="text-white size-8" />
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="flex-1 mb-2">
                            <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
                                {formData.name}
                                <span className="px-3 py-1 bg-green-100 text-green-700 text-xs font-bold uppercase tracking-wider rounded-full border border-green-200">
                                    Active
                                </span>
                            </h1>
                            <p className="text-gray-500 font-medium flex items-center gap-2 mt-1">
                                <span className="text-indigo-600 font-semibold">{student?.studentId}</span>
                                <span className="w-1 h-1 rounded-full bg-gray-300"></span>
                                <span>Computer Science Student</span>
                            </p>
                        </div>

                        <div className="flex gap-3 mb-2">
                            {!isEditing ? (
                                <button
                                    onClick={toggleEdit}
                                    className="px-5 py-2.5 bg-white text-gray-700 border border-gray-200 rounded-xl hover:bg-gray-50 hover:border-gray-300 hover:text-indigo-600 font-medium transition-all shadow-sm hover:shadow-md flex items-center gap-2"
                                >
                                    <Pencil className="size-4" />
                                    <span>Edit Profile</span>
                                </button>
                            ) : (
                                <>
                                    <button
                                        onClick={toggleEdit}
                                        className="px-5 py-2.5 bg-white text-gray-700 border border-gray-200 rounded-xl hover:bg-red-50 hover:text-red-600 hover:border-red-200 font-medium transition-all shadow-sm flex items-center gap-2"
                                    >
                                        <X className="size-4" />
                                        <span>Cancel</span>
                                    </button>
                                    <button
                                        onClick={handleSubmit}
                                        className="px-6 py-2.5 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 transition-all font-medium shadow-lg shadow-indigo-600/20 flex items-center gap-2 hover:translate-y-px"
                                    >
                                        <Save className="size-4" />
                                        <span>Save Changes</span>
                                    </button>
                                </>
                            )}
                        </div>
                    </div>

                    {/* Quick Stats Row */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 border-t border-gray-100 pt-6">
                        <div className="flex items-center gap-4 p-4 rounded-xl bg-gray-50 border border-gray-100 hover:border-indigo-100 hover:bg-indigo-50/30 transition-colors group/stat">
                            <div className="p-3 bg-white rounded-lg shadow-sm text-indigo-600 group-hover/stat:scale-110 transition-transform duration-300">
                                <Award className="size-6" />
                            </div>
                            <div>
                                <p className="text-sm text-gray-500 font-medium">Current GPA</p>
                                <p className="text-xl font-bold text-gray-900">3.85</p>
                            </div>
                        </div>
                        <div className="flex items-center gap-4 p-4 rounded-xl bg-gray-50 border border-gray-100 hover:border-blue-100 hover:bg-blue-50/30 transition-colors group/stat">
                            <div className="p-3 bg-white rounded-lg shadow-sm text-blue-600 group-hover/stat:scale-110 transition-transform duration-300">
                                <Book className="size-6" />
                            </div>
                            <div>
                                <p className="text-sm text-gray-500 font-medium">Credits Earned</p>
                                <p className="text-xl font-bold text-gray-900">86 / 120</p>
                            </div>
                        </div>
                        <div className="flex items-center gap-4 p-4 rounded-xl bg-gray-50 border border-gray-100 hover:border-purple-100 hover:bg-purple-50/30 transition-colors group/stat">
                            <div className="p-3 bg-white rounded-lg shadow-sm text-purple-600 group-hover/stat:scale-110 transition-transform duration-300">
                                <Clock className="size-6" />
                            </div>
                            <div>
                                <p className="text-sm text-gray-500 font-medium">Academic Standing</p>
                                <p className="text-xl font-bold text-gray-900">Senior</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Main Form Section */}
            <div className="bg-white rounded-2xl shadow-xl border border-gray-200 overflow-hidden">
                <div className="p-8">
                    <div className="flex items-center justify-between mb-8">
                        <div>
                            <h2 className="text-xl font-bold text-gray-900">Profile Details</h2>
                            <p className="text-gray-500 mt-1">Manage your account information and preferences.</p>
                        </div>
                    </div>

                    <form onSubmit={handleSubmit}>
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
                            {/* Personal Info */}
                            <div className="space-y-6">
                                <h3 className="text-sm font-bold text-gray-400 uppercase tracking-wider border-b border-gray-100 pb-2 mb-4">
                                    Personal Information
                                </h3>

                                <div className="space-y-6">
                                    <div className="group">
                                        <label className="block text-sm font-medium text-gray-700 mb-2 transition-colors group-focus-within:text-indigo-600">Full Name</label>
                                        <div className="relative">
                                            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                                <User className="size-5 text-gray-400 group-focus-within:text-indigo-500 transition-colors" />
                                            </div>
                                            <input
                                                type="text"
                                                name="name"
                                                value={formData.name}
                                                onChange={handleChange}
                                                disabled={!isEditing}
                                                className={`block w-full pl-10 pr-3 py-3 border rounded-xl transition-all duration-200 outline-none ${isEditing
                                                        ? 'bg-white border-gray-300 focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 text-gray-900 shadow-sm'
                                                        : 'bg-gray-50 border-transparent text-gray-600 cursor-default'
                                                    }`}
                                            />
                                        </div>
                                    </div>

                                    <div className="group">
                                        <label className="block text-sm font-medium text-gray-700 mb-2 transition-colors group-focus-within:text-indigo-600">Email Address</label>
                                        <div className="relative">
                                            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                                <Mail className="size-5 text-gray-400 group-focus-within:text-indigo-500 transition-colors" />
                                            </div>
                                            <input
                                                type="email"
                                                value={formData.email}
                                                disabled
                                                className="block w-full pl-10 pr-3 py-3 border border-gray-200 rounded-xl bg-gray-50 text-gray-500 cursor-not-allowed font-medium shadow-inner"
                                            />
                                        </div>
                                        {isEditing && (
                                            <p className="mt-2 text-xs text-blue-600 flex items-center gap-1 cursor-pointer hover:underline">
                                                <ChevronRight className="size-3" /> Request email change
                                            </p>
                                        )}
                                    </div>
                                </div>
                            </div>

                            {/* Academic Info */}
                            <div className="space-y-6">
                                <h3 className="text-sm font-bold text-gray-400 uppercase tracking-wider border-b border-gray-100 pb-2 mb-4">
                                    Academic Information
                                </h3>

                                <div className="space-y-6">
                                    <div className="group">
                                        <label className="block text-sm font-medium text-gray-700 mb-2 transition-colors group-focus-within:text-indigo-600">Major</label>
                                        <div className="relative">
                                            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                                <Book className="size-5 text-gray-400 group-focus-within:text-indigo-500 transition-colors" />
                                            </div>
                                            <input
                                                type="text"
                                                name="major"
                                                value={formData.major}
                                                onChange={handleChange}
                                                disabled={!isEditing}
                                                className={`block w-full pl-10 pr-3 py-3 border rounded-xl transition-all duration-200 outline-none ${isEditing
                                                        ? 'bg-white border-gray-300 focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 text-gray-900 shadow-sm'
                                                        : 'bg-gray-50 border-transparent text-gray-600 cursor-default'
                                                    }`}
                                            />
                                        </div>
                                    </div>

                                    <div className="group">
                                        <label className="block text-sm font-medium text-gray-700 mb-2 transition-colors group-focus-within:text-indigo-600">Expected Graduation</label>
                                        <div className="relative">
                                            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                                <GraduationCap className="size-5 text-gray-400 group-focus-within:text-indigo-500 transition-colors" />
                                            </div>
                                            <input
                                                type="text"
                                                name="expectedGraduation"
                                                value={formData.expectedGraduation}
                                                onChange={handleChange}
                                                disabled={!isEditing}
                                                className={`block w-full pl-10 pr-3 py-3 border rounded-xl transition-all duration-200 outline-none ${isEditing
                                                        ? 'bg-white border-gray-300 focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 text-gray-900 shadow-sm'
                                                        : 'bg-gray-50 border-transparent text-gray-600 cursor-default'
                                                    }`}
                                            />
                                        </div>
                                    </div>

                                    <div className="group">
                                        <label className="block text-sm font-medium text-gray-700 mb-2 transition-colors group-focus-within:text-indigo-600">Faculty Advisor</label>
                                        <div className="relative">
                                            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                                <Calendar className="size-5 text-gray-400 group-focus-within:text-indigo-500 transition-colors" />
                                            </div>
                                            <input
                                                type="text"
                                                name="advisor"
                                                value={formData.advisor}
                                                onChange={handleChange}
                                                disabled
                                                className="block w-full pl-10 pr-3 py-3 border border-gray-200 rounded-xl bg-gray-50 text-gray-500 cursor-not-allowed font-medium shadow-inner"
                                            />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    );
}
