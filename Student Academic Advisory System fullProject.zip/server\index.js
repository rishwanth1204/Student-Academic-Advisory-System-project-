const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
require('dotenv').config();

const http = require('http');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
    cors: {
        origin: "http://localhost:3000", // Update with your frontend URL if different
        methods: ["GET", "POST"]
    }
});

const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());

// Socket.io Connection Logic
io.on('connection', (socket) => {
    console.log('User connected:', socket.id);

    socket.on('join_chat', (userId) => {
        socket.join(userId);
        console.log(`User ${userId} joined their chat room`);
    });

    socket.on('send_message', (data) => {
        // data: { recipientId, text, senderId }
        // For simple advisor chat, we might just echo back or send to specific room
        console.log('Message received:', data);

        // Simulate Advisor Reply
        setTimeout(() => {
            io.to(data.senderId).emit('receive_message', {
                id: Date.now().toString(),
                sender: 'advisor',
                text: "Thanks for your message! An advisor will review it shortly.",
                timestamp: new Date().toISOString()
            });
        }, 2000);
    });

    socket.on('disconnect', () => {
        console.log('User disconnected:', socket.id);
    });
});

// Database Connection
// mongoose.connect(process.env.MONGODB_URI)
//     .then(() => console.log('MongoDB Connected'))
//     .catch(err => {
//         console.error('MongoDB Connection Error:', err);
//         // process.exit(1); // Exit process with failure
//     });
console.log('Using In-Memory Mock Data (MongoDB connection skipped)');


// Routes
app.use('/api/auth', require('./routes/auth'));
app.use('/api/students', require('./routes/students'));
app.use('/api/courses', require('./routes/courses'));
app.use('/api/appointments', require('./routes/appointments'));

app.get('/', (req, res) => {
    res.send('API is running...');
});

// Global Error Handling Middleware
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({
        message: err.message || 'Internal Server Error',
        stack: process.env.NODE_ENV === 'production' ? null : err.stack,
    });
});

server.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
