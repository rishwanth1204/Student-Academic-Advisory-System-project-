
  # Student Academic Advisory System project

  This is a code bundle for Student Academic Advisory System project. The original project is available at https://www.figma.com/design/u9eKbPZf4iMvvYPsjNtHGN/Student-Academic-Advisory-System-project.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  