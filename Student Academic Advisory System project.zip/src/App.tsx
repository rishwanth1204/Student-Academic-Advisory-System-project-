import { useState } from 'react';
import { Dashboard } from './components/Dashboard';
import { Courses } from './components/Courses';
import { Advisor } from './components/Advisor';
import { Appointments } from './components/Appointments';
import { Progress } from './components/Progress';
import { Calendar } from './components/Calendar';
import { Resources } from './components/Resources';
import { Analytics } from './components/Analytics';
import { Tutoring } from './components/Tutoring';
import { Scholarships } from './components/Scholarships';
import { StudyGroups } from './components/StudyGroups';
import { Career } from './components/Career';
import { Registration } from './components/Registration';
import { Achievements } from './components/Achievements';
import { Transcript } from './components/Transcript';
import { Notifications } from './components/Notifications';
import { LayoutDashboard, BookOpen, User, Calendar as CalendarIcon, TrendingUp, Library, BarChart3, Users, Award, Briefcase, ClipboardList, Trophy, FileText, Bell } from 'lucide-react';

type Tab = 'dashboard' | 'courses' | 'advisor' | 'appointments' | 'progress' | 'calendar' | 'resources' | 'analytics' | 'tutoring' | 'scholarships' | 'study-groups' | 'career' | 'registration' | 'achievements' | 'transcript' | 'notifications';

export default function App() {
  const [activeTab, setActiveTab] = useState<Tab>('dashboard');
  const [notificationCount] = useState(5);

  const tabs = [
    { id: 'dashboard' as Tab, label: 'Dashboard', icon: LayoutDashboard },
    { id: 'courses' as Tab, label: 'Courses', icon: BookOpen },
    { id: 'analytics' as Tab, label: 'Analytics', icon: BarChart3 },
    { id: 'progress' as Tab, label: 'Progress', icon: TrendingUp },
    { id: 'calendar' as Tab, label: 'Calendar', icon: CalendarIcon },
    { id: 'registration' as Tab, label: 'Registration', icon: ClipboardList },
    { id: 'advisor' as Tab, label: 'Advisor', icon: User },
    { id: 'appointments' as Tab, label: 'Appointments', icon: CalendarIcon },
    { id: 'resources' as Tab, label: 'Resources', icon: Library },
    { id: 'tutoring' as Tab, label: 'Tutoring', icon: Users },
    { id: 'study-groups' as Tab, label: 'Study Groups', icon: Users },
    { id: 'career' as Tab, label: 'Career', icon: Briefcase },
    { id: 'scholarships' as Tab, label: 'Scholarships', icon: Award },
    { id: 'achievements' as Tab, label: 'Achievements', icon: Trophy },
    { id: 'transcript' as Tab, label: 'Transcript', icon: FileText },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <BookOpen className="size-8 text-blue-600" />
              <h1 className="ml-3 font-semibold text-gray-900">Academic Advisory System</h1>
            </div>
            <div className="flex items-center gap-4">
              <button 
                onClick={() => setActiveTab('notifications')}
                className="relative p-2 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-100"
              >
                <Bell className="size-6" />
                {notificationCount > 0 && (
                  <span className="absolute top-1 right-1 size-4 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
                    {notificationCount}
                  </span>
                )}
              </button>
              <div className="flex items-center gap-3">
                <div className="text-right">
                  <p className="text-sm font-medium text-gray-900">Sarah Johnson</p>
                  <p className="text-xs text-gray-500">Student ID: 2024-CS-1234</p>
                </div>
                <div className="size-10 rounded-full bg-blue-100 flex items-center justify-center">
                  <span className="text-blue-600 font-medium">SJ</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className="bg-white border-b border-gray-200 sticky top-16 z-40 overflow-x-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex gap-6">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-2 px-1 py-4 border-b-2 transition-colors whitespace-nowrap ${
                    activeTab === tab.id
                      ? 'border-blue-600 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <Icon className="size-5" />
                  <span className="font-medium text-sm">{tab.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'dashboard' && <Dashboard />}
        {activeTab === 'courses' && <Courses />}
        {activeTab === 'advisor' && <Advisor />}
        {activeTab === 'appointments' && <Appointments />}
        {activeTab === 'progress' && <Progress />}
        {activeTab === 'calendar' && <Calendar />}
        {activeTab === 'resources' && <Resources />}
        {activeTab === 'analytics' && <Analytics />}
        {activeTab === 'tutoring' && <Tutoring />}
        {activeTab === 'scholarships' && <Scholarships />}
        {activeTab === 'study-groups' && <StudyGroups />}
        {activeTab === 'career' && <Career />}
        {activeTab === 'registration' && <Registration />}
        {activeTab === 'achievements' && <Achievements />}
        {activeTab === 'transcript' && <Transcript />}
        {activeTab === 'notifications' && <Notifications />}
      </main>
    </div>
  );
}