import { BookOpen, Clock, MapPin, User } from 'lucide-react';

interface Course {
  id: string;
  code: string;
  name: string;
  instructor: string;
  credits: number;
  schedule: string;
  location: string;
  grade: string;
  progress: number;
}

export function Courses() {
  const courses: Course[] = [
    {
      id: '1',
      code: 'CS 301',
      name: 'Data Structures',
      instructor: 'Dr. Emily Chen',
      credits: 3,
      schedule: 'Mon/Wed 10:00 AM - 11:30 AM',
      location: 'Building A, Room 201',
      grade: 'A-',
      progress: 65,
    },
    {
      id: '2',
      code: 'CS 305',
      name: 'Database Systems',
      instructor: 'Prof. Michael Torres',
      credits: 4,
      schedule: 'Tue/Thu 2:00 PM - 3:45 PM',
      location: 'Building B, Room 105',
      grade: 'A',
      progress: 58,
    },
    {
      id: '3',
      code: 'CS 320',
      name: 'Web Development',
      instructor: 'Dr. Sarah Martinez',
      credits: 3,
      schedule: 'Mon/Wed 1:00 PM - 2:30 PM',
      location: 'Building C, Room 310',
      grade: 'A+',
      progress: 72,
    },
    {
      id: '4',
      code: 'CS 340',
      name: 'Algorithms',
      instructor: 'Prof. David Kim',
      credits: 3,
      schedule: 'Tue/Thu 10:00 AM - 11:30 AM',
      location: 'Building A, Room 150',
      grade: 'B+',
      progress: 60,
    },
    {
      id: '5',
      code: 'CS 350',
      name: 'Operating Systems',
      instructor: 'Dr. Jennifer Lee',
      credits: 4,
      schedule: 'Mon/Wed/Fri 9:00 AM - 10:00 AM',
      location: 'Building D, Room 220',
      grade: 'A',
      progress: 70,
    },
  ];

  const totalCredits = courses.reduce((sum, course) => sum + course.credits, 0);
  const gpa = 3.75;

  return (
    <div className="space-y-6">
      {/* Summary */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="font-semibold text-gray-900">Spring 2026 Semester</h2>
            <p className="text-sm text-gray-500 mt-1">
              {courses.length} courses • {totalCredits} credits
            </p>
          </div>
          <div className="text-right">
            <p className="text-sm text-gray-500">Current GPA</p>
            <p className="text-2xl font-semibold text-gray-900">{gpa.toFixed(2)}</p>
          </div>
        </div>
      </div>

      {/* Course List */}
      <div className="grid grid-cols-1 gap-6">
        {courses.map((course) => (
          <div key={course.id} className="bg-white rounded-lg border border-gray-200 p-6 hover:shadow-lg transition-shadow">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-start gap-4">
                <div className="p-3 bg-blue-100 rounded-lg">
                  <BookOpen className="size-6 text-blue-600" />
                </div>
                <div>
                  <div className="flex items-center gap-3">
                    <h3 className="font-semibold text-gray-900">{course.name}</h3>
                    <span className="px-2 py-1 bg-gray-100 text-gray-700 rounded text-xs font-medium">
                      {course.code}
                    </span>
                  </div>
                  <div className="flex items-center gap-4 mt-2 text-sm text-gray-500">
                    <div className="flex items-center gap-1">
                      <User className="size-4" />
                      <span>{course.instructor}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Clock className="size-4" />
                      <span>{course.schedule}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <MapPin className="size-4" />
                      <span>{course.location}</span>
                    </div>
                  </div>
                </div>
              </div>
              <div className="text-right">
                <p className="text-2xl font-semibold text-gray-900">{course.grade}</p>
                <p className="text-xs text-gray-500 mt-1">{course.credits} Credits</p>
              </div>
            </div>

            {/* Progress Bar */}
            <div className="mt-4">
              <div className="flex items-center justify-between text-sm mb-2">
                <span className="text-gray-600">Course Progress</span>
                <span className="text-gray-900 font-medium">{course.progress}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div
                  className="bg-blue-600 h-2 rounded-full transition-all"
                  style={{ width: `${course.progress}%` }}
                />
              </div>
            </div>

            {/* Actions */}
            <div className="flex gap-3 mt-4">
              <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium">
                View Details
              </button>
              <button className="px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors text-sm font-medium">
                Course Materials
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
