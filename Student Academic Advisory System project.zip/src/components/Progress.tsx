import { Award, BookOpen, CheckCircle, Circle, Target } from 'lucide-react';

interface Requirement {
  category: string;
  required: number;
  completed: number;
  courses: { code: string; name: string; credits: number; grade?: string }[];
}

export function Progress() {
  const degreeRequirements: Requirement[] = [
    {
      category: 'Core Computer Science',
      required: 36,
      completed: 30,
      courses: [
        { code: 'CS 101', name: 'Intro to Programming', credits: 3, grade: 'A' },
        { code: 'CS 201', name: 'Data Structures', credits: 3, grade: 'A-' },
        { code: 'CS 202', name: 'Algorithms', credits: 3, grade: 'B+' },
        { code: 'CS 305', name: 'Database Systems', credits: 4, grade: 'A' },
        { code: 'CS 310', name: 'Operating Systems', credits: 4, grade: 'A' },
        { code: 'CS 320', name: 'Web Development', credits: 3, grade: 'A+' },
        { code: 'CS 330', name: 'Software Engineering', credits: 3, grade: 'A' },
        { code: 'CS 340', name: 'Computer Networks', credits: 3, grade: 'B+' },
        { code: 'CS 350', name: 'Computer Architecture', credits: 4, grade: 'A-' },
        { code: 'CS 400', name: 'Theory of Computation', credits: 3 },
        { code: 'CS 450', name: 'Machine Learning', credits: 3 },
      ],
    },
    {
      category: 'Mathematics',
      required: 18,
      completed: 18,
      courses: [
        { code: 'MATH 101', name: 'Calculus I', credits: 4, grade: 'A' },
        { code: 'MATH 102', name: 'Calculus II', credits: 4, grade: 'A-' },
        { code: 'MATH 201', name: 'Linear Algebra', credits: 3, grade: 'A' },
        { code: 'MATH 210', name: 'Discrete Mathematics', credits: 4, grade: 'B+' },
        { code: 'STAT 301', name: 'Probability & Statistics', credits: 3, grade: 'A' },
      ],
    },
    {
      category: 'General Education',
      required: 30,
      completed: 24,
      courses: [
        { code: 'ENG 101', name: 'English Composition', credits: 3, grade: 'A' },
        { code: 'HIST 201', name: 'World History', credits: 3, grade: 'B+' },
        { code: 'PSYC 101', name: 'Introduction to Psychology', credits: 3, grade: 'A' },
        { code: 'ECON 101', name: 'Microeconomics', credits: 3, grade: 'A-' },
        { code: 'PHYS 201', name: 'Physics I', credits: 4, grade: 'B+' },
        { code: 'PHYS 202', name: 'Physics II', credits: 4, grade: 'B' },
        { code: 'ART 101', name: 'Art History', credits: 3, grade: 'A' },
        { code: 'PHIL 201', name: 'Ethics', credits: 3 },
        { code: 'SOC 101', name: 'Sociology', credits: 3 },
      ],
    },
    {
      category: 'Electives',
      required: 18,
      completed: 15,
      courses: [
        { code: 'BUS 301', name: 'Business Communication', credits: 3, grade: 'A' },
        { code: 'CS 420', name: 'Mobile App Development', credits: 3, grade: 'A+' },
        { code: 'CS 430', name: 'Cloud Computing', credits: 3, grade: 'A' },
        { code: 'MKT 201', name: 'Digital Marketing', credits: 3, grade: 'B+' },
        { code: 'CS 460', name: 'Cybersecurity', credits: 3, grade: 'A-' },
      ],
    },
  ];

  const totalRequired = degreeRequirements.reduce((sum, req) => sum + req.required, 0);
  const totalCompleted = degreeRequirements.reduce((sum, req) => sum + req.completed, 0);
  const overallProgress = Math.round((totalCompleted / totalRequired) * 100);
  const creditsRemaining = totalRequired - totalCompleted;

  const milestones = [
    { name: 'Freshman Year', status: 'completed', semester: 'Fall 2023 - Spring 2024' },
    { name: 'Sophomore Year', status: 'completed', semester: 'Fall 2024 - Spring 2025' },
    { name: 'Junior Year', status: 'in-progress', semester: 'Fall 2025 - Spring 2026' },
    { name: 'Senior Year', status: 'upcoming', semester: 'Fall 2026 - Spring 2027' },
  ];

  return (
    <div className="space-y-6">
      {/* Overall Progress */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-semibold text-gray-900">Degree Progress</h2>
            <p className="text-sm text-gray-500 mt-1">Bachelor of Science in Computer Science</p>
          </div>
          <div className="text-right">
            <p className="text-4xl font-semibold text-blue-600">{overallProgress}%</p>
            <p className="text-sm text-gray-500 mt-1">Complete</p>
          </div>
        </div>

        <div className="w-full bg-gray-200 rounded-full h-4 mb-4">
          <div
            className="bg-blue-600 h-4 rounded-full transition-all"
            style={{ width: `${overallProgress}%` }}
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="text-center p-4 bg-green-50 rounded-lg">
            <p className="text-3xl font-semibold text-green-600">{totalCompleted}</p>
            <p className="text-sm text-gray-600 mt-1">Credits Completed</p>
          </div>
          <div className="text-center p-4 bg-orange-50 rounded-lg">
            <p className="text-3xl font-semibold text-orange-600">{creditsRemaining}</p>
            <p className="text-sm text-gray-600 mt-1">Credits Remaining</p>
          </div>
          <div className="text-center p-4 bg-blue-50 rounded-lg">
            <p className="text-3xl font-semibold text-blue-600">{totalRequired}</p>
            <p className="text-sm text-gray-600 mt-1">Total Required</p>
          </div>
        </div>
      </div>

      {/* Academic Milestones */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h3 className="font-semibold text-gray-900 mb-4">Academic Milestones</h3>
        <div className="space-y-4">
          {milestones.map((milestone, index) => (
            <div key={index} className="flex items-center gap-4">
              <div className="flex-shrink-0">
                {milestone.status === 'completed' ? (
                  <CheckCircle className="size-6 text-green-500" />
                ) : milestone.status === 'in-progress' ? (
                  <Target className="size-6 text-blue-500" />
                ) : (
                  <Circle className="size-6 text-gray-300" />
                )}
              </div>
              <div className="flex-1">
                <p className="font-medium text-gray-900">{milestone.name}</p>
                <p className="text-sm text-gray-500">{milestone.semester}</p>
              </div>
              <span
                className={`px-3 py-1 rounded-full text-xs font-medium ${
                  milestone.status === 'completed'
                    ? 'bg-green-100 text-green-700'
                    : milestone.status === 'in-progress'
                    ? 'bg-blue-100 text-blue-700'
                    : 'bg-gray-100 text-gray-600'
                }`}
              >
                {milestone.status === 'completed'
                  ? 'Completed'
                  : milestone.status === 'in-progress'
                  ? 'In Progress'
                  : 'Upcoming'}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Requirement Categories */}
      <div className="space-y-4">
        {degreeRequirements.map((requirement, index) => {
          const progress = Math.round((requirement.completed / requirement.required) * 100);
          const isComplete = requirement.completed >= requirement.required;

          return (
            <div key={index} className="bg-white rounded-lg border border-gray-200 p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  {isComplete ? (
                    <Award className="size-6 text-green-500" />
                  ) : (
                    <BookOpen className="size-6 text-blue-500" />
                  )}
                  <div>
                    <h3 className="font-semibold text-gray-900">{requirement.category}</h3>
                    <p className="text-sm text-gray-500">
                      {requirement.completed} of {requirement.required} credits
                    </p>
                  </div>
                </div>
                <span
                  className={`text-2xl font-semibold ${
                    isComplete ? 'text-green-600' : 'text-blue-600'
                  }`}
                >
                  {progress}%
                </span>
              </div>

              <div className="w-full bg-gray-200 rounded-full h-2 mb-4">
                <div
                  className={`h-2 rounded-full transition-all ${
                    isComplete ? 'bg-green-500' : 'bg-blue-600'
                  }`}
                  style={{ width: `${Math.min(progress, 100)}%` }}
                />
              </div>

              <div className="space-y-2">
                {requirement.courses.map((course, courseIndex) => (
                  <div
                    key={courseIndex}
                    className="flex items-center justify-between py-2 px-3 bg-gray-50 rounded"
                  >
                    <div className="flex items-center gap-3">
                      {course.grade ? (
                        <CheckCircle className="size-4 text-green-500 flex-shrink-0" />
                      ) : (
                        <Circle className="size-4 text-gray-300 flex-shrink-0" />
                      )}
                      <div>
                        <span className="text-sm font-medium text-gray-900">
                          {course.code}
                        </span>
                        <span className="text-sm text-gray-600 ml-2">{course.name}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="text-sm text-gray-500">{course.credits} credits</span>
                      {course.grade && (
                        <span className="text-sm font-medium text-gray-900 min-w-[2rem] text-right">
                          {course.grade}
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>

      {/* Projected Graduation */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 rounded-lg p-6 text-white">
        <div className="flex items-center gap-4">
          <Award className="size-12" />
          <div>
            <h3 className="text-xl font-semibold">Projected Graduation</h3>
            <p className="text-blue-100 mt-1">Spring 2027</p>
            <p className="text-sm text-blue-100 mt-2">
              You're on track to graduate on time! Keep up the great work.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
