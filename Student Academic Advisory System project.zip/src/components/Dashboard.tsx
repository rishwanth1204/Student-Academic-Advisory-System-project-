import { Award, BookOpen, Calendar, TrendingUp, AlertCircle } from 'lucide-react';

export function Dashboard() {
  const stats = [
    { label: 'Current GPA', value: '3.75', icon: Award, color: 'bg-green-100 text-green-600' },
    { label: 'Enrolled Courses', value: '5', icon: BookOpen, color: 'bg-blue-100 text-blue-600' },
    { label: 'Upcoming Appointments', value: '2', icon: Calendar, color: 'bg-purple-100 text-purple-600' },
    { label: 'Credits Completed', value: '87/120', icon: TrendingUp, color: 'bg-orange-100 text-orange-600' },
  ];

  const upcomingDeadlines = [
    { course: 'Data Structures', task: 'Assignment 3', dueDate: 'Feb 8, 2026', priority: 'high' },
    { course: 'Database Systems', task: 'Project Proposal', dueDate: 'Feb 10, 2026', priority: 'medium' },
    { course: 'Web Development', task: 'Midterm Exam', dueDate: 'Feb 15, 2026', priority: 'high' },
    { course: 'Algorithms', task: 'Weekly Quiz', dueDate: 'Feb 7, 2026', priority: 'low' },
  ];

  const recentGrades = [
    { course: 'Operating Systems', assignment: 'Midterm Exam', grade: 'A', score: '92/100' },
    { course: 'Data Structures', assignment: 'Assignment 2', grade: 'A-', score: '88/100' },
    { course: 'Web Development', assignment: 'Project 1', grade: 'A+', score: '98/100' },
  ];

  return (
    <div className="space-y-6">
      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <div key={stat.label} className="bg-white rounded-lg border border-gray-200 p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500">{stat.label}</p>
                  <p className="mt-2 text-3xl font-semibold text-gray-900">{stat.value}</p>
                </div>
                <div className={`p-3 rounded-lg ${stat.color}`}>
                  <Icon className="size-6" />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Upcoming Deadlines */}
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold text-gray-900">Upcoming Deadlines</h2>
            <AlertCircle className="size-5 text-gray-400" />
          </div>
          <div className="space-y-4">
            {upcomingDeadlines.map((deadline, index) => (
              <div key={index} className="flex items-start gap-3 pb-4 border-b border-gray-100 last:border-0 last:pb-0">
                <div
                  className={`size-2 rounded-full mt-2 ${
                    deadline.priority === 'high'
                      ? 'bg-red-500'
                      : deadline.priority === 'medium'
                      ? 'bg-yellow-500'
                      : 'bg-green-500'
                  }`}
                />
                <div className="flex-1">
                  <p className="text-sm font-medium text-gray-900">{deadline.task}</p>
                  <p className="text-sm text-gray-500">{deadline.course}</p>
                  <p className="text-xs text-gray-400 mt-1">{deadline.dueDate}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Recent Grades */}
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold text-gray-900">Recent Grades</h2>
            <Award className="size-5 text-gray-400" />
          </div>
          <div className="space-y-4">
            {recentGrades.map((grade, index) => (
              <div key={index} className="flex items-center justify-between pb-4 border-b border-gray-100 last:border-0 last:pb-0">
                <div className="flex-1">
                  <p className="text-sm font-medium text-gray-900">{grade.assignment}</p>
                  <p className="text-sm text-gray-500">{grade.course}</p>
                </div>
                <div className="text-right">
                  <p className="text-lg font-semibold text-gray-900">{grade.grade}</p>
                  <p className="text-xs text-gray-500">{grade.score}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h2 className="font-semibold text-gray-900 mb-4">Quick Actions</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <button className="px-4 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium">
            Schedule Appointment
          </button>
          <button className="px-4 py-3 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors text-sm font-medium">
            View Transcript
          </button>
          <button className="px-4 py-3 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors text-sm font-medium">
            Contact Advisor
          </button>
        </div>
      </div>
    </div>
  );
}
