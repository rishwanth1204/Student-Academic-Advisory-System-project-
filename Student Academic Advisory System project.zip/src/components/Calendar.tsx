import { useState } from 'react';
import { ChevronLeft, ChevronRight, Plus, Clock, MapPin, Users } from 'lucide-react';

interface CalendarEvent {
  id: string;
  title: string;
  date: string;
  time: string;
  type: 'class' | 'exam' | 'assignment' | 'appointment' | 'event';
  location?: string;
  course?: string;
  color: string;
}

export function Calendar() {
  const [currentDate, setCurrentDate] = useState(new Date(2026, 1, 1)); // February 2026
  
  const events: CalendarEvent[] = [
    { id: '1', title: 'Data Structures - Lecture', date: '2026-02-04', time: '10:00 AM', type: 'class', location: 'Building A, Room 201', course: 'CS 301', color: 'bg-blue-500' },
    { id: '2', title: 'Database Systems - Lecture', date: '2026-02-04', time: '2:00 PM', type: 'class', location: 'Building B, Room 105', course: 'CS 305', color: 'bg-blue-500' },
    { id: '3', title: 'Assignment 3 Due', date: '2026-02-08', time: '11:59 PM', type: 'assignment', course: 'CS 301', color: 'bg-red-500' },
    { id: '4', title: 'Advisor Meeting', date: '2026-02-10', time: '2:30 PM', type: 'appointment', location: 'Building E, Room 305', color: 'bg-purple-500' },
    { id: '5', title: 'Project Proposal Due', date: '2026-02-10', time: '11:59 PM', type: 'assignment', course: 'CS 305', color: 'bg-red-500' },
    { id: '6', title: 'Midterm Exam', date: '2026-02-15', time: '1:00 PM', type: 'exam', location: 'Building C, Room 310', course: 'CS 320', color: 'bg-orange-500' },
    { id: '7', title: 'Career Fair', date: '2026-02-18', time: '10:00 AM', type: 'event', location: 'Student Center', color: 'bg-green-500' },
    { id: '8', title: 'Study Group - Algorithms', date: '2026-02-12', time: '4:00 PM', type: 'event', location: 'Library, Room 203', color: 'bg-green-500' },
  ];

  const daysInMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0).getDate();
  const firstDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1).getDay();
  
  const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  const previousMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1));
  };

  const nextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1));
  };

  const getEventsForDay = (day: number) => {
    const dateStr = `${currentDate.getFullYear()}-${String(currentDate.getMonth() + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    return events.filter(event => event.date === dateStr);
  };

  const todayEvents = events.filter(event => event.date === '2026-02-04');
  const upcomingEvents = events.filter(event => event.date >= '2026-02-04').slice(0, 5);

  return (
    <div className="space-y-6">
      {/* Calendar Header */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-semibold text-gray-900">
            {monthNames[currentDate.getMonth()]} {currentDate.getFullYear()}
          </h2>
          <div className="flex items-center gap-2">
            <button
              onClick={previousMonth}
              className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
            >
              <ChevronLeft className="size-5" />
            </button>
            <button
              onClick={() => setCurrentDate(new Date(2026, 1, 1))}
              className="px-4 py-2 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors text-sm font-medium"
            >
              Today
            </button>
            <button
              onClick={nextMonth}
              className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
            >
              <ChevronRight className="size-5" />
            </button>
            <button className="ml-4 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium flex items-center gap-2">
              <Plus className="size-4" />
              Add Event
            </button>
          </div>
        </div>

        {/* Calendar Grid */}
        <div className="grid grid-cols-7 gap-px bg-gray-200 border border-gray-200 rounded-lg overflow-hidden">
          {/* Day Headers */}
          {dayNames.map(day => (
            <div key={day} className="bg-gray-50 py-2 text-center text-sm font-medium text-gray-700">
              {day}
            </div>
          ))}
          
          {/* Empty cells for days before month starts */}
          {Array.from({ length: firstDayOfMonth }).map((_, index) => (
            <div key={`empty-${index}`} className="bg-white min-h-[100px] p-2" />
          ))}
          
          {/* Calendar days */}
          {Array.from({ length: daysInMonth }).map((_, index) => {
            const day = index + 1;
            const dayEvents = getEventsForDay(day);
            const isToday = day === 4; // Feb 4, 2026
            
            return (
              <div
                key={day}
                className={`bg-white min-h-[100px] p-2 hover:bg-gray-50 transition-colors ${
                  isToday ? 'ring-2 ring-blue-500 ring-inset' : ''
                }`}
              >
                <div className={`text-sm font-medium mb-1 ${
                  isToday ? 'text-blue-600' : 'text-gray-900'
                }`}>
                  {day}
                </div>
                <div className="space-y-1">
                  {dayEvents.slice(0, 3).map(event => (
                    <div
                      key={event.id}
                      className={`text-xs text-white px-1 py-0.5 rounded truncate ${event.color}`}
                      title={event.title}
                    >
                      {event.title}
                    </div>
                  ))}
                  {dayEvents.length > 3 && (
                    <div className="text-xs text-gray-500 px-1">
                      +{dayEvents.length - 3} more
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Today's Schedule */}
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h3 className="font-semibold text-gray-900 mb-4">Today's Schedule</h3>
          <div className="space-y-3">
            {todayEvents.length === 0 ? (
              <p className="text-gray-500 text-sm">No events scheduled for today</p>
            ) : (
              todayEvents.map(event => (
                <div key={event.id} className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                  <div className={`size-3 rounded-full mt-1.5 ${event.color}`} />
                  <div className="flex-1">
                    <p className="font-medium text-gray-900">{event.title}</p>
                    {event.course && (
                      <p className="text-xs text-gray-500 mt-0.5">{event.course}</p>
                    )}
                    <div className="flex items-center gap-3 mt-1 text-xs text-gray-600">
                      <div className="flex items-center gap-1">
                        <Clock className="size-3" />
                        <span>{event.time}</span>
                      </div>
                      {event.location && (
                        <div className="flex items-center gap-1">
                          <MapPin className="size-3" />
                          <span>{event.location}</span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Upcoming Events */}
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h3 className="font-semibold text-gray-900 mb-4">Upcoming Events</h3>
          <div className="space-y-3">
            {upcomingEvents.map(event => (
              <div key={event.id} className="flex items-start gap-3 pb-3 border-b border-gray-100 last:border-0">
                <div className={`size-3 rounded-full mt-1.5 ${event.color}`} />
                <div className="flex-1">
                  <p className="font-medium text-gray-900 text-sm">{event.title}</p>
                  {event.course && (
                    <p className="text-xs text-gray-500 mt-0.5">{event.course}</p>
                  )}
                  <p className="text-xs text-gray-600 mt-1">
                    {new Date(event.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} at {event.time}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Event Legend */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h3 className="font-semibold text-gray-900 mb-4">Event Types</h3>
        <div className="flex flex-wrap gap-4">
          <div className="flex items-center gap-2">
            <div className="size-4 bg-blue-500 rounded" />
            <span className="text-sm text-gray-700">Classes</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="size-4 bg-orange-500 rounded" />
            <span className="text-sm text-gray-700">Exams</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="size-4 bg-red-500 rounded" />
            <span className="text-sm text-gray-700">Assignments</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="size-4 bg-purple-500 rounded" />
            <span className="text-sm text-gray-700">Appointments</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="size-4 bg-green-500 rounded" />
            <span className="text-sm text-gray-700">Events</span>
          </div>
        </div>
      </div>
    </div>
  );
}
