import { Bell, CheckCircle, AlertCircle, Info, Calendar, BookOpen, Award, X } from 'lucide-react';

interface Notification {
  id: string;
  type: 'success' | 'warning' | 'info' | 'reminder';
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
  category: string;
  actionLabel?: string;
}

export function Notifications() {
  const notifications: Notification[] = [
    {
      id: '1',
      type: 'warning',
      title: 'Assignment Due Soon',
      message: 'Your CS 301 Assignment 3 is due in 2 days (February 8, 2026)',
      timestamp: '2026-02-04T10:00:00',
      read: false,
      category: 'Academic',
      actionLabel: 'View Assignment'
    },
    {
      id: '2',
      type: 'info',
      title: 'New Study Resource Available',
      message: 'Dr. Williams uploaded new lecture notes for Machine Learning',
      timestamp: '2026-02-04T09:30:00',
      read: false,
      category: 'Resources'
    },
    {
      id: '3',
      type: 'reminder',
      title: 'Advisor Meeting Tomorrow',
      message: 'Don\'t forget your appointment with Dr. Anderson at 2:30 PM',
      timestamp: '2026-02-04T08:00:00',
      read: false,
      category: 'Appointments',
      actionLabel: 'View Details'
    },
    {
      id: '4',
      type: 'success',
      title: 'Grade Posted',
      message: 'Your grade for CS 320 Project 1 has been posted: A+ (98/100)',
      timestamp: '2026-02-03T16:45:00',
      read: false,
      category: 'Grades',
      actionLabel: 'View Grade'
    },
    {
      id: '5',
      type: 'info',
      title: 'Registration Opens Soon',
      message: 'Fall 2026 registration begins on February 17 at 9:00 AM',
      timestamp: '2026-02-03T14:00:00',
      read: false,
      category: 'Registration'
    },
    {
      id: '6',
      type: 'success',
      title: 'Scholarship Application Received',
      message: 'Your application for CS Department Excellence Scholarship has been received',
      timestamp: '2026-02-03T11:20:00',
      read: true,
      category: 'Financial Aid'
    },
    {
      id: '7',
      type: 'reminder',
      title: 'Career Fair This Week',
      message: 'Spring Career Fair is on February 18. Register now to secure your spot!',
      timestamp: '2026-02-02T15:00:00',
      read: true,
      category: 'Career',
      actionLabel: 'Register'
    },
    {
      id: '8',
      type: 'info',
      title: 'Study Group Invitation',
      message: 'Alex Chen invited you to join "Data Structures Mastery" study group',
      timestamp: '2026-02-02T10:30:00',
      read: true,
      category: 'Study Groups',
      actionLabel: 'View Invitation'
    },
    {
      id: '9',
      type: 'success',
      title: 'Achievement Unlocked',
      message: 'You\'ve earned the "Perfect Score" achievement for getting 100% on an assignment!',
      timestamp: '2026-02-01T18:00:00',
      read: true,
      category: 'Achievements'
    },
    {
      id: '10',
      type: 'warning',
      title: 'Tuition Payment Reminder',
      message: 'Spring 2026 tuition payment is due by February 15, 2026',
      timestamp: '2026-02-01T09:00:00',
      read: true,
      category: 'Financial'
    }
  ];

  const unreadCount = notifications.filter(n => !n.read).length;
  const unreadNotifications = notifications.filter(n => !n.read);
  const readNotifications = notifications.filter(n => n.read);

  const getIcon = (type: string) => {
    switch (type) {
      case 'success':
        return <CheckCircle className="size-5 text-green-600" />;
      case 'warning':
        return <AlertCircle className="size-5 text-orange-600" />;
      case 'reminder':
        return <Calendar className="size-5 text-blue-600" />;
      case 'info':
      default:
        return <Info className="size-5 text-gray-600" />;
    }
  };

  const getBgColor = (type: string, read: boolean) => {
    if (read) return 'bg-white';
    
    switch (type) {
      case 'success':
        return 'bg-green-50 border-green-200';
      case 'warning':
        return 'bg-orange-50 border-orange-200';
      case 'reminder':
        return 'bg-blue-50 border-blue-200';
      case 'info':
      default:
        return 'bg-gray-50 border-gray-200';
    }
  };

  const formatTimestamp = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 60) {
      return `${diffMins} minutes ago`;
    } else if (diffHours < 24) {
      return `${diffHours} hours ago`;
    } else if (diffDays === 1) {
      return 'Yesterday';
    } else if (diffDays < 7) {
      return `${diffDays} days ago`;
    } else {
      return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Bell className="size-8 text-blue-600" />
            <div>
              <h2 className="text-2xl font-semibold text-gray-900">Notifications</h2>
              <p className="text-sm text-gray-500 mt-1">
                {unreadCount} unread notification{unreadCount !== 1 ? 's' : ''}
              </p>
            </div>
          </div>
          <div className="flex gap-2">
            <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium">
              Mark All as Read
            </button>
            <button className="px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors text-sm font-medium">
              Settings
            </button>
          </div>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <p className="text-sm text-gray-500">Unread</p>
          <p className="text-2xl font-semibold text-gray-900 mt-1">{unreadCount}</p>
        </div>
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <p className="text-sm text-gray-500">Academic</p>
          <p className="text-2xl font-semibold text-gray-900 mt-1">
            {notifications.filter(n => n.category === 'Academic').length}
          </p>
        </div>
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <p className="text-sm text-gray-500">Reminders</p>
          <p className="text-2xl font-semibold text-gray-900 mt-1">
            {notifications.filter(n => n.type === 'reminder').length}
          </p>
        </div>
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <p className="text-sm text-gray-500">This Week</p>
          <p className="text-2xl font-semibold text-gray-900 mt-1">
            {notifications.filter(n => {
              const diff = new Date().getTime() - new Date(n.timestamp).getTime();
              return diff < 7 * 24 * 60 * 60 * 1000;
            }).length}
          </p>
        </div>
      </div>

      {/* Unread Notifications */}
      {unreadNotifications.length > 0 && (
        <div>
          <h3 className="font-semibold text-gray-900 mb-4">Unread ({unreadNotifications.length})</h3>
          <div className="space-y-3">
            {unreadNotifications.map(notification => (
              <div
                key={notification.id}
                className={`p-4 rounded-lg border-2 ${getBgColor(notification.type, notification.read)}`}
              >
                <div className="flex items-start gap-4">
                  <div className="flex-shrink-0 mt-1">{getIcon(notification.type)}</div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex-1">
                        <h4 className="font-semibold text-gray-900">{notification.title}</h4>
                        <span className="inline-block px-2 py-0.5 bg-white rounded text-xs text-gray-600 mt-1">
                          {notification.category}
                        </span>
                      </div>
                      <button className="text-gray-400 hover:text-gray-600 ml-4">
                        <X className="size-5" />
                      </button>
                    </div>
                    <p className="text-sm text-gray-700 mb-2">{notification.message}</p>
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-gray-500">{formatTimestamp(notification.timestamp)}</span>
                      {notification.actionLabel && (
                        <button className="text-sm text-blue-600 hover:text-blue-700 font-medium">
                          {notification.actionLabel} →
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Earlier Notifications */}
      {readNotifications.length > 0 && (
        <div>
          <h3 className="font-semibold text-gray-900 mb-4">Earlier</h3>
          <div className="space-y-3">
            {readNotifications.map(notification => (
              <div
                key={notification.id}
                className="p-4 rounded-lg border border-gray-200 bg-white opacity-75 hover:opacity-100 transition-opacity"
              >
                <div className="flex items-start gap-4">
                  <div className="flex-shrink-0 mt-1 opacity-50">{getIcon(notification.type)}</div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex-1">
                        <h4 className="font-medium text-gray-900">{notification.title}</h4>
                        <span className="inline-block px-2 py-0.5 bg-gray-100 rounded text-xs text-gray-600 mt-1">
                          {notification.category}
                        </span>
                      </div>
                      <button className="text-gray-400 hover:text-gray-600 ml-4">
                        <X className="size-5" />
                      </button>
                    </div>
                    <p className="text-sm text-gray-600 mb-2">{notification.message}</p>
                    <span className="text-xs text-gray-500">{formatTimestamp(notification.timestamp)}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Empty State */}
      {notifications.length === 0 && (
        <div className="bg-white rounded-lg border border-gray-200 p-12 text-center">
          <Bell className="size-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No Notifications</h3>
          <p className="text-gray-500">You're all caught up! Check back later for updates.</p>
        </div>
      )}

      {/* Notification Preferences */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg p-6 text-white">
        <h3 className="text-xl font-semibold mb-3">🔔 Notification Preferences</h3>
        <p className="text-blue-100 mb-4">
          Manage how and when you receive notifications about assignments, grades, and important updates.
        </p>
        <button className="px-4 py-2 bg-white text-blue-600 rounded-lg hover:bg-blue-50 transition-colors font-medium">
          Manage Preferences
        </button>
      </div>
    </div>
  );
}
