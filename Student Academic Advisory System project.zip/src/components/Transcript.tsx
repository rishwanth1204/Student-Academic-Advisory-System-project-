import { Download, Printer, Share2, Award, TrendingUp } from 'lucide-react';

interface CourseRecord {
  semester: string;
  courses: {
    code: string;
    name: string;
    credits: number;
    grade: string;
    gradePoints: number;
  }[];
  semesterGPA: number;
  cumulativeGPA: number;
}

export function Transcript() {
  const studentInfo = {
    name: 'Sarah Johnson',
    studentId: '2024-CS-1234',
    major: 'Computer Science',
    minor: 'Mathematics',
    expectedGraduation: 'Spring 2027',
    admissionDate: 'Fall 2023'
  };

  const transcriptData: CourseRecord[] = [
    {
      semester: 'Fall 2023',
      courses: [
        { code: 'CS 101', name: 'Introduction to Programming', credits: 3, grade: 'A', gradePoints: 4.0 },
        { code: 'MATH 101', name: 'Calculus I', credits: 4, grade: 'A', gradePoints: 4.0 },
        { code: 'ENG 101', name: 'English Composition', credits: 3, grade: 'A-', gradePoints: 3.7 },
        { code: 'HIST 201', name: 'World History', credits: 3, grade: 'B+', gradePoints: 3.3 },
        { code: 'PHYS 201', name: 'Physics I', credits: 4, grade: 'B+', gradePoints: 3.3 }
      ],
      semesterGPA: 3.6,
      cumulativeGPA: 3.6
    },
    {
      semester: 'Spring 2024',
      courses: [
        { code: 'CS 201', name: 'Data Structures', credits: 3, grade: 'A-', gradePoints: 3.7 },
        { code: 'MATH 102', name: 'Calculus II', credits: 4, grade: 'A-', gradePoints: 3.7 },
        { code: 'MATH 201', name: 'Linear Algebra', credits: 3, grade: 'A', gradePoints: 4.0 },
        { code: 'PHYS 202', name: 'Physics II', credits: 4, grade: 'B', gradePoints: 3.0 },
        { code: 'PSYC 101', name: 'Introduction to Psychology', credits: 3, grade: 'A', gradePoints: 4.0 }
      ],
      semesterGPA: 3.7,
      cumulativeGPA: 3.65
    },
    {
      semester: 'Fall 2024',
      courses: [
        { code: 'CS 202', name: 'Algorithms', credits: 3, grade: 'B+', gradePoints: 3.3 },
        { code: 'CS 210', name: 'Computer Organization', credits: 3, grade: 'A', gradePoints: 4.0 },
        { code: 'MATH 210', name: 'Discrete Mathematics', credits: 4, grade: 'B+', gradePoints: 3.3 },
        { code: 'ECON 101', name: 'Microeconomics', credits: 3, grade: 'A-', gradePoints: 3.7 },
        { code: 'ART 101', name: 'Art History', credits: 3, grade: 'A', gradePoints: 4.0 }
      ],
      semesterGPA: 3.7,
      cumulativeGPA: 3.67
    },
    {
      semester: 'Spring 2025',
      courses: [
        { code: 'CS 305', name: 'Database Systems', credits: 4, grade: 'A', gradePoints: 4.0 },
        { code: 'CS 320', name: 'Web Development', credits: 3, grade: 'A+', gradePoints: 4.0 },
        { code: 'CS 330', name: 'Software Engineering', credits: 3, grade: 'A', gradePoints: 4.0 },
        { code: 'STAT 301', name: 'Probability & Statistics', credits: 3, grade: 'A', gradePoints: 4.0 },
        { code: 'BUS 301', name: 'Business Communication', credits: 3, grade: 'A', gradePoints: 4.0 }
      ],
      semesterGPA: 4.0,
      cumulativeGPA: 3.74
    },
    {
      semester: 'Fall 2025',
      courses: [
        { code: 'CS 301', name: 'Data Structures', credits: 3, grade: 'A-', gradePoints: 3.7 },
        { code: 'CS 340', name: 'Computer Networks', credits: 3, grade: 'B+', gradePoints: 3.3 },
        { code: 'CS 350', name: 'Operating Systems', credits: 4, grade: 'A', gradePoints: 4.0 },
        { code: 'CS 420', name: 'Mobile App Development', credits: 3, grade: 'A+', gradePoints: 4.0 },
        { code: 'PHIL 201', name: 'Ethics', credits: 3, grade: 'A-', gradePoints: 3.7 }
      ],
      semesterGPA: 3.75,
      cumulativeGPA: 3.75
    }
  ];

  const totalCredits = transcriptData.reduce((sum, semester) => 
    sum + semester.courses.reduce((s, c) => s + c.credits, 0), 0
  );

  const currentGPA = 3.75;

  const gradeScale = [
    { grade: 'A+', points: 4.0 },
    { grade: 'A', points: 4.0 },
    { grade: 'A-', points: 3.7 },
    { grade: 'B+', points: 3.3 },
    { grade: 'B', points: 3.0 },
    { grade: 'B-', points: 2.7 },
    { grade: 'C+', points: 2.3 },
    { grade: 'C', points: 2.0 },
    { grade: 'C-', points: 1.7 },
    { grade: 'D', points: 1.0 },
    { grade: 'F', points: 0.0 }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-semibold text-gray-900">Official Transcript</h2>
            <p className="text-sm text-gray-500 mt-1">Academic Record Summary</p>
          </div>
          <div className="flex gap-2">
            <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium flex items-center gap-2">
              <Download className="size-4" />
              Download PDF
            </button>
            <button className="px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors text-sm font-medium">
              <Printer className="size-4" />
            </button>
            <button className="px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors text-sm font-medium">
              <Share2 className="size-4" />
            </button>
          </div>
        </div>

        {/* Student Info */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 p-4 bg-gray-50 rounded-lg">
          <div>
            <p className="text-xs text-gray-500">Student Name</p>
            <p className="font-medium text-gray-900">{studentInfo.name}</p>
          </div>
          <div>
            <p className="text-xs text-gray-500">Student ID</p>
            <p className="font-medium text-gray-900">{studentInfo.studentId}</p>
          </div>
          <div>
            <p className="text-xs text-gray-500">Major</p>
            <p className="font-medium text-gray-900">{studentInfo.major}</p>
          </div>
          <div>
            <p className="text-xs text-gray-500">Minor</p>
            <p className="font-medium text-gray-900">{studentInfo.minor}</p>
          </div>
          <div>
            <p className="text-xs text-gray-500">Admission Date</p>
            <p className="font-medium text-gray-900">{studentInfo.admissionDate}</p>
          </div>
          <div>
            <p className="text-xs text-gray-500">Expected Graduation</p>
            <p className="font-medium text-gray-900">{studentInfo.expectedGraduation}</p>
          </div>
        </div>
      </div>

      {/* GPA Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="flex items-center gap-3">
            <Award className="size-10 text-blue-600" />
            <div>
              <p className="text-3xl font-semibold text-gray-900">{currentGPA}</p>
              <p className="text-sm text-gray-500">Cumulative GPA</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="flex items-center gap-3">
            <TrendingUp className="size-10 text-green-600" />
            <div>
              <p className="text-3xl font-semibold text-gray-900">{totalCredits}</p>
              <p className="text-sm text-gray-500">Total Credits Earned</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="flex items-center gap-3">
            <Award className="size-10 text-purple-600" />
            <div>
              <p className="text-3xl font-semibold text-gray-900">4.0</p>
              <p className="text-sm text-gray-500">Highest Semester GPA</p>
            </div>
          </div>
        </div>
      </div>

      {/* Academic History */}
      <div className="space-y-6">
        {transcriptData.map((record, index) => (
          <div key={index} className="bg-white rounded-lg border border-gray-200 overflow-hidden">
            <div className="bg-gray-50 px-6 py-4 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold text-gray-900">{record.semester}</h3>
                <div className="flex items-center gap-6 text-sm">
                  <div>
                    <span className="text-gray-500">Semester GPA: </span>
                    <span className="font-semibold text-gray-900">{record.semesterGPA.toFixed(2)}</span>
                  </div>
                  <div>
                    <span className="text-gray-500">Cumulative GPA: </span>
                    <span className="font-semibold text-gray-900">{record.cumulativeGPA.toFixed(2)}</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-200 bg-gray-50 text-sm">
                    <th className="px-6 py-3 text-left font-medium text-gray-700">Course Code</th>
                    <th className="px-6 py-3 text-left font-medium text-gray-700">Course Name</th>
                    <th className="px-6 py-3 text-center font-medium text-gray-700">Credits</th>
                    <th className="px-6 py-3 text-center font-medium text-gray-700">Grade</th>
                    <th className="px-6 py-3 text-center font-medium text-gray-700">Grade Points</th>
                  </tr>
                </thead>
                <tbody>
                  {record.courses.map((course, courseIndex) => (
                    <tr key={courseIndex} className="border-b border-gray-100 hover:bg-gray-50">
                      <td className="px-6 py-4 text-sm font-medium text-gray-900">{course.code}</td>
                      <td className="px-6 py-4 text-sm text-gray-700">{course.name}</td>
                      <td className="px-6 py-4 text-sm text-center text-gray-700">{course.credits}</td>
                      <td className="px-6 py-4 text-center">
                        <span className={`inline-block px-3 py-1 rounded-full text-sm font-medium ${
                          course.gradePoints >= 4.0 ? 'bg-green-100 text-green-700' :
                          course.gradePoints >= 3.7 ? 'bg-blue-100 text-blue-700' :
                          course.gradePoints >= 3.0 ? 'bg-yellow-100 text-yellow-700' :
                          'bg-orange-100 text-orange-700'
                        }`}>
                          {course.grade}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-sm text-center text-gray-700">{course.gradePoints.toFixed(1)}</td>
                    </tr>
                  ))}
                  <tr className="bg-gray-50 font-medium">
                    <td className="px-6 py-4 text-sm text-gray-900" colSpan={2}>Semester Totals</td>
                    <td className="px-6 py-4 text-sm text-center text-gray-900">
                      {record.courses.reduce((sum, c) => sum + c.credits, 0)}
                    </td>
                    <td className="px-6 py-4 text-sm text-center text-gray-900" colSpan={2}>
                      GPA: {record.semesterGPA.toFixed(2)}
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        ))}
      </div>

      {/* Grade Scale */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h3 className="font-semibold text-gray-900 mb-4">Grading Scale</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
          {gradeScale.map((item, index) => (
            <div key={index} className="p-3 bg-gray-50 rounded-lg text-center">
              <p className="font-semibold text-gray-900">{item.grade}</p>
              <p className="text-sm text-gray-600">{item.points.toFixed(1)}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Academic Honors */}
      <div className="bg-gradient-to-r from-yellow-400 to-orange-500 rounded-lg p-6 text-white">
        <h3 className="text-xl font-semibold mb-3">🏆 Academic Honors</h3>
        <div className="space-y-2">
          <div className="flex items-center gap-3">
            <Award className="size-5" />
            <span>Dean's List - Fall 2023, Spring 2025, Fall 2025</span>
          </div>
          <div className="flex items-center gap-3">
            <Award className="size-5" />
            <span>President's Honor Roll - Spring 2025</span>
          </div>
          <div className="flex items-center gap-3">
            <Award className="size-5" />
            <span>Computer Science Department Excellence Award - 2025</span>
          </div>
        </div>
      </div>

      {/* Footer Note */}
      <div className="bg-gray-50 rounded-lg p-4 border border-gray-200">
        <p className="text-xs text-gray-600 text-center">
          This is an unofficial transcript for student reference only. For official transcripts, please contact the Registrar's Office.
          Generated on {new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}.
        </p>
      </div>
    </div>
  );
}
