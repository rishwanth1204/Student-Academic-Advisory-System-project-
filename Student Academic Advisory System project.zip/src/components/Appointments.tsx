import { useState } from 'react';
import { Calendar, Clock, Plus, Video, MapPin, X } from 'lucide-react';

interface Appointment {
  id: string;
  date: string;
  time: string;
  type: 'in-person' | 'virtual';
  topic: string;
  status: 'confirmed' | 'pending' | 'completed';
  notes?: string;
}

export function Appointments() {
  const [showNewAppointment, setShowNewAppointment] = useState(false);
  const [appointments] = useState<Appointment[]>([
    {
      id: '1',
      date: '2026-02-10',
      time: '2:30 PM',
      type: 'in-person',
      topic: 'Course Selection for Fall 2026',
      status: 'confirmed',
      notes: 'Bring current transcript and list of desired courses',
    },
    {
      id: '2',
      date: '2026-02-24',
      time: '11:00 AM',
      type: 'virtual',
      topic: 'Career Planning Discussion',
      status: 'pending',
    },
    {
      id: '3',
      date: '2026-01-20',
      time: '3:00 PM',
      type: 'in-person',
      topic: 'Academic Progress Review',
      status: 'completed',
      notes: 'Discussed GPA improvement strategies',
    },
    {
      id: '4',
      date: '2026-01-10',
      time: '10:00 AM',
      type: 'virtual',
      topic: 'Spring Semester Planning',
      status: 'completed',
    },
  ]);

  const upcomingAppointments = appointments.filter((apt) => apt.status !== 'completed');
  const pastAppointments = appointments.filter((apt) => apt.status === 'completed');

  return (
    <div className="space-y-6">
      {/* Header with New Appointment Button */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="font-semibold text-gray-900">My Appointments</h2>
            <p className="text-sm text-gray-500 mt-1">
              {upcomingAppointments.length} upcoming • {pastAppointments.length} past
            </p>
          </div>
          <button
            onClick={() => setShowNewAppointment(!showNewAppointment)}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium flex items-center gap-2"
          >
            <Plus className="size-4" />
            New Appointment
          </button>
        </div>
      </div>

      {/* New Appointment Form */}
      {showNewAppointment && (
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-gray-900">Schedule New Appointment</h3>
            <button
              onClick={() => setShowNewAppointment(false)}
              className="text-gray-400 hover:text-gray-600"
            >
              <X className="size-5" />
            </button>
          </div>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Appointment Topic
              </label>
              <input
                type="text"
                placeholder="e.g., Course Selection, Career Advice"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Preferred Date
                </label>
                <input
                  type="date"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Preferred Time
                </label>
                <input
                  type="time"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Meeting Type
              </label>
              <div className="flex gap-4">
                <label className="flex items-center gap-2">
                  <input type="radio" name="type" value="in-person" defaultChecked />
                  <span className="text-sm text-gray-700">In-Person</span>
                </label>
                <label className="flex items-center gap-2">
                  <input type="radio" name="type" value="virtual" />
                  <span className="text-sm text-gray-700">Virtual</span>
                </label>
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Additional Notes (Optional)
              </label>
              <textarea
                rows={3}
                placeholder="Any specific topics or questions you'd like to discuss..."
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div className="flex gap-3">
              <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium">
                Submit Request
              </button>
              <button
                onClick={() => setShowNewAppointment(false)}
                className="px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors text-sm font-medium"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Upcoming Appointments */}
      {upcomingAppointments.length > 0 && (
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h3 className="font-semibold text-gray-900 mb-4">Upcoming Appointments</h3>
          <div className="space-y-4">
            {upcomingAppointments.map((appointment) => (
              <div
                key={appointment.id}
                className="p-4 border border-gray-200 rounded-lg hover:shadow-md transition-shadow"
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-4">
                    <div className="p-3 bg-blue-100 rounded-lg">
                      {appointment.type === 'virtual' ? (
                        <Video className="size-6 text-blue-600" />
                      ) : (
                        <MapPin className="size-6 text-blue-600" />
                      )}
                    </div>
                    <div>
                      <h4 className="font-medium text-gray-900">{appointment.topic}</h4>
                      <div className="flex items-center gap-3 mt-2 text-sm text-gray-600">
                        <div className="flex items-center gap-1">
                          <Calendar className="size-4" />
                          <span>{new Date(appointment.date).toLocaleDateString('en-US', { 
                            month: 'short', 
                            day: 'numeric', 
                            year: 'numeric' 
                          })}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Clock className="size-4" />
                          <span>{appointment.time}</span>
                        </div>
                        <span className="px-2 py-0.5 bg-gray-100 text-gray-700 rounded text-xs">
                          {appointment.type === 'virtual' ? 'Virtual' : 'In-Person'}
                        </span>
                      </div>
                      {appointment.notes && (
                        <p className="text-sm text-gray-500 mt-2">{appointment.notes}</p>
                      )}
                    </div>
                  </div>
                  <span
                    className={`px-3 py-1 rounded-full text-xs font-medium ${
                      appointment.status === 'confirmed'
                        ? 'bg-green-100 text-green-700'
                        : 'bg-yellow-100 text-yellow-700'
                    }`}
                  >
                    {appointment.status}
                  </span>
                </div>
                <div className="flex gap-3 mt-4">
                  {appointment.type === 'virtual' && (
                    <button className="px-3 py-1.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium">
                      Join Meeting
                    </button>
                  )}
                  <button className="px-3 py-1.5 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors text-sm font-medium">
                    Reschedule
                  </button>
                  <button className="px-3 py-1.5 bg-white border border-red-300 text-red-600 rounded-lg hover:bg-red-50 transition-colors text-sm font-medium">
                    Cancel
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Past Appointments */}
      {pastAppointments.length > 0 && (
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h3 className="font-semibold text-gray-900 mb-4">Past Appointments</h3>
          <div className="space-y-3">
            {pastAppointments.map((appointment) => (
              <div
                key={appointment.id}
                className="p-4 bg-gray-50 rounded-lg"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <h4 className="font-medium text-gray-900">{appointment.topic}</h4>
                    <div className="flex items-center gap-3 mt-1 text-sm text-gray-600">
                      <span>{new Date(appointment.date).toLocaleDateString('en-US', { 
                        month: 'short', 
                        day: 'numeric', 
                        year: 'numeric' 
                      })}</span>
                      <span>•</span>
                      <span>{appointment.time}</span>
                      <span>•</span>
                      <span>{appointment.type === 'virtual' ? 'Virtual' : 'In-Person'}</span>
                    </div>
                    {appointment.notes && (
                      <p className="text-sm text-gray-500 mt-2">{appointment.notes}</p>
                    )}
                  </div>
                  <span className="px-3 py-1 bg-gray-200 text-gray-600 rounded-full text-xs font-medium">
                    Completed
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
