import { useState } from 'react';
import { Search, Plus, Minus, Calendar, Users, Star, Clock, AlertCircle, CheckCircle2 } from 'lucide-react';

interface Course {
  id: string;
  code: string;
  name: string;
  credits: number;
  instructor: string;
  schedule: string;
  location: string;
  capacity: number;
  enrolled: number;
  prerequisites: string[];
  rating: number;
  status: 'open' | 'waitlist' | 'closed';
}

export function Registration() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCourses, setSelectedCourses] = useState<string[]>(['1', '2']);

  const availableCourses: Course[] = [
    {
      id: '1',
      code: 'CS 450',
      name: 'Machine Learning',
      credits: 3,
      instructor: 'Dr. Sarah Williams',
      schedule: 'Mon/Wed 2:00 PM - 3:30 PM',
      location: 'Building A, Room 301',
      capacity: 40,
      enrolled: 35,
      prerequisites: ['CS 340', 'STAT 301'],
      rating: 4.7,
      status: 'open'
    },
    {
      id: '2',
      code: 'CS 460',
      name: 'Computer Graphics',
      credits: 3,
      instructor: 'Prof. Michael Chen',
      schedule: 'Tue/Thu 10:00 AM - 11:30 AM',
      location: 'Building C, Room 205',
      capacity: 35,
      enrolled: 32,
      prerequisites: ['CS 301', 'MATH 201'],
      rating: 4.5,
      status: 'open'
    },
    {
      id: '3',
      code: 'CS 470',
      name: 'Cloud Computing',
      credits: 3,
      instructor: 'Dr. Jennifer Lee',
      schedule: 'Mon/Wed 4:00 PM - 5:30 PM',
      location: 'Building B, Room 110',
      capacity: 30,
      enrolled: 30,
      prerequisites: ['CS 350'],
      rating: 4.8,
      status: 'waitlist'
    },
    {
      id: '4',
      code: 'CS 480',
      name: 'Mobile App Development',
      credits: 3,
      instructor: 'Prof. David Kumar',
      schedule: 'Tue/Thu 1:00 PM - 2:30 PM',
      location: 'Building D, Room 150',
      capacity: 25,
      enrolled: 25,
      prerequisites: ['CS 320'],
      rating: 4.9,
      status: 'closed'
    },
    {
      id: '5',
      code: 'CS 490',
      name: 'Cybersecurity',
      credits: 3,
      instructor: 'Dr. Emily Zhang',
      schedule: 'Mon/Wed 10:00 AM - 11:30 AM',
      location: 'Building A, Room 220',
      capacity: 35,
      enrolled: 28,
      prerequisites: ['CS 350', 'CS 305'],
      rating: 4.6,
      status: 'open'
    },
    {
      id: '6',
      code: 'CS 495',
      name: 'Senior Capstone Project',
      credits: 4,
      instructor: 'Various Faculty',
      schedule: 'Flexible',
      location: 'TBD',
      capacity: 50,
      enrolled: 42,
      prerequisites: ['Senior Standing', '90+ Credits'],
      rating: 4.4,
      status: 'open'
    },
    {
      id: '7',
      code: 'MATH 320',
      name: 'Numerical Analysis',
      credits: 3,
      instructor: 'Prof. Robert Anderson',
      schedule: 'Tue/Thu 3:00 PM - 4:30 PM',
      location: 'Math Building, Room 101',
      capacity: 40,
      enrolled: 25,
      prerequisites: ['MATH 201', 'CS 101'],
      rating: 4.3,
      status: 'open'
    },
    {
      id: '8',
      code: 'BUS 450',
      name: 'Technology Entrepreneurship',
      credits: 3,
      instructor: 'Dr. Lisa Thompson',
      schedule: 'Wed 6:00 PM - 9:00 PM',
      location: 'Business School, Room 305',
      capacity: 30,
      enrolled: 18,
      prerequisites: ['Junior Standing'],
      rating: 4.8,
      status: 'open'
    }
  ];

  const filteredCourses = availableCourses.filter(course =>
    course.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
    course.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    course.instructor.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const selectedCoursesList = availableCourses.filter(course => 
    selectedCourses.includes(course.id)
  );

  const totalCredits = selectedCoursesList.reduce((sum, course) => sum + course.credits, 0);

  const toggleCourse = (courseId: string) => {
    if (selectedCourses.includes(courseId)) {
      setSelectedCourses(selectedCourses.filter(id => id !== courseId));
    } else {
      setSelectedCourses([...selectedCourses, courseId]);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'open':
        return <span className="px-2 py-1 bg-green-100 text-green-700 rounded text-xs font-medium">Open</span>;
      case 'waitlist':
        return <span className="px-2 py-1 bg-yellow-100 text-yellow-700 rounded text-xs font-medium">Waitlist</span>;
      case 'closed':
        return <span className="px-2 py-1 bg-red-100 text-red-700 rounded text-xs font-medium">Closed</span>;
      default:
        return null;
    }
  };

  return (
    <div className="space-y-6">
      {/* Registration Period */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-semibold">Fall 2026 Registration</h2>
            <p className="text-blue-100 mt-2">Registration Period: February 15 - March 1, 2026</p>
          </div>
          <div className="text-right">
            <p className="text-sm text-blue-100">Your Registration Time</p>
            <p className="text-xl font-semibold mt-1">Feb 17, 9:00 AM</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Course Search */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white rounded-lg border border-gray-200 p-6">
            <h3 className="font-semibold text-gray-900 mb-4">Available Courses</h3>
            
            <div className="relative mb-4">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 size-5 text-gray-400" />
              <input
                type="text"
                placeholder="Search courses..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div className="space-y-4">
              {filteredCourses.map(course => {
                const isSelected = selectedCourses.includes(course.id);
                const availableSeats = course.capacity - course.enrolled;
                
                return (
                  <div
                    key={course.id}
                    className={`p-4 border-2 rounded-lg transition-all ${
                      isSelected
                        ? 'border-blue-500 bg-blue-50'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-1">
                          <h4 className="font-semibold text-gray-900">{course.code}</h4>
                          {getStatusBadge(course.status)}
                          <div className="flex items-center gap-1 text-yellow-500">
                            <Star className="size-4 fill-current" />
                            <span className="text-sm text-gray-900">{course.rating}</span>
                          </div>
                        </div>
                        <p className="text-gray-700">{course.name}</p>
                        <p className="text-sm text-gray-600 mt-1">{course.instructor}</p>
                      </div>
                      <button
                        onClick={() => toggleCourse(course.id)}
                        disabled={course.status === 'closed' && !isSelected}
                        className={`p-2 rounded-lg transition-colors ${
                          isSelected
                            ? 'bg-red-100 text-red-600 hover:bg-red-200'
                            : course.status === 'closed'
                            ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                            : 'bg-blue-100 text-blue-600 hover:bg-blue-200'
                        }`}
                      >
                        {isSelected ? <Minus className="size-5" /> : <Plus className="size-5" />}
                      </button>
                    </div>

                    <div className="grid grid-cols-2 gap-3 text-sm text-gray-600 mb-3">
                      <div className="flex items-center gap-2">
                        <Clock className="size-4" />
                        <span>{course.schedule}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Users className="size-4" />
                        <span>{course.enrolled}/{course.capacity} enrolled</span>
                      </div>
                      <div className="flex items-center gap-2 col-span-2">
                        <Calendar className="size-4" />
                        <span>{course.location}</span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between text-sm">
                      <div>
                        <span className="text-gray-600">Credits: </span>
                        <span className="font-medium text-gray-900">{course.credits}</span>
                      </div>
                      <div className={`font-medium ${
                        availableSeats > 10 ? 'text-green-600' :
                        availableSeats > 0 ? 'text-yellow-600' :
                        'text-red-600'
                      }`}>
                        {availableSeats > 0 ? `${availableSeats} seats available` : 'Full'}
                      </div>
                    </div>

                    {course.prerequisites.length > 0 && (
                      <div className="mt-3 pt-3 border-t border-gray-200">
                        <p className="text-xs text-gray-500">Prerequisites:</p>
                        <div className="flex flex-wrap gap-1 mt-1">
                          {course.prerequisites.map((prereq, index) => (
                            <span key={index} className="px-2 py-0.5 bg-gray-100 text-gray-600 rounded text-xs">
                              {prereq}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Shopping Cart */}
        <div className="space-y-6">
          <div className="bg-white rounded-lg border border-gray-200 p-6 sticky top-32">
            <h3 className="font-semibold text-gray-900 mb-4">Course Schedule</h3>

            {selectedCoursesList.length === 0 ? (
              <div className="text-center py-8">
                <AlertCircle className="size-12 text-gray-300 mx-auto mb-3" />
                <p className="text-gray-500 text-sm">No courses selected</p>
              </div>
            ) : (
              <>
                <div className="space-y-3 mb-4">
                  {selectedCoursesList.map(course => (
                    <div key={course.id} className="p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-start justify-between mb-1">
                        <div className="flex-1">
                          <p className="font-medium text-gray-900 text-sm">{course.code}</p>
                          <p className="text-xs text-gray-600">{course.name}</p>
                        </div>
                        <button
                          onClick={() => toggleCourse(course.id)}
                          className="text-red-600 hover:text-red-700"
                        >
                          <Minus className="size-4" />
                        </button>
                      </div>
                      <p className="text-xs text-gray-500 mt-1">{course.schedule}</p>
                      <p className="text-xs text-gray-900 font-medium mt-1">{course.credits} credits</p>
                    </div>
                  ))}
                </div>

                <div className="border-t border-gray-200 pt-4 mb-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-gray-600">Total Credits</span>
                    <span className="text-lg font-semibold text-gray-900">{totalCredits}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Total Courses</span>
                    <span className="font-medium text-gray-900">{selectedCoursesList.length}</span>
                  </div>
                </div>

                {totalCredits < 12 && (
                  <div className="flex items-start gap-2 p-3 bg-yellow-50 border border-yellow-200 rounded-lg mb-4">
                    <AlertCircle className="size-4 text-yellow-600 mt-0.5 flex-shrink-0" />
                    <p className="text-xs text-yellow-800">
                      Minimum 12 credits required for full-time status
                    </p>
                  </div>
                )}

                {totalCredits > 18 && (
                  <div className="flex items-start gap-2 p-3 bg-red-50 border border-red-200 rounded-lg mb-4">
                    <AlertCircle className="size-4 text-red-600 mt-0.5 flex-shrink-0" />
                    <p className="text-xs text-red-800">
                      Maximum 18 credits allowed without approval
                    </p>
                  </div>
                )}

                <button
                  disabled={totalCredits < 12 || totalCredits > 18}
                  className="w-full px-4 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium disabled:bg-gray-300 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                >
                  <CheckCircle2 className="size-5" />
                  Submit Registration
                </button>

                <button className="w-full px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors text-sm font-medium mt-2">
                  Save as Draft
                </button>
              </>
            )}
          </div>

          {/* Registration Tips */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <h4 className="font-medium text-blue-900 mb-2 text-sm">Registration Tips</h4>
            <ul className="space-y-1 text-xs text-blue-800">
              <li>• Have backup courses ready</li>
              <li>• Check for time conflicts</li>
              <li>• Verify prerequisites</li>
              <li>• Register at your assigned time</li>
              <li>• Contact advisor if unsure</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
