import { Mail, Phone, MapPin, Calendar, MessageSquare, Video } from 'lucide-react';

export function Advisor() {
  const advisor = {
    name: 'Dr. Robert Anderson',
    title: 'Academic Advisor - Computer Science',
    email: 'r.anderson@university.edu',
    phone: '(555) 123-4567',
    office: 'Building E, Room 305',
    officeHours: [
      { day: 'Monday', time: '2:00 PM - 4:00 PM' },
      { day: 'Wednesday', time: '10:00 AM - 12:00 PM' },
      { day: 'Friday', time: '1:00 PM - 3:00 PM' },
    ],
    specializations: ['Computer Science', 'Software Engineering', 'Career Planning'],
    bio: 'Dr. Anderson has been advising Computer Science students for over 15 years. He specializes in helping students plan their academic path, choose the right courses, and prepare for their careers in technology.',
  };

  const upcomingMeetings = [
    {
      id: '1',
      date: 'Feb 10, 2026',
      time: '2:30 PM',
      type: 'In-Person',
      topic: 'Course Selection for Fall 2026',
      status: 'confirmed',
    },
    {
      id: '2',
      date: 'Feb 24, 2026',
      time: '11:00 AM',
      type: 'Virtual',
      topic: 'Career Planning Discussion',
      status: 'pending',
    },
  ];

  const advisingNotes = [
    {
      date: 'Jan 15, 2026',
      topic: 'Academic Progress Review',
      summary: 'Discussed current semester performance. On track for graduation in Spring 2027. Recommended adding CS 450 (Machine Learning) next semester.',
    },
    {
      date: 'Dec 10, 2025',
      topic: 'Internship Preparation',
      summary: 'Reviewed resume and discussed summer internship opportunities. Provided contacts for local tech companies.',
    },
  ];

  return (
    <div className="space-y-6">
      {/* Advisor Profile */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <div className="flex items-start gap-6">
          <div className="size-24 rounded-full bg-blue-600 flex items-center justify-center flex-shrink-0">
            <span className="text-white text-3xl font-semibold">RA</span>
          </div>
          <div className="flex-1">
            <h2 className="text-2xl font-semibold text-gray-900">{advisor.name}</h2>
            <p className="text-gray-600 mt-1">{advisor.title}</p>
            <div className="flex flex-wrap gap-2 mt-3">
              {advisor.specializations.map((spec, index) => (
                <span key={index} className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm">
                  {spec}
                </span>
              ))}
            </div>
            <p className="text-gray-600 mt-4">{advisor.bio}</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6 pt-6 border-t border-gray-200">
          <div className="flex items-center gap-3">
            <Mail className="size-5 text-gray-400" />
            <div>
              <p className="text-xs text-gray-500">Email</p>
              <p className="text-sm text-gray-900">{advisor.email}</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Phone className="size-5 text-gray-400" />
            <div>
              <p className="text-xs text-gray-500">Phone</p>
              <p className="text-sm text-gray-900">{advisor.phone}</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <MapPin className="size-5 text-gray-400" />
            <div>
              <p className="text-xs text-gray-500">Office</p>
              <p className="text-sm text-gray-900">{advisor.office}</p>
            </div>
          </div>
        </div>

        <div className="flex gap-3 mt-6">
          <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium flex items-center gap-2">
            <Calendar className="size-4" />
            Schedule Appointment
          </button>
          <button className="px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors text-sm font-medium flex items-center gap-2">
            <MessageSquare className="size-4" />
            Send Message
          </button>
          <button className="px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors text-sm font-medium flex items-center gap-2">
            <Video className="size-4" />
            Join Virtual Meeting
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Office Hours */}
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h3 className="font-semibold text-gray-900 mb-4">Office Hours</h3>
          <div className="space-y-3">
            {advisor.officeHours.map((hours, index) => (
              <div key={index} className="flex items-center justify-between py-3 border-b border-gray-100 last:border-0">
                <span className="text-sm font-medium text-gray-900">{hours.day}</span>
                <span className="text-sm text-gray-600">{hours.time}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Upcoming Meetings */}
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h3 className="font-semibold text-gray-900 mb-4">Upcoming Meetings</h3>
          <div className="space-y-4">
            {upcomingMeetings.map((meeting) => (
              <div key={meeting.id} className="p-4 bg-gray-50 rounded-lg">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="font-medium text-gray-900">{meeting.topic}</p>
                    <div className="flex items-center gap-3 mt-2 text-sm text-gray-600">
                      <span>{meeting.date}</span>
                      <span>•</span>
                      <span>{meeting.time}</span>
                      <span>•</span>
                      <span>{meeting.type}</span>
                    </div>
                  </div>
                  <span
                    className={`px-2 py-1 rounded text-xs font-medium ${
                      meeting.status === 'confirmed'
                        ? 'bg-green-100 text-green-700'
                        : 'bg-yellow-100 text-yellow-700'
                    }`}
                  >
                    {meeting.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Advising Notes */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h3 className="font-semibold text-gray-900 mb-4">Advising Notes</h3>
        <div className="space-y-4">
          {advisingNotes.map((note, index) => (
            <div key={index} className="pb-4 border-b border-gray-100 last:border-0 last:pb-0">
              <div className="flex items-start justify-between mb-2">
                <h4 className="font-medium text-gray-900">{note.topic}</h4>
                <span className="text-sm text-gray-500">{note.date}</span>
              </div>
              <p className="text-sm text-gray-600">{note.summary}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
