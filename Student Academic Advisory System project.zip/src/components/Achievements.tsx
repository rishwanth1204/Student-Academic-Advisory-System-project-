import { Trophy, Award, Star, Target, Medal, Zap, Crown, Lock } from 'lucide-react';

interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  unlocked: boolean;
  progress?: number;
  maxProgress?: number;
  unlockedDate?: string;
  points: number;
  rarity: 'common' | 'rare' | 'epic' | 'legendary';
}

export function Achievements() {
  const achievements: Achievement[] = [
    {
      id: '1',
      title: 'Dean\'s List',
      description: 'Achieve a GPA of 3.5 or higher for a semester',
      icon: '🎓',
      unlocked: true,
      unlockedDate: '2025-12-20',
      points: 100,
      rarity: 'epic'
    },
    {
      id: '2',
      title: 'Perfect Score',
      description: 'Get 100% on an exam or assignment',
      icon: '💯',
      unlocked: true,
      unlockedDate: '2026-01-15',
      points: 50,
      rarity: 'rare'
    },
    {
      id: '3',
      title: 'Study Marathon',
      description: 'Attend 5 study group sessions in one week',
      icon: '📚',
      unlocked: true,
      unlockedDate: '2026-01-28',
      points: 75,
      rarity: 'rare'
    },
    {
      id: '4',
      title: 'Early Bird',
      description: 'Submit 10 assignments before the deadline',
      icon: '🐦',
      unlocked: true,
      progress: 10,
      maxProgress: 10,
      unlockedDate: '2026-02-01',
      points: 50,
      rarity: 'common'
    },
    {
      id: '5',
      title: 'Scholarship Winner',
      description: 'Receive an academic scholarship',
      icon: '💰',
      unlocked: false,
      progress: 1,
      maxProgress: 1,
      points: 200,
      rarity: 'legendary'
    },
    {
      id: '6',
      title: 'Research Pioneer',
      description: 'Publish a research paper',
      icon: '🔬',
      unlocked: false,
      progress: 0,
      maxProgress: 1,
      points: 250,
      rarity: 'legendary'
    },
    {
      id: '7',
      title: 'Networking Pro',
      description: 'Attend 3 career fairs or networking events',
      icon: '🤝',
      unlocked: false,
      progress: 2,
      maxProgress: 3,
      points: 75,
      rarity: 'rare'
    },
    {
      id: '8',
      title: 'Code Master',
      description: 'Complete 50 coding challenges',
      icon: '💻',
      unlocked: false,
      progress: 34,
      maxProgress: 50,
      points: 100,
      rarity: 'epic'
    },
    {
      id: '9',
      title: 'Perfect Attendance',
      description: 'No absences for an entire semester',
      icon: '✅',
      unlocked: true,
      unlockedDate: '2025-12-15',
      points: 50,
      rarity: 'common'
    },
    {
      id: '10',
      title: 'Tutor Champion',
      description: 'Complete 20 tutoring sessions',
      icon: '👨‍🏫',
      unlocked: false,
      progress: 12,
      maxProgress: 20,
      points: 150,
      rarity: 'epic'
    },
    {
      id: '11',
      title: 'Honor Roll',
      description: 'Maintain a 4.0 GPA for an entire year',
      icon: '⭐',
      unlocked: false,
      progress: 1,
      maxProgress: 2,
      points: 300,
      rarity: 'legendary'
    },
    {
      id: '12',
      title: 'Leadership Award',
      description: 'Organize or lead a student organization',
      icon: '👑',
      unlocked: false,
      progress: 0,
      maxProgress: 1,
      points: 200,
      rarity: 'legendary'
    },
    {
      id: '13',
      title: 'Quick Learner',
      description: 'Complete a course with an A grade',
      icon: '🚀',
      unlocked: true,
      unlockedDate: '2025-12-18',
      points: 50,
      rarity: 'common'
    },
    {
      id: '14',
      title: 'Community Helper',
      description: 'Participate in 10 community service hours',
      icon: '❤️',
      unlocked: false,
      progress: 6,
      maxProgress: 10,
      points: 100,
      rarity: 'rare'
    },
    {
      id: '15',
      title: 'All-Rounder',
      description: 'Complete courses in 5 different departments',
      icon: '🌟',
      unlocked: false,
      progress: 4,
      maxProgress: 5,
      points: 125,
      rarity: 'epic'
    }
  ];

  const unlockedAchievements = achievements.filter(a => a.unlocked);
  const lockedAchievements = achievements.filter(a => !a.unlocked);
  const totalPoints = unlockedAchievements.reduce((sum, a) => sum + a.points, 0);

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case 'common':
        return 'from-gray-400 to-gray-500';
      case 'rare':
        return 'from-blue-400 to-blue-600';
      case 'epic':
        return 'from-purple-400 to-purple-600';
      case 'legendary':
        return 'from-yellow-400 to-orange-600';
      default:
        return 'from-gray-400 to-gray-500';
    }
  };

  const getRarityBadge = (rarity: string) => {
    const colors = {
      common: 'bg-gray-100 text-gray-700',
      rare: 'bg-blue-100 text-blue-700',
      epic: 'bg-purple-100 text-purple-700',
      legendary: 'bg-yellow-100 text-yellow-700'
    };
    return colors[rarity as keyof typeof colors] || colors.common;
  };

  return (
    <div className="space-y-6">
      {/* Header Stats */}
      <div className="bg-gradient-to-r from-purple-600 to-blue-600 rounded-lg p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-semibold">Achievements</h2>
            <p className="text-blue-100 mt-2">Track your academic milestones and accomplishments</p>
          </div>
          <Trophy className="size-16 opacity-50" />
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="flex items-center gap-3">
            <Trophy className="size-8 text-yellow-600" />
            <div>
              <p className="text-2xl font-semibold text-gray-900">{unlockedAchievements.length}</p>
              <p className="text-sm text-gray-500">Unlocked</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="flex items-center gap-3">
            <Lock className="size-8 text-gray-400" />
            <div>
              <p className="text-2xl font-semibold text-gray-900">{lockedAchievements.length}</p>
              <p className="text-sm text-gray-500">Locked</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="flex items-center gap-3">
            <Star className="size-8 text-blue-600" />
            <div>
              <p className="text-2xl font-semibold text-gray-900">{totalPoints}</p>
              <p className="text-sm text-gray-500">Total Points</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="flex items-center gap-3">
            <Target className="size-8 text-green-600" />
            <div>
              <p className="text-2xl font-semibold text-gray-900">{Math.round((unlockedAchievements.length / achievements.length) * 100)}%</p>
              <p className="text-sm text-gray-500">Completion</p>
            </div>
          </div>
        </div>
      </div>

      {/* Progress Overview */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h3 className="font-semibold text-gray-900 mb-4">Overall Progress</h3>
        <div className="w-full bg-gray-200 rounded-full h-4">
          <div
            className="bg-gradient-to-r from-blue-600 to-purple-600 h-4 rounded-full transition-all flex items-center justify-end pr-2"
            style={{ width: `${(unlockedAchievements.length / achievements.length) * 100}%` }}
          >
            <span className="text-white text-xs font-medium">
              {unlockedAchievements.length}/{achievements.length}
            </span>
          </div>
        </div>
      </div>

      {/* Recently Unlocked */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h3 className="font-semibold text-gray-900 mb-4">Recently Unlocked</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {unlockedAchievements.slice(0, 3).map(achievement => (
            <div
              key={achievement.id}
              className={`relative p-6 rounded-lg bg-gradient-to-br ${getRarityColor(achievement.rarity)} text-white overflow-hidden`}
            >
              <div className="relative z-10">
                <div className="text-5xl mb-3">{achievement.icon}</div>
                <h4 className="font-semibold mb-1">{achievement.title}</h4>
                <p className="text-sm text-white/90 mb-3">{achievement.description}</p>
                <div className="flex items-center justify-between">
                  <span className="text-xs bg-white/20 px-2 py-1 rounded">
                    {achievement.points} pts
                  </span>
                  <span className="text-xs">
                    {achievement.unlockedDate && new Date(achievement.unlockedDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                  </span>
                </div>
              </div>
              <div className="absolute top-0 right-0 opacity-10">
                <Trophy className="size-32" />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* All Achievements */}
      <div>
        <h3 className="font-semibold text-gray-900 mb-4">All Achievements</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {achievements.map(achievement => (
            <div
              key={achievement.id}
              className={`p-5 rounded-lg border-2 transition-all ${
                achievement.unlocked
                  ? 'border-gray-200 bg-white hover:shadow-lg'
                  : 'border-gray-200 bg-gray-50 opacity-75'
              }`}
            >
              <div className="flex items-start gap-4">
                <div className={`text-4xl ${!achievement.unlocked && 'grayscale opacity-50'}`}>
                  {achievement.unlocked ? achievement.icon : '🔒'}
                </div>
                <div className="flex-1">
                  <div className="flex items-start justify-between mb-2">
                    <h4 className="font-semibold text-gray-900">{achievement.title}</h4>
                    <span className={`px-2 py-0.5 rounded text-xs font-medium ${getRarityBadge(achievement.rarity)}`}>
                      {achievement.rarity}
                    </span>
                  </div>
                  <p className="text-sm text-gray-600 mb-3">{achievement.description}</p>

                  {!achievement.unlocked && achievement.maxProgress && (
                    <div className="mb-3">
                      <div className="flex items-center justify-between text-xs text-gray-600 mb-1">
                        <span>Progress</span>
                        <span>{achievement.progress}/{achievement.maxProgress}</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div
                          className="bg-blue-600 h-2 rounded-full transition-all"
                          style={{ width: `${((achievement.progress || 0) / achievement.maxProgress) * 100}%` }}
                        />
                      </div>
                    </div>
                  )}

                  <div className="flex items-center justify-between text-sm">
                    <span className="flex items-center gap-1 text-gray-600">
                      <Star className="size-4 text-yellow-500 fill-current" />
                      {achievement.points} points
                    </span>
                    {achievement.unlocked && achievement.unlockedDate && (
                      <span className="text-xs text-gray-500">
                        {new Date(achievement.unlockedDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Leaderboard Teaser */}
      <div className="bg-gradient-to-r from-yellow-400 to-orange-500 rounded-lg p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-xl font-semibold mb-2">🏆 Leaderboard</h3>
            <p className="text-yellow-50">You rank #127 out of 2,450 students</p>
            <p className="text-sm text-yellow-100 mt-1">Keep unlocking achievements to climb higher!</p>
          </div>
          <div className="text-right">
            <p className="text-4xl font-bold">#127</p>
            <p className="text-sm text-yellow-100">Your Rank</p>
          </div>
        </div>
      </div>
    </div>
  );
}
