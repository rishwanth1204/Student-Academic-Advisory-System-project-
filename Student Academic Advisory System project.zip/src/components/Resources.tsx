import { useState } from 'react';
import { FileText, Video, Link, Download, Search, Filter, Star, BookOpen, File } from 'lucide-react';

interface Resource {
  id: string;
  title: string;
  type: 'pdf' | 'video' | 'link' | 'document';
  course: string;
  category: string;
  uploadDate: string;
  rating: number;
  downloads: number;
  size?: string;
}

export function Resources() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');

  const resources: Resource[] = [
    {
      id: '1',
      title: 'Data Structures Complete Notes',
      type: 'pdf',
      course: 'CS 301',
      category: 'Lecture Notes',
      uploadDate: '2026-01-15',
      rating: 4.8,
      downloads: 234,
      size: '2.4 MB'
    },
    {
      id: '2',
      title: 'Introduction to Binary Trees',
      type: 'video',
      course: 'CS 301',
      category: 'Video Tutorials',
      uploadDate: '2026-01-20',
      rating: 4.9,
      downloads: 156
    },
    {
      id: '3',
      title: 'SQL Practice Problems',
      type: 'pdf',
      course: 'CS 305',
      category: 'Practice Materials',
      uploadDate: '2026-01-22',
      rating: 4.6,
      downloads: 189,
      size: '1.8 MB'
    },
    {
      id: '4',
      title: 'Database Design Tutorial',
      type: 'video',
      course: 'CS 305',
      category: 'Video Tutorials',
      uploadDate: '2026-01-25',
      rating: 4.7,
      downloads: 145
    },
    {
      id: '5',
      title: 'JavaScript ES6 Features Guide',
      type: 'pdf',
      course: 'CS 320',
      category: 'Reference Guides',
      uploadDate: '2026-02-01',
      rating: 4.9,
      downloads: 267,
      size: '3.2 MB'
    },
    {
      id: '6',
      title: 'React Hooks Tutorial Series',
      type: 'video',
      course: 'CS 320',
      category: 'Video Tutorials',
      uploadDate: '2026-02-02',
      rating: 5.0,
      downloads: 312
    },
    {
      id: '7',
      title: 'Algorithm Complexity Cheat Sheet',
      type: 'pdf',
      course: 'CS 340',
      category: 'Reference Guides',
      uploadDate: '2026-01-18',
      rating: 4.8,
      downloads: 445,
      size: '0.8 MB'
    },
    {
      id: '8',
      title: 'Operating Systems Concepts',
      type: 'pdf',
      course: 'CS 350',
      category: 'Lecture Notes',
      uploadDate: '2026-01-28',
      rating: 4.7,
      downloads: 198,
      size: '4.1 MB'
    },
    {
      id: '9',
      title: 'W3Schools Online Reference',
      type: 'link',
      course: 'CS 320',
      category: 'External Resources',
      uploadDate: '2026-01-10',
      rating: 4.5,
      downloads: 89
    },
    {
      id: '10',
      title: 'Sorting Algorithms Visualization',
      type: 'link',
      course: 'CS 340',
      category: 'External Resources',
      uploadDate: '2026-01-12',
      rating: 4.9,
      downloads: 276
    },
    {
      id: '11',
      title: 'Midterm Exam Review Questions',
      type: 'document',
      course: 'CS 301',
      category: 'Exam Prep',
      uploadDate: '2026-02-03',
      rating: 4.8,
      downloads: 523,
      size: '1.2 MB'
    },
    {
      id: '12',
      title: 'Database Normalization Examples',
      type: 'pdf',
      course: 'CS 305',
      category: 'Practice Materials',
      uploadDate: '2026-01-30',
      rating: 4.6,
      downloads: 167,
      size: '1.5 MB'
    }
  ];

  const categories = ['all', 'Lecture Notes', 'Video Tutorials', 'Practice Materials', 'Reference Guides', 'External Resources', 'Exam Prep'];

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'pdf':
        return <FileText className="size-5 text-red-500" />;
      case 'video':
        return <Video className="size-5 text-purple-500" />;
      case 'link':
        return <Link className="size-5 text-blue-500" />;
      case 'document':
        return <File className="size-5 text-green-500" />;
      default:
        return <FileText className="size-5 text-gray-500" />;
    }
  };

  const filteredResources = resources.filter(resource => {
    const matchesSearch = resource.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         resource.course.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || resource.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h2 className="text-2xl font-semibold text-gray-900 mb-4">Study Resources</h2>
        
        {/* Search and Filters */}
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 size-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search resources..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            {categories.map(category => (
              <option key={category} value={category}>
                {category === 'all' ? 'All Categories' : category}
              </option>
            ))}
          </select>
        </div>

        <div className="mt-4 flex items-center gap-2 text-sm text-gray-600">
          <Filter className="size-4" />
          <span>Showing {filteredResources.length} of {resources.length} resources</span>
        </div>
      </div>

      {/* Resources Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredResources.map(resource => (
          <div key={resource.id} className="bg-white rounded-lg border border-gray-200 p-6 hover:shadow-lg transition-shadow">
            <div className="flex items-start justify-between mb-4">
              {getTypeIcon(resource.type)}
              <div className="flex items-center gap-1 text-yellow-500">
                <Star className="size-4 fill-current" />
                <span className="text-sm text-gray-900">{resource.rating}</span>
              </div>
            </div>

            <h3 className="font-medium text-gray-900 mb-2">{resource.title}</h3>
            
            <div className="space-y-2 mb-4">
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-500">Course:</span>
                <span className="text-gray-900 font-medium">{resource.course}</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-500">Category:</span>
                <span className="text-gray-700">{resource.category}</span>
              </div>
              {resource.size && (
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-500">Size:</span>
                  <span className="text-gray-700">{resource.size}</span>
                </div>
              )}
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-500">Downloads:</span>
                <span className="text-gray-700">{resource.downloads}</span>
              </div>
            </div>

            <div className="flex gap-2">
              <button className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium flex items-center justify-center gap-2">
                <Download className="size-4" />
                Download
              </button>
              <button className="px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors text-sm font-medium">
                View
              </button>
            </div>

            <p className="text-xs text-gray-500 mt-3">
              Added {new Date(resource.uploadDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
            </p>
          </div>
        ))}
      </div>

      {/* Popular Resources */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h3 className="font-semibold text-gray-900 mb-4">Most Popular This Week</h3>
        <div className="space-y-3">
          {resources
            .sort((a, b) => b.downloads - a.downloads)
            .slice(0, 5)
            .map((resource, index) => (
              <div key={resource.id} className="flex items-center gap-4 p-3 bg-gray-50 rounded-lg">
                <span className="text-2xl font-semibold text-gray-400 w-8">
                  {index + 1}
                </span>
                {getTypeIcon(resource.type)}
                <div className="flex-1">
                  <p className="font-medium text-gray-900 text-sm">{resource.title}</p>
                  <p className="text-xs text-gray-500">{resource.course} • {resource.downloads} downloads</p>
                </div>
                <div className="flex items-center gap-1 text-yellow-500">
                  <Star className="size-4 fill-current" />
                  <span className="text-sm text-gray-900">{resource.rating}</span>
                </div>
              </div>
            ))}
        </div>
      </div>
    </div>
  );
}
